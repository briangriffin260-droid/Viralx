import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../src/contexts/AuthContext';
import colors from '../src/theme/colors';
import api from '../src/services/api';

const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL || 'http://localhost:8001';

interface CoinPackage {
  id: string;
  coins: number;
  price: number;
  bonus?: number;
}

interface VirtualGift {
  id: string;
  name: string;
  icon: string;
  coin_cost: number;
}

const COIN_PACKAGES: CoinPackage[] = [
  { id: 'small', coins: 100, price: 0.99 },
  { id: 'medium', coins: 500, price: 4.99, bonus: 50 },
  { id: 'large', coins: 1000, price: 9.99, bonus: 150 },
  { id: 'mega', coins: 5000, price: 39.99, bonus: 1000 },
];

const VIRTUAL_GIFTS: VirtualGift[] = [
  { id: 'heart', name: 'Heart', icon: 'heart', coin_cost: 10 },
  { id: 'star', name: 'Star', icon: 'star', coin_cost: 50 },
  { id: 'diamond', name: 'Diamond', icon: 'diamond', coin_cost: 100 },
  { id: 'crown', name: 'Crown', icon: 'trophy', coin_cost: 500 },
  { id: 'rocket', name: 'Rocket', icon: 'rocket', coin_cost: 1000 },
];

export default function WalletScreen() {
  const { user, refreshUser } = useAuth();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [coinBalance, setCoinBalance] = useState(0);
  const [badgeStatus, setBadgeStatus] = useState<any>(null);
  const [analyticsStatus, setAnalyticsStatus] = useState<any>(null);
  
  // Modals
  const [showBuyCoinsModal, setShowBuyCoinsModal] = useState(false);
  const [showBadgeModal, setShowBadgeModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [showPromoteModal, setShowPromoteModal] = useState(false);
  const [showFeaturedModal, setShowFeaturedModal] = useState(false);
  
  // Form states
  const [promoteBudget, setPromoteBudget] = useState('10');
  const [promoteDays, setPromoteDays] = useState('7');
  const [selectedFeaturedType, setSelectedFeaturedType] = useState('explore');
  
  const [processingPayment, setProcessingPayment] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Get coin balance
      const balanceRes = await api.get('/coins/balance');
      setCoinBalance(balanceRes.data.balance || 0);
      
      // Get badge status
      const badgeRes = await api.get('/verified/status');
      setBadgeStatus(badgeRes.data);
      
      // Get analytics status if creator
      if (user?.is_premium_creator) {
        const analyticsRes = await api.get('/analytics/status');
        setAnalyticsStatus(analyticsRes.data);
      }
    } catch (error) {
      console.log('Error loading wallet data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    await refreshUser();
    setIsRefreshing(false);
  };

  const handleBuyCoins = async (pkg: CoinPackage) => {
    setProcessingPayment(true);
    try {
      const response = await api.post('/coins/buy', {
        package_id: pkg.id,
        origin_url: `${API_URL}/wallet`,
      });
      
      if (response.data.checkout_url) {
        await Linking.openURL(response.data.checkout_url);
        Alert.alert('Payment', 'Complete the payment in your browser. Your coins will be added automatically.');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to initiate purchase');
    } finally {
      setProcessingPayment(false);
      setShowBuyCoinsModal(false);
    }
  };

  const handlePurchaseBadge = async (months: number) => {
    setProcessingPayment(true);
    try {
      const response = await api.post('/verified/purchase', {
        months,
        origin_url: `${API_URL}/wallet`,
      });
      
      if (response.data.checkout_url) {
        await Linking.openURL(response.data.checkout_url);
        Alert.alert('Payment', 'Complete the payment in your browser to get your verified badge.');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to initiate purchase');
    } finally {
      setProcessingPayment(false);
      setShowBadgeModal(false);
    }
  };

  const handleSubscribeAnalytics = async (plan: string) => {
    setProcessingPayment(true);
    try {
      const response = await api.post('/analytics/subscribe', {
        plan: plan,
        origin_url: `${API_URL}/wallet`,
      });
      
      if (response.data.checkout_url) {
        await Linking.openURL(response.data.checkout_url);
        Alert.alert('Payment', 'Complete the payment to unlock premium analytics.');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to initiate subscription');
    } finally {
      setProcessingPayment(false);
      setShowAnalyticsModal(false);
    }
  };

  const handlePromoteProfile = async () => {
    const budget = parseFloat(promoteBudget);
    const days = parseInt(promoteDays);
    
    if (isNaN(budget) || budget < 5) {
      Alert.alert('Error', 'Minimum budget is $5');
      return;
    }
    if (isNaN(days) || days < 1 || days > 30) {
      Alert.alert('Error', 'Duration must be between 1-30 days');
      return;
    }

    setProcessingPayment(true);
    try {
      const response = await api.post('/promote/profile', {
        budget,
        duration_days: days,
        origin_url: `${API_URL}/wallet`,
      });
      
      if (response.data.checkout_url) {
        await Linking.openURL(response.data.checkout_url);
        Alert.alert('Payment', 'Complete the payment to promote your profile.');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to initiate promotion');
    } finally {
      setProcessingPayment(false);
      setShowPromoteModal(false);
    }
  };

  const handlePurchaseFeaturedSpot = async () => {
    setProcessingPayment(true);
    try {
      const response = await api.post('/featured/purchase', {
        spot_type: selectedFeaturedType,
        duration_days: 7,
        origin_url: `${API_URL}/wallet`,
      });
      
      if (response.data.checkout_url) {
        await Linking.openURL(response.data.checkout_url);
        Alert.alert('Payment', 'Complete the payment to get featured.');
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to initiate purchase');
    } finally {
      setProcessingPayment(false);
      setShowFeaturedModal(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Wallet & Monetization</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={styles.scrollContent}
      >
        {/* Coin Balance Card */}
        <View style={styles.balanceCard}>
          <View style={styles.balanceHeader}>
            <Ionicons name="diamond" size={32} color={colors.premium} />
            <Text style={styles.balanceTitle}>Coin Balance</Text>
          </View>
          <Text style={styles.balanceAmount}>{coinBalance.toLocaleString()}</Text>
          <Text style={styles.balanceSubtext}>coins</Text>
          <TouchableOpacity 
            style={styles.buyCoinsButton}
            onPress={() => setShowBuyCoinsModal(true)}
          >
            <Ionicons name="add-circle" size={20} color="#fff" />
            <Text style={styles.buyCoinsText}>Buy Coins</Text>
          </TouchableOpacity>
        </View>

        {/* Monetization Features */}
        <Text style={styles.sectionTitle}>Boost Your Presence</Text>
        
        {/* Verified Badge */}
        <TouchableOpacity 
          style={styles.featureCard}
          onPress={() => setShowBadgeModal(true)}
        >
          <View style={[styles.featureIcon, { backgroundColor: `${colors.info}15` }]}>
            <Ionicons name="checkmark-circle" size={28} color={colors.info} />
          </View>
          <View style={styles.featureContent}>
            <Text style={styles.featureTitle}>Verified Badge</Text>
            <Text style={styles.featureDescription}>
              Get a blue checkmark on your profile
            </Text>
            {badgeStatus?.is_verified && (
              <View style={styles.activeTag}>
                <Text style={styles.activeTagText}>Active</Text>
              </View>
            )}
          </View>
          <Ionicons name="chevron-forward" size={24} color={colors.textTertiary} />
        </TouchableOpacity>

        {/* Promote Profile */}
        <TouchableOpacity 
          style={styles.featureCard}
          onPress={() => setShowPromoteModal(true)}
        >
          <View style={[styles.featureIcon, { backgroundColor: `${colors.success}15` }]}>
            <Ionicons name="trending-up" size={28} color={colors.success} />
          </View>
          <View style={styles.featureContent}>
            <Text style={styles.featureTitle}>Promote Profile</Text>
            <Text style={styles.featureDescription}>
              Appear in more search results & suggestions
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={colors.textTertiary} />
        </TouchableOpacity>

        {/* Featured Spot */}
        <TouchableOpacity 
          style={styles.featureCard}
          onPress={() => setShowFeaturedModal(true)}
        >
          <View style={[styles.featureIcon, { backgroundColor: `${colors.premium}15` }]}>
            <Ionicons name="star" size={28} color={colors.premium} />
          </View>
          <View style={styles.featureContent}>
            <Text style={styles.featureTitle}>Featured Creator Spot</Text>
            <Text style={styles.featureDescription}>
              Get featured on the Explore page
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={colors.textTertiary} />
        </TouchableOpacity>

        {/* Creator-only Features */}
        {user?.is_premium_creator && (
          <>
            <Text style={styles.sectionTitle}>Creator Tools</Text>
            
            {/* Premium Analytics */}
            <TouchableOpacity 
              style={styles.featureCard}
              onPress={() => setShowAnalyticsModal(true)}
            >
              <View style={[styles.featureIcon, { backgroundColor: `${colors.accent}15` }]}>
                <Ionicons name="analytics" size={28} color={colors.accent} />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Premium Analytics</Text>
                <Text style={styles.featureDescription}>
                  Detailed insights about your audience
                </Text>
                {analyticsStatus?.is_active && (
                  <View style={styles.activeTag}>
                    <Text style={styles.activeTagText}>Active</Text>
                  </View>
                )}
              </View>
              <Ionicons name="chevron-forward" size={24} color={colors.textTertiary} />
            </TouchableOpacity>
          </>
        )}

        {/* Info Section */}
        <View style={styles.infoSection}>
          <Ionicons name="information-circle" size={20} color={colors.textTertiary} />
          <Text style={styles.infoText}>
            All payments are processed securely via Stripe. 
            The platform takes a 15% fee on creator earnings.
          </Text>
        </View>
      </ScrollView>

      {/* Buy Coins Modal */}
      <Modal
        visible={showBuyCoinsModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowBuyCoinsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Buy Coins</Text>
              <TouchableOpacity onPress={() => setShowBuyCoinsModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalBody}>
              {COIN_PACKAGES.map((pkg) => (
                <TouchableOpacity
                  key={pkg.id}
                  style={styles.packageCard}
                  onPress={() => handleBuyCoins(pkg)}
                  disabled={processingPayment}
                >
                  <View style={styles.packageLeft}>
                    <Ionicons name="diamond" size={24} color={colors.premium} />
                    <View>
                      <Text style={styles.packageCoins}>
                        {pkg.coins.toLocaleString()} coins
                      </Text>
                      {pkg.bonus && (
                        <Text style={styles.packageBonus}>+{pkg.bonus} bonus!</Text>
                      )}
                    </View>
                  </View>
                  <View style={styles.packagePrice}>
                    <Text style={styles.priceText}>${pkg.price.toFixed(2)}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Badge Purchase Modal */}
      <Modal
        visible={showBadgeModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowBadgeModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Verified Badge</Text>
              <TouchableOpacity onPress={() => setShowBadgeModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <View style={styles.badgePreview}>
                <Ionicons name="checkmark-circle" size={64} color={colors.info} />
                <Text style={styles.badgeTitle}>Get Verified</Text>
                <Text style={styles.badgeDescription}>
                  Stand out with a blue checkmark on your profile. 
                  Shows others you're a trusted member of the community.
                </Text>
              </View>
              
              <TouchableOpacity
                style={styles.purchaseOption}
                onPress={() => handlePurchaseBadge(1)}
                disabled={processingPayment}
              >
                <Text style={styles.purchaseOptionTitle}>1 Month</Text>
                <Text style={styles.purchaseOptionPrice}>$4.99</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.purchaseOption, styles.purchaseOptionPopular]}
                onPress={() => handlePurchaseBadge(6)}
                disabled={processingPayment}
              >
                <View style={styles.popularTag}>
                  <Text style={styles.popularTagText}>Best Value</Text>
                </View>
                <Text style={styles.purchaseOptionTitle}>6 Months</Text>
                <Text style={styles.purchaseOptionPrice}>$19.99</Text>
                <Text style={styles.purchaseOptionSave}>Save 33%</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.purchaseOption}
                onPress={() => handlePurchaseBadge(12)}
                disabled={processingPayment}
              >
                <Text style={styles.purchaseOptionTitle}>12 Months</Text>
                <Text style={styles.purchaseOptionPrice}>$34.99</Text>
                <Text style={styles.purchaseOptionSave}>Save 42%</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Promote Profile Modal */}
      <Modal
        visible={showPromoteModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowPromoteModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Promote Your Profile</Text>
              <TouchableOpacity onPress={() => setShowPromoteModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Budget ($)</Text>
              <TextInput
                style={styles.textInput}
                value={promoteBudget}
                onChangeText={setPromoteBudget}
                keyboardType="decimal-pad"
                placeholder="Minimum $5"
                placeholderTextColor={colors.textTertiary}
              />
              
              <Text style={styles.inputLabel}>Duration (days)</Text>
              <TextInput
                style={styles.textInput}
                value={promoteDays}
                onChangeText={setPromoteDays}
                keyboardType="number-pad"
                placeholder="1-30 days"
                placeholderTextColor={colors.textTertiary}
              />
              
              <View style={styles.estimateBox}>
                <Text style={styles.estimateTitle}>Estimated Reach</Text>
                <Text style={styles.estimateValue}>
                  ~{Math.floor(parseFloat(promoteBudget || '0') * 100)} impressions
                </Text>
              </View>
              
              <TouchableOpacity
                style={styles.primaryButton}
                onPress={handlePromoteProfile}
                disabled={processingPayment}
              >
                {processingPayment ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.primaryButtonText}>Promote for ${promoteBudget}</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Featured Spot Modal */}
      <Modal
        visible={showFeaturedModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowFeaturedModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Featured Creator Spot</Text>
              <TouchableOpacity onPress={() => setShowFeaturedModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.featuredDescription}>
                Get featured prominently on the Explore page for 7 days!
              </Text>
              
              <TouchableOpacity
                style={[
                  styles.featuredOption,
                  selectedFeaturedType === 'explore' && styles.featuredOptionSelected
                ]}
                onPress={() => setSelectedFeaturedType('explore')}
              >
                <Ionicons name="compass" size={24} color={colors.primary} />
                <View style={styles.featuredOptionContent}>
                  <Text style={styles.featuredOptionTitle}>Explore Page</Text>
                  <Text style={styles.featuredOptionDesc}>Top of the explore feed</Text>
                </View>
                <Text style={styles.featuredOptionPrice}>$29.99/week</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.featuredOption,
                  selectedFeaturedType === 'home' && styles.featuredOptionSelected
                ]}
                onPress={() => setSelectedFeaturedType('home')}
              >
                <Ionicons name="home" size={24} color={colors.primary} />
                <View style={styles.featuredOptionContent}>
                  <Text style={styles.featuredOptionTitle}>Home Feed</Text>
                  <Text style={styles.featuredOptionDesc}>Featured in users' home feed</Text>
                </View>
                <Text style={styles.featuredOptionPrice}>$49.99/week</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.primaryButton}
                onPress={handlePurchaseFeaturedSpot}
                disabled={processingPayment}
              >
                {processingPayment ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.primaryButtonText}>Get Featured</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Analytics Modal */}
      <Modal
        visible={showAnalyticsModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowAnalyticsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Premium Analytics</Text>
              <TouchableOpacity onPress={() => setShowAnalyticsModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <View style={styles.analyticsPreview}>
                <Ionicons name="analytics" size={48} color={colors.accent} />
                <Text style={styles.analyticsTitle}>Unlock Deep Insights</Text>
                <Text style={styles.analyticsDescription}>
                  See detailed data about your audience, engagement patterns, 
                  revenue trends, and growth opportunities.
                </Text>
              </View>
              
              <View style={styles.analyticsFeatures}>
                <View style={styles.analyticsFeature}>
                  <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                  <Text style={styles.analyticsFeatureText}>Audience demographics</Text>
                </View>
                <View style={styles.analyticsFeature}>
                  <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                  <Text style={styles.analyticsFeatureText}>Revenue breakdown</Text>
                </View>
                <View style={styles.analyticsFeature}>
                  <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                  <Text style={styles.analyticsFeatureText}>Best posting times</Text>
                </View>
                <View style={styles.analyticsFeature}>
                  <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                  <Text style={styles.analyticsFeatureText}>Growth predictions</Text>
                </View>
              </View>
              
              <TouchableOpacity
                style={styles.purchaseOption}
                onPress={() => handleSubscribeAnalytics('monthly')}
                disabled={processingPayment}
              >
                <Text style={styles.purchaseOptionTitle}>Monthly</Text>
                <Text style={styles.purchaseOptionPrice}>$9.99/mo</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.purchaseOption, styles.purchaseOptionPopular]}
                onPress={() => handleSubscribeAnalytics('yearly')}
                disabled={processingPayment}
              >
                <View style={styles.popularTag}>
                  <Text style={styles.popularTagText}>Best Value</Text>
                </View>
                <Text style={styles.purchaseOptionTitle}>Yearly</Text>
                <Text style={styles.purchaseOptionPrice}>$79.99/yr</Text>
                <Text style={styles.purchaseOptionSave}>Save 33%</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  balanceCard: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.border,
  },
  balanceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  balanceTitle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  balanceAmount: {
    fontSize: 48,
    fontWeight: 'bold',
    color: colors.premium,
  },
  balanceSubtext: {
    fontSize: 14,
    color: colors.textTertiary,
    marginBottom: 16,
  },
  buyCoinsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.premium,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    gap: 8,
  },
  buyCoinsText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 12,
    marginTop: 8,
  },
  featureCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  featureIcon: {
    width: 52,
    height: 52,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  featureDescription: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  activeTag: {
    backgroundColor: `${colors.success}20`,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginTop: 6,
  },
  activeTagText: {
    fontSize: 11,
    color: colors.success,
    fontWeight: '600',
  },
  infoSection: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.backgroundAlt,
    padding: 16,
    borderRadius: 12,
    marginTop: 24,
    gap: 12,
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: colors.textTertiary,
    lineHeight: 20,
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  modalBody: {
    padding: 20,
    paddingBottom: 40,
  },
  // Package Cards
  packageCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  packageLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  packageCoins: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  packageBonus: {
    fontSize: 12,
    color: colors.success,
    fontWeight: '500',
  },
  packagePrice: {
    backgroundColor: colors.premium,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  priceText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  // Badge Preview
  badgePreview: {
    alignItems: 'center',
    marginBottom: 24,
  },
  badgeTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.textPrimary,
    marginTop: 12,
  },
  badgeDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 22,
  },
  // Purchase Options
  purchaseOption: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  purchaseOptionPopular: {
    borderColor: colors.premium,
    borderWidth: 2,
  },
  popularTag: {
    position: 'absolute',
    top: -10,
    backgroundColor: colors.premium,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  popularTagText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '600',
  },
  purchaseOptionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  purchaseOptionPrice: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.premium,
    marginTop: 4,
  },
  purchaseOptionSave: {
    fontSize: 12,
    color: colors.success,
    marginTop: 4,
  },
  // Input Styles
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textPrimary,
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: colors.textPrimary,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  estimateBox: {
    backgroundColor: `${colors.success}10`,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  estimateTitle: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  estimateValue: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.success,
    marginTop: 4,
  },
  primaryButton: {
    backgroundColor: colors.accent,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  primaryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  // Featured Options
  featuredDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 22,
  },
  featuredOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  featuredOptionSelected: {
    borderColor: colors.primary,
  },
  featuredOptionContent: {
    flex: 1,
    marginLeft: 12,
  },
  featuredOptionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  featuredOptionDesc: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  featuredOptionPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.premium,
  },
  // Analytics Preview
  analyticsPreview: {
    alignItems: 'center',
    marginBottom: 20,
  },
  analyticsTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.textPrimary,
    marginTop: 12,
  },
  analyticsDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 22,
  },
  analyticsFeatures: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  analyticsFeature: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  analyticsFeatureText: {
    fontSize: 14,
    color: colors.textPrimary,
  },
});
