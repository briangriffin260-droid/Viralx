import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import colors from '../src/theme/colors';

const { width } = Dimensions.get('window');

// API base URL
const API_BASE = process.env.EXPO_PUBLIC_BACKEND_URL || '';

interface DashboardData {
  overview: {
    total_revenue: number;
    platform_earnings: number;
    creator_payouts: number;
    total_transactions: number;
    ad_revenue: number;
    total_income: number;
  };
  today: {
    transactions: number;
    revenue: number;
  };
  users: {
    total: number;
    creators: number;
    subscribers: number;
  };
  recent_transactions: Array<{
    id: string;
    type: string;
    amount: number;
    platform_fee: number;
    creator_amount: number;
    created_at: string;
  }>;
  platform_fee_percent: number;
}

export default function AdminDashboardScreen() {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/admin/dashboard`, {
        headers: {
          'Authorization': `Bearer ${await getToken()}`,
        },
      });
      const data = await response.json();
      setDashboardData(data);
    } catch (error) {
      console.log('Dashboard error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getToken = async () => {
    // Get token from AsyncStorage
    const AsyncStorage = require('@react-native-async-storage/async-storage').default;
    return await AsyncStorage.getItem('token');
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchDashboard();
    setIsRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toFixed(2)}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Admin Dashboard</Text>
        <TouchableOpacity onPress={handleRefresh}>
          <Ionicons name="refresh" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Total Income Card */}
        <View style={styles.totalIncomeCard}>
          <Text style={styles.totalIncomeLabel}>Total Platform Income</Text>
          <Text style={styles.totalIncomeAmount}>
            {formatCurrency(dashboardData?.overview.total_income || 0)}
          </Text>
          <View style={styles.incomeBreakdown}>
            <View style={styles.incomeItem}>
              <Ionicons name="card" size={16} color="#fff" />
              <Text style={styles.incomeItemLabel}>Fees ({dashboardData?.platform_fee_percent}%)</Text>
              <Text style={styles.incomeItemValue}>
                {formatCurrency(dashboardData?.overview.platform_earnings || 0)}
              </Text>
            </View>
            <View style={styles.incomeDivider} />
            <View style={styles.incomeItem}>
              <Ionicons name="megaphone" size={16} color="#fff" />
              <Text style={styles.incomeItemLabel}>Ads</Text>
              <Text style={styles.incomeItemValue}>
                {formatCurrency(dashboardData?.overview.ad_revenue || 0)}
              </Text>
            </View>
          </View>
        </View>

        {/* Today's Stats */}
        <View style={styles.sectionHeader}>
          <Ionicons name="today" size={20} color={colors.textPrimary} />
          <Text style={styles.sectionTitle}>Today</Text>
        </View>
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Ionicons name="receipt" size={24} color={colors.primary} />
            <Text style={styles.statValue}>{dashboardData?.today.transactions || 0}</Text>
            <Text style={styles.statLabel}>Transactions</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="cash" size={24} color={colors.success} />
            <Text style={styles.statValue}>{formatCurrency(dashboardData?.today.revenue || 0)}</Text>
            <Text style={styles.statLabel}>Revenue</Text>
          </View>
        </View>

        {/* Overview Stats */}
        <View style={styles.sectionHeader}>
          <Ionicons name="analytics" size={20} color={colors.textPrimary} />
          <Text style={styles.sectionTitle}>All Time</Text>
        </View>
        <View style={styles.overviewGrid}>
          <View style={styles.overviewCard}>
            <Text style={styles.overviewValue}>
              {formatCurrency(dashboardData?.overview.total_revenue || 0)}
            </Text>
            <Text style={styles.overviewLabel}>Total Revenue</Text>
          </View>
          <View style={styles.overviewCard}>
            <Text style={styles.overviewValue}>
              {dashboardData?.overview.total_transactions || 0}
            </Text>
            <Text style={styles.overviewLabel}>Transactions</Text>
          </View>
          <View style={styles.overviewCard}>
            <Text style={styles.overviewValue}>
              {formatCurrency(dashboardData?.overview.creator_payouts || 0)}
            </Text>
            <Text style={styles.overviewLabel}>Creator Payouts</Text>
          </View>
        </View>

        {/* User Stats */}
        <View style={styles.sectionHeader}>
          <Ionicons name="people" size={20} color={colors.textPrimary} />
          <Text style={styles.sectionTitle}>Users</Text>
        </View>
        <View style={styles.statsRow}>
          <View style={styles.userStatCard}>
            <Text style={styles.userStatValue}>{dashboardData?.users.total || 0}</Text>
            <Text style={styles.userStatLabel}>Total Users</Text>
          </View>
          <View style={styles.userStatCard}>
            <View style={styles.userStatIcon}>
              <Ionicons name="star" size={16} color={colors.premium} />
            </View>
            <Text style={styles.userStatValue}>{dashboardData?.users.creators || 0}</Text>
            <Text style={styles.userStatLabel}>Creators</Text>
          </View>
          <View style={styles.userStatCard}>
            <Text style={styles.userStatValue}>{dashboardData?.users.subscribers || 0}</Text>
            <Text style={styles.userStatLabel}>Subscribers</Text>
          </View>
        </View>

        {/* Recent Transactions */}
        <View style={styles.sectionHeader}>
          <Ionicons name="time" size={20} color={colors.textPrimary} />
          <Text style={styles.sectionTitle}>Recent Transactions</Text>
        </View>
        <View style={styles.transactionsCard}>
          {dashboardData?.recent_transactions.length === 0 ? (
            <Text style={styles.noTransactions}>No transactions yet</Text>
          ) : (
            dashboardData?.recent_transactions.map((transaction) => (
              <View key={transaction.id} style={styles.transactionItem}>
                <View style={styles.transactionIcon}>
                  <Ionicons
                    name={transaction.type === 'subscription' ? 'star' : 'cash'}
                    size={20}
                    color={transaction.type === 'subscription' ? colors.premium : colors.success}
                  />
                </View>
                <View style={styles.transactionInfo}>
                  <Text style={styles.transactionType}>
                    {transaction.type === 'subscription' ? 'Subscription' : 'Tip'}
                  </Text>
                  <Text style={styles.transactionDate}>{formatDate(transaction.created_at)}</Text>
                </View>
                <View style={styles.transactionAmounts}>
                  <Text style={styles.transactionTotal}>{formatCurrency(transaction.amount)}</Text>
                  <Text style={styles.transactionFee}>
                    +{formatCurrency(transaction.platform_fee)} fee
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Quick Actions */}
        <View style={styles.sectionHeader}>
          <Ionicons name="flash" size={20} color={colors.textPrimary} />
          <Text style={styles.sectionTitle}>Quick Actions</Text>
        </View>
        <View style={styles.actionsGrid}>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="people" size={24} color={colors.primary} />
            <Text style={styles.actionText}>View Creators</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="megaphone" size={24} color={colors.accent} />
            <Text style={styles.actionText}>Manage Ads</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="flag" size={24} color={colors.warning} />
            <Text style={styles.actionText}>View Reports</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="settings" size={24} color={colors.textSecondary} />
            <Text style={styles.actionText}>Settings</Text>
          </TouchableOpacity>
        </View>

        {/* Footer spacer */}
        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  totalIncomeCard: {
    backgroundColor: colors.primary,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  totalIncomeLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
  },
  totalIncomeAmount: {
    color: '#fff',
    fontSize: 36,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  incomeBreakdown: {
    flexDirection: 'row',
    marginTop: 12,
  },
  incomeItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  incomeItemLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
  },
  incomeItemValue: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  incomeDivider: {
    width: 1,
    backgroundColor: 'rgba(255,255,255,0.3)',
    marginHorizontal: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  overviewGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  overviewCard: {
    width: (width - 56) / 3,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  overviewValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  overviewLabel: {
    fontSize: 10,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  userStatCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  userStatIcon: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  userStatValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  userStatLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginTop: 4,
  },
  transactionsCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  noTransactions: {
    textAlign: 'center',
    color: colors.textTertiary,
    paddingVertical: 20,
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  transactionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
  transactionInfo: {
    flex: 1,
    marginLeft: 12,
  },
  transactionType: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  transactionDate: {
    fontSize: 12,
    color: colors.textTertiary,
    marginTop: 2,
  },
  transactionAmounts: {
    alignItems: 'flex-end',
  },
  transactionTotal: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  transactionFee: {
    fontSize: 11,
    color: colors.success,
    marginTop: 2,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionButton: {
    width: (width - 44) / 2,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  actionText: {
    fontSize: 13,
    color: colors.textPrimary,
    marginTop: 8,
  },
});
