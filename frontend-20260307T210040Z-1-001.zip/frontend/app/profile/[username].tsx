import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  FlatList,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { usersAPI, postsAPI, messagesAPI } from '../../src/services/api';
import { useAuth } from '../../src/contexts/AuthContext';

const { width } = Dimensions.get('window');
const imageSize = (width - 4) / 3;

interface UserProfile {
  id: string;
  username: string;
  display_name: string;
  bio: string;
  avatar: string | null;
  followers_count: number;
  following_count: number;
  posts_count: number;
  is_premium_creator: boolean;
  subscription_price: number;
}

interface Post {
  id: string;
  media: string | null;
  content: string;
  likes_count: number;
  is_premium: boolean;
  is_accessible: boolean;
}

export default function UserProfileScreen() {
  const { username } = useLocalSearchParams<{ username: string }>();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [subscriptionPrice, setSubscriptionPrice] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isFollowLoading, setIsFollowLoading] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);
  const [tipAmount, setTipAmount] = useState('5');
  const [tipMessage, setTipMessage] = useState('');
  const [isSendingTip, setIsSendingTip] = useState(false);
  const { user } = useAuth();
  const router = useRouter();

  const isOwnProfile = user?.username === username;

  useEffect(() => {
    fetchProfile();
  }, [username]);

  const fetchProfile = async () => {
    try {
      const profileResponse = await usersAPI.getProfile(username!);
      setProfile(profileResponse.data);

      const postsResponse = await postsAPI.getUserPosts(profileResponse.data.id);
      setPosts(postsResponse.data);

      if (user && !isOwnProfile) {
        const followResponse = await usersAPI.getFollowStatus(profileResponse.data.id);
        setIsFollowing(followResponse.data.is_following);

        if (profileResponse.data.is_premium_creator) {
          const subResponse = await usersAPI.getSubscriptionStatus(profileResponse.data.id);
          setIsSubscribed(subResponse.data.is_subscribed);
          setSubscriptionPrice(subResponse.data.price);
        }
      }
    } catch (error) {
      console.log('Fetch profile error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchProfile();
    setIsRefreshing(false);
  };

  const handleFollow = async () => {
    if (!profile || isFollowLoading) return;

    setIsFollowLoading(true);
    try {
      if (isFollowing) {
        await usersAPI.unfollow(profile.id);
        setIsFollowing(false);
        setProfile(prev => prev ? { ...prev, followers_count: prev.followers_count - 1 } : null);
      } else {
        await usersAPI.follow(profile.id);
        setIsFollowing(true);
        setProfile(prev => prev ? { ...prev, followers_count: prev.followers_count + 1 } : null);
      }
    } catch (error) {
      console.log('Follow error:', error);
    } finally {
      setIsFollowLoading(false);
    }
  };

  const handleSubscribe = async () => {
    if (!profile) return;
    
    try {
      if (isSubscribed) {
        await usersAPI.cancelSubscription(profile.id);
        setIsSubscribed(false);
        Alert.alert('Unsubscribed', 'Your subscription has been cancelled');
      } else {
        await usersAPI.subscribe(profile.id);
        setIsSubscribed(true);
        Alert.alert('Subscribed!', `You are now subscribed to ${profile.display_name}'s premium content! (MOCKED)`);
        // Refresh posts to show premium content
        const postsResponse = await postsAPI.getUserPosts(profile.id);
        setPosts(postsResponse.data);
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to process subscription');
    }
  };

  const handleSendTip = async () => {
    if (!profile) return;
    
    const amount = parseFloat(tipAmount);
    if (isNaN(amount) || amount < 1) {
      Alert.alert('Error', 'Please enter a valid amount (minimum $1)');
      return;
    }

    setIsSendingTip(true);
    try {
      await usersAPI.sendTip(profile.id, amount, tipMessage);
      setShowTipModal(false);
      setTipAmount('5');
      setTipMessage('');
      Alert.alert('Tip Sent!', `You sent $${amount.toFixed(2)} to ${profile.display_name}! (MOCKED)`);
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to send tip');
    } finally {
      setIsSendingTip(false);
    }
  };

  const handleMessage = async () => {
    if (!profile) return;
    
    try {
      const response = await messagesAPI.createOrGetConversation(profile.id);
      router.push(`/messages/${response.data.id}`);
    } catch (error) {
      console.log('Create conversation error:', error);
    }
  };

  const renderPostItem = ({ item }: { item: Post }) => (
    <TouchableOpacity
      style={styles.postItem}
      onPress={() => router.push(`/post/${item.id}`)}
    >
      {item.is_accessible && item.media ? (
        <Image source={{ uri: item.media }} style={styles.postImage} />
      ) : item.is_premium && !item.is_accessible ? (
        <View style={styles.lockedPost}>
          <Ionicons name="lock-closed" size={24} color="#FF3B5C" />
          <Text style={styles.lockedText}>Premium</Text>
        </View>
      ) : (
        <View style={styles.textPostItem}>
          <Text style={styles.textPostContent} numberOfLines={4}>
            {item.content}
          </Text>
        </View>
      )}
      {item.is_premium && (
        <View style={styles.premiumBadge}>
          <Ionicons name="star" size={10} color="#FFD700" />
        </View>
      )}
      <View style={styles.postOverlay}>
        <View style={styles.postStat}>
          <Ionicons name="heart" size={14} color="#fff" />
          <Text style={styles.postStatText}>{item.likes_count}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF3B5C" />
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Ionicons name="person-outline" size={64} color="#666" />
          <Text style={styles.errorText}>User not found</Text>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerUsername}>@{profile.username}</Text>
        <TouchableOpacity>
          <Ionicons name="ellipsis-horizontal" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={renderPostItem}
        numColumns={3}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor="#FF3B5C"
          />
        }
        ListHeaderComponent={
          <View style={styles.profileSection}>
            {/* Avatar */}
            {profile.avatar ? (
              <Image source={{ uri: profile.avatar }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={40} color="#666" />
              </View>
            )}

            <Text style={styles.displayName}>{profile.display_name}</Text>
            {profile.bio ? <Text style={styles.bio}>{profile.bio}</Text> : null}

            {/* Stats */}
            <View style={styles.statsRow}>
              <View style={styles.stat}>
                <Text style={styles.statNumber}>{profile.posts_count}</Text>
                <Text style={styles.statLabel}>Posts</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statNumber}>{profile.followers_count}</Text>
                <Text style={styles.statLabel}>Followers</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statNumber}>{profile.following_count}</Text>
                <Text style={styles.statLabel}>Following</Text>
              </View>
            </View>

            {/* Action Buttons */}
            {!isOwnProfile && (
              <View style={styles.actionButtons}>
                <TouchableOpacity
                  style={[styles.followButton, isFollowing && styles.followingButton]}
                  onPress={handleFollow}
                  disabled={isFollowLoading}
                >
                  {isFollowLoading ? (
                    <ActivityIndicator size="small" color={isFollowing ? '#888' : '#fff'} />
                  ) : (
                    <Text style={[styles.followButtonText, isFollowing && styles.followingButtonText]}>
                      {isFollowing ? 'Following' : 'Follow'}
                    </Text>
                  )}
                </TouchableOpacity>
                <TouchableOpacity style={styles.messageButton} onPress={handleMessage}>
                  <Ionicons name="chatbubble-outline" size={20} color="#fff" />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.tipButton}
                  onPress={() => setShowTipModal(true)}
                >
                  <Ionicons name="cash-outline" size={20} color="#2ECC71" />
                </TouchableOpacity>
              </View>
            )}

            {/* Premium Creator Section */}
            {profile.is_premium_creator && (
              <View style={styles.premiumSection}>
                <View style={styles.premiumBadgeRow}>
                  <Ionicons name="star" size={16} color="#FFD700" />
                  <Text style={styles.premiumText}>Premium Creator</Text>
                </View>
                
                {!isOwnProfile && (
                  <TouchableOpacity
                    style={[
                      styles.subscribeButton,
                      isSubscribed && styles.subscribedButton
                    ]}
                    onPress={handleSubscribe}
                  >
                    <Ionicons 
                      name={isSubscribed ? 'checkmark-circle' : 'lock-closed'} 
                      size={18} 
                      color={isSubscribed ? '#000' : '#000'} 
                    />
                    <Text style={styles.subscribeButtonText}>
                      {isSubscribed 
                        ? 'Subscribed' 
                        : `Subscribe $${profile.subscription_price?.toFixed(2)}/mo`}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            )}

            {/* Posts Tab */}
            <View style={styles.postsTabs}>
              <TouchableOpacity style={[styles.postsTab, styles.postsTabActive]}>
                <Ionicons name="grid" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        }
        ListEmptyComponent={
          <View style={styles.emptyPosts}>
            <Ionicons name="camera-outline" size={48} color="#333" />
            <Text style={styles.emptyPostsTitle}>No posts yet</Text>
          </View>
        }
        contentContainerStyle={styles.postsGrid}
      />

      {/* Tip Modal */}
      <Modal
        visible={showTipModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowTipModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Send a Tip</Text>
              <TouchableOpacity onPress={() => setShowTipModal(false)}>
                <Ionicons name="close" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              <View style={styles.tipRecipient}>
                {profile.avatar ? (
                  <Image source={{ uri: profile.avatar }} style={styles.tipAvatar} />
                ) : (
                  <View style={styles.tipAvatarPlaceholder}>
                    <Ionicons name="person" size={20} color="#666" />
                  </View>
                )}
                <Text style={styles.tipRecipientName}>{profile.display_name}</Text>
              </View>
              
              <View style={styles.tipAmountContainer}>
                <Text style={styles.tipAmountLabel}>Amount</Text>
                <View style={styles.tipAmountRow}>
                  <Text style={styles.tipCurrency}>$</Text>
                  <TextInput
                    style={styles.tipAmountInput}
                    value={tipAmount}
                    onChangeText={setTipAmount}
                    keyboardType="decimal-pad"
                    placeholder="5.00"
                    placeholderTextColor="#666"
                  />
                </View>
              </View>
              
              <View style={styles.quickTips}>
                {['5', '10', '20', '50'].map((amount) => (
                  <TouchableOpacity
                    key={amount}
                    style={[
                      styles.quickTipButton,
                      tipAmount === amount && styles.quickTipButtonActive
                    ]}
                    onPress={() => setTipAmount(amount)}
                  >
                    <Text style={[
                      styles.quickTipText,
                      tipAmount === amount && styles.quickTipTextActive
                    ]}>${amount}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              
              <TextInput
                style={styles.tipMessageInput}
                value={tipMessage}
                onChangeText={setTipMessage}
                placeholder="Add a message (optional)"
                placeholderTextColor="#666"
                multiline
                maxLength={200}
              />
              
              <TouchableOpacity
                style={styles.sendTipButton}
                onPress={handleSendTip}
                disabled={isSendingTip}
              >
                {isSendingTip ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Ionicons name="cash" size={20} color="#fff" />
                    <Text style={styles.sendTipButtonText}>Send Tip</Text>
                  </>
                )}
              </TouchableOpacity>
              
              <Text style={styles.mockNote}>Note: Payments are MOCKED for this MVP</Text>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    color: '#888',
    fontSize: 18,
    marginTop: 16,
  },
  backBtn: {
    marginTop: 24,
    backgroundColor: '#FF3B5C',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  backBtnText: {
    color: '#fff',
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  headerUsername: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 48,
  },
  avatarPlaceholder: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
  },
  displayName: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '600',
    marginTop: 12,
  },
  bio: {
    color: '#888',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 32,
  },
  statsRow: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 40,
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  statLabel: {
    color: '#888',
    fontSize: 13,
    marginTop: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 10,
  },
  followButton: {
    flex: 1,
    backgroundColor: '#FF3B5C',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    minWidth: 100,
  },
  followingButton: {
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
  },
  followButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  followingButtonText: {
    color: '#888',
  },
  messageButton: {
    backgroundColor: '#1a1a1a',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
  tipButton: {
    backgroundColor: '#1a1a1a',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2ECC71',
  },
  premiumSection: {
    alignItems: 'center',
    marginTop: 16,
    width: '100%',
  },
  premiumBadgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 215, 0, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
  },
  premiumText: {
    color: '#FFD700',
    fontSize: 13,
    fontWeight: '600',
  },
  subscribeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFD700',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginTop: 12,
    gap: 6,
  },
  subscribedButton: {
    backgroundColor: '#2ECC71',
  },
  subscribeButtonText: {
    color: '#000',
    fontWeight: '600',
    fontSize: 14,
  },
  postsTabs: {
    flexDirection: 'row',
    width: '100%',
    borderTopWidth: 1,
    borderTopColor: '#1a1a1a',
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
    marginTop: 20,
  },
  postsTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
  },
  postsTabActive: {
    borderBottomWidth: 1,
    borderBottomColor: '#fff',
  },
  postsGrid: {
    gap: 2,
  },
  postItem: {
    width: imageSize,
    height: imageSize,
    margin: 1,
  },
  postImage: {
    width: '100%',
    height: '100%',
  },
  textPostItem: {
    width: '100%',
    height: '100%',
    backgroundColor: '#1a1a1a',
    padding: 8,
    justifyContent: 'center',
  },
  textPostContent: {
    color: '#fff',
    fontSize: 12,
  },
  lockedPost: {
    width: '100%',
    height: '100%',
    backgroundColor: '#1a1a1a',
    justifyContent: 'center',
    alignItems: 'center',
  },
  lockedText: {
    color: '#FF3B5C',
    fontSize: 10,
    marginTop: 4,
  },
  premiumBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 8,
    padding: 3,
  },
  postOverlay: {
    position: 'absolute',
    bottom: 4,
    left: 4,
    flexDirection: 'row',
  },
  postStat: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  postStatText: {
    color: '#fff',
    fontSize: 11,
    marginLeft: 4,
  },
  emptyPosts: {
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 40,
  },
  emptyPostsTitle: {
    color: '#888',
    fontSize: 16,
    marginTop: 16,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#1a1a1a',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  modalTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  modalBody: {
    padding: 24,
    alignItems: 'center',
  },
  tipRecipient: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  tipAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  tipAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  tipRecipientName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  tipAmountContainer: {
    width: '100%',
    marginBottom: 16,
  },
  tipAmountLabel: {
    color: '#888',
    fontSize: 14,
    marginBottom: 8,
  },
  tipAmountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0a0a0a',
    borderRadius: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#333',
  },
  tipCurrency: {
    color: '#2ECC71',
    fontSize: 24,
    fontWeight: '600',
  },
  tipAmountInput: {
    flex: 1,
    color: '#fff',
    fontSize: 24,
    paddingVertical: 14,
    marginLeft: 8,
  },
  quickTips: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  quickTipButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: '#0a0a0a',
    borderWidth: 1,
    borderColor: '#333',
  },
  quickTipButtonActive: {
    backgroundColor: '#2ECC71',
    borderColor: '#2ECC71',
  },
  quickTipText: {
    color: '#888',
    fontSize: 14,
    fontWeight: '600',
  },
  quickTipTextActive: {
    color: '#000',
  },
  tipMessageInput: {
    width: '100%',
    backgroundColor: '#0a0a0a',
    borderRadius: 12,
    padding: 16,
    color: '#fff',
    fontSize: 14,
    borderWidth: 1,
    borderColor: '#333',
    marginBottom: 20,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  sendTipButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2ECC71',
    paddingVertical: 14,
    borderRadius: 24,
    width: '100%',
    gap: 8,
  },
  sendTipButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  mockNote: {
    color: '#FF3B5C',
    fontSize: 12,
    marginTop: 16,
  },
});
