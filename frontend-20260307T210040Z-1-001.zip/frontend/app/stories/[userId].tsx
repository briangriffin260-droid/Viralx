import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Dimensions,
  Animated,
  PanResponder,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { formatDistanceToNow } from 'date-fns';
import { storiesAPI } from '../../src/services/api';

const { width, height } = Dimensions.get('window');
const STORY_DURATION = 5000; // 5 seconds per story

interface Story {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  user_avatar: string | null;
  media: string;
  media_type: string;
  created_at: string;
  expires_at: string;
  views_count: number;
}

export default function StoryViewerScreen() {
  const { userId, stories: storiesParam } = useLocalSearchParams<{ userId: string; stories: string }>();
  const [stories, setStories] = useState<Story[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const router = useRouter();

  useEffect(() => {
    if (storiesParam) {
      try {
        const parsedStories = JSON.parse(storiesParam);
        setStories(parsedStories);
      } catch (e) {
        console.log('Parse error:', e);
      }
    }
  }, [storiesParam]);

  useEffect(() => {
    if (stories.length === 0) return;

    // Mark story as viewed
    const currentStory = stories[currentIndex];
    if (currentStory) {
      storiesAPI.viewStory(currentStory.id).catch(console.log);
    }

    // Animate progress bar
    progressAnim.setValue(0);
    const animation = Animated.timing(progressAnim, {
      toValue: 1,
      duration: STORY_DURATION,
      useNativeDriver: false,
    });

    animation.start(({ finished }) => {
      if (finished) {
        goToNext();
      }
    });

    return () => {
      animation.stop();
    };
  }, [currentIndex, stories]);

  const goToNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      router.back();
    }
  };

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handlePress = (event: any) => {
    const touchX = event.nativeEvent.locationX;
    if (touchX < width / 3) {
      goToPrevious();
    } else {
      goToNext();
    }
  };

  const getTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return '';
    }
  };

  if (stories.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <TouchableOpacity style={styles.closeButton} onPress={() => router.back()}>
          <Ionicons name="close" size={28} color="#fff" />
        </TouchableOpacity>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading stories...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const currentStory = stories[currentIndex];

  return (
    <View style={styles.container}>
      {/* Story Image */}
      <TouchableOpacity activeOpacity={1} onPress={handlePress} style={styles.storyContainer}>
        <Image
          source={{ uri: currentStory.media }}
          style={styles.storyImage}
          resizeMode="contain"
        />
      </TouchableOpacity>

      {/* Overlay */}
      <SafeAreaView style={styles.overlay} pointerEvents="box-none">
        {/* Progress Bars */}
        <View style={styles.progressContainer}>
          {stories.map((_, index) => (
            <View key={index} style={styles.progressBarBackground}>
              <Animated.View
                style={[
                  styles.progressBar,
                  {
                    width:
                      index < currentIndex
                        ? '100%'
                        : index === currentIndex
                        ? progressAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: ['0%', '100%'],
                          })
                        : '0%',
                  },
                ]}
              />
            </View>
          ))}
        </View>

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.userInfo}
            onPress={() => router.push(`/profile/${currentStory.username}`)}
          >
            {currentStory.user_avatar ? (
              <Image source={{ uri: currentStory.user_avatar }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={16} color="#666" />
              </View>
            )}
            <View>
              <Text style={styles.username}>{currentStory.display_name}</Text>
              <Text style={styles.time}>{getTimeAgo(currentStory.created_at)}</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => router.back()} style={styles.closeButton}>
            <Ionicons name="close" size={28} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Views count */}
        <View style={styles.footer}>
          <View style={styles.viewsContainer}>
            <Ionicons name="eye" size={20} color="#fff" />
            <Text style={styles.viewsText}>{currentStory.views_count} views</Text>
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  storyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  storyImage: {
    width: width,
    height: height,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'space-between',
  },
  progressContainer: {
    flexDirection: 'row',
    paddingHorizontal: 8,
    paddingTop: 8,
    gap: 4,
  },
  progressBarBackground: {
    flex: 1,
    height: 2,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 1,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 10,
    borderWidth: 2,
    borderColor: '#fff',
  },
  avatarPlaceholder: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  username: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  time: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
  },
  closeButton: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    fontSize: 16,
  },
  footer: {
    padding: 16,
  },
  viewsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewsText: {
    color: '#fff',
    fontSize: 14,
    marginLeft: 6,
  },
});
