import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/contexts/AuthContext';
import AsyncStorage from '@react-native-async-storage/async-storage';
import colors from '../src/theme/colors';

const AGE_VERIFIED_KEY = '@age_verified';

export default function Index() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [checkingAge, setCheckingAge] = useState(true);

  useEffect(() => {
    checkAgeVerification();
  }, []);

  const checkAgeVerification = async () => {
    try {
      const ageVerified = await AsyncStorage.getItem(AGE_VERIFIED_KEY);
      if (ageVerified !== 'true') {
        // User hasn't verified age yet, show age gate
        router.replace('/age-gate');
        return;
      }
      setCheckingAge(false);
    } catch (error) {
      console.log('Error checking age verification:', error);
      setCheckingAge(false);
    }
  };

  useEffect(() => {
    if (!checkingAge && !isLoading) {
      if (user) {
        router.replace('/(tabs)');
      } else {
        router.replace('/(auth)/login');
      }
    }
  }, [isLoading, user, checkingAge]);

  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
