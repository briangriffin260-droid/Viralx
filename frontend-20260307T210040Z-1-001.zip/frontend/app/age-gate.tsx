import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import colors from '../src/theme/colors';

const AGE_VERIFIED_KEY = '@age_verified';

export default function AgeGateScreen() {
  const router = useRouter();

  const handleConfirmAge = async () => {
    try {
      await AsyncStorage.setItem(AGE_VERIFIED_KEY, 'true');
      router.replace('/');
    } catch (error) {
      console.log('Error saving age verification:', error);
    }
  };

  const handleDeny = () => {
    // Show a message or close the app
    // For web, we can redirect to a safe page
    router.replace('/age-denied');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Logo */}
        <View style={styles.logoContainer}>
          <View style={styles.logoCircle}>
            <Ionicons name="planet" size={60} color={colors.primary} />
          </View>
          <Text style={styles.appName}>AllTogether</Text>
        </View>

        {/* Age Verification Card */}
        <View style={styles.card}>
          <View style={styles.warningIcon}>
            <Ionicons name="warning" size={40} color={colors.accent} />
          </View>
          
          <Text style={styles.title}>Age Verification Required</Text>
          
          <Text style={styles.description}>
            This app contains content that may not be suitable for all audiences. 
            Some features include premium creator content.
          </Text>
          
          <Text style={styles.question}>
            Are you 18 years of age or older?
          </Text>

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.confirmButton}
              onPress={handleConfirmAge}
              testID="age-confirm-button"
            >
              <Ionicons name="checkmark-circle" size={22} color="#fff" />
              <Text style={styles.confirmButtonText}>Yes, I'm 18+</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.denyButton}
              onPress={handleDeny}
            >
              <Ionicons name="close-circle" size={22} color={colors.textSecondary} />
              <Text style={styles.denyButtonText}>No, I'm under 18</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.disclaimer}>
            By clicking "Yes, I'm 18+", you confirm that you are of legal age 
            to view adult content in your jurisdiction.
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  appName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    elevation: 6,
  },
  warningIcon: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'rgba(224, 122, 95, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 12,
  },
  description: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  question: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 24,
  },
  buttonContainer: {
    width: '100%',
    gap: 12,
  },
  confirmButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  confirmButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  denyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.backgroundAlt,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  denyButtonText: {
    color: colors.textSecondary,
    fontSize: 16,
    fontWeight: '600',
  },
  disclaimer: {
    fontSize: 11,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: 20,
    lineHeight: 16,
  },
});
