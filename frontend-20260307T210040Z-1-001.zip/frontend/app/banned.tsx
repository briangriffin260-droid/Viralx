import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { reportsAPI } from '../src/services/api';
import { useAuth } from '../src/contexts/AuthContext';
import colors from '../src/theme/colors';

export default function BannedScreen() {
  const [banInfo, setBanInfo] = useState<any>(null);
  const { logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    fetchBanStatus();
  }, []);

  const fetchBanStatus = async () => {
    try {
      const response = await reportsAPI.getBanStatus();
      setBanInfo(response.data);
    } catch (error) {
      console.log('Ban status error:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
    router.replace('/(auth)/login');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Icon */}
        <View style={styles.iconContainer}>
          <Ionicons name="ban" size={80} color={colors.accent} />
        </View>

        {/* Title */}
        <Text style={styles.title}>Account Suspended</Text>

        {/* Message */}
        <Text style={styles.message}>
          Your account has been temporarily suspended due to violations of our community guidelines.
        </Text>

        {/* Ban Details */}
        {banInfo && (
          <View style={styles.detailsCard}>
            <View style={styles.detailRow}>
              <Ionicons name="alert-circle" size={20} color={colors.accent} />
              <View style={styles.detailContent}>
                <Text style={styles.detailLabel}>Reason</Text>
                <Text style={styles.detailValue}>{banInfo.reason}</Text>
              </View>
            </View>

            <View style={styles.divider} />

            <View style={styles.detailRow}>
              <Ionicons name="calendar" size={20} color={colors.textSecondary} />
              <View style={styles.detailContent}>
                <Text style={styles.detailLabel}>Banned On</Text>
                <Text style={styles.detailValue}>{formatDate(banInfo.banned_at)}</Text>
              </View>
            </View>

            <View style={styles.divider} />

            <View style={styles.detailRow}>
              <Ionicons name="time" size={20} color={colors.primary} />
              <View style={styles.detailContent}>
                <Text style={styles.detailLabel}>Access Restored On</Text>
                <Text style={styles.detailValue}>{formatDate(banInfo.expires_at)}</Text>
              </View>
            </View>

            {banInfo.days_remaining > 0 && (
              <>
                <View style={styles.divider} />
                <View style={styles.countdownContainer}>
                  <Text style={styles.countdownNumber}>{banInfo.days_remaining}</Text>
                  <Text style={styles.countdownLabel}>days remaining</Text>
                </View>
              </>
            )}
          </View>
        )}

        {/* Guidelines */}
        <View style={styles.guidelinesCard}>
          <Text style={styles.guidelinesTitle}>Community Guidelines</Text>
          <Text style={styles.guidelinesText}>
            To prevent future suspensions, please:
          </Text>
          <View style={styles.guidelineItem}>
            <Ionicons name="checkmark-circle" size={18} color={colors.success} />
            <Text style={styles.guidelineText}>Be respectful to creators and other users</Text>
          </View>
          <View style={styles.guidelineItem}>
            <Ionicons name="checkmark-circle" size={18} color={colors.success} />
            <Text style={styles.guidelineText}>Avoid harassment, hate speech, and threats</Text>
          </View>
          <View style={styles.guidelineItem}>
            <Ionicons name="checkmark-circle" size={18} color={colors.success} />
            <Text style={styles.guidelineText}>Keep conversations civil and constructive</Text>
          </View>
        </View>

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color={colors.textSecondary} />
          <Text style={styles.logoutButtonText}>Log Out</Text>
        </TouchableOpacity>

        {/* Appeal Note */}
        <Text style={styles.appealNote}>
          If you believe this was a mistake, you can appeal by contacting support.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: `${colors.accent}15`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 12,
    textAlign: 'center',
  },
  message: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  detailsCard: {
    width: '100%',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: colors.border,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  detailContent: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 12,
    color: colors.textTertiary,
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 15,
    color: colors.textPrimary,
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 12,
  },
  countdownContainer: {
    alignItems: 'center',
    paddingTop: 8,
  },
  countdownNumber: {
    fontSize: 48,
    fontWeight: 'bold',
    color: colors.accent,
  },
  countdownLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  guidelinesCard: {
    width: '100%',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.border,
  },
  guidelinesTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 8,
  },
  guidelinesText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 12,
  },
  guidelineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  guidelineText: {
    flex: 1,
    fontSize: 14,
    color: colors.textSecondary,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  logoutButtonText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  appealNote: {
    fontSize: 12,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: 20,
  },
});
