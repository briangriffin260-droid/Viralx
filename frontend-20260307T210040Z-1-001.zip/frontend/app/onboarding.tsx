import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  FlatList,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import colors from '../src/theme/colors';

const { width, height } = Dimensions.get('window');

const ONBOARDING_KEY = '@onboarding_complete';

interface OnboardingSlide {
  id: string;
  icon: string;
  iconColor: string;
  title: string;
  description: string;
  features?: string[];
}

const slides: OnboardingSlide[] = [
  {
    id: '1',
    icon: 'planet',
    iconColor: colors.primary,
    title: 'Welcome to AllTogether!',
    description: 'The ultimate social platform combining the best features from your favorite apps.',
    features: [
      'Share posts, photos & videos',
      'Connect with creators',
      'Discover trending content',
    ],
  },
  {
    id: '2',
    icon: 'home',
    iconColor: colors.primary,
    title: 'Your Home Feed',
    description: 'See posts from people you follow and discover new content.',
    features: [
      '"For You" - Personalized recommendations',
      '"Following" - Posts from people you follow',
      'Like, comment, and share posts',
    ],
  },
  {
    id: '3',
    icon: 'add-circle',
    iconColor: colors.accent,
    title: 'Stories',
    description: 'Share moments that disappear after 24 hours.',
    features: [
      'Tap the + on your avatar to add a story',
      'View stories at the top of your feed',
      'Stories vanish after 24 hours',
    ],
  },
  {
    id: '4',
    icon: 'play-circle',
    iconColor: '#FF2D55',
    title: 'Short Videos (Reels)',
    description: 'TikTok-style vertical video feed for endless entertainment.',
    features: [
      'Swipe up for the next video',
      'Like and comment on videos',
      'Create your own short videos',
    ],
  },
  {
    id: '5',
    icon: 'search',
    iconColor: colors.primary,
    title: 'Explore & Discover',
    description: 'Find new people, trending content, and premium creators.',
    features: [
      'Search for users by name',
      'Browse trending posts',
      'Discover premium creators',
    ],
  },
  {
    id: '6',
    icon: 'chatbubbles',
    iconColor: colors.success,
    title: 'Direct Messages',
    description: 'Private conversations with other users.',
    features: [
      'Send text and photos',
      'Tap the chat icon from home',
      'Message any user directly',
    ],
  },
  {
    id: '7',
    icon: 'star',
    iconColor: colors.premium,
    title: 'Premium Creators',
    description: 'Support your favorite creators with subscriptions and tips.',
    features: [
      'Subscribe for exclusive content',
      'Send tips to show appreciation',
      'Creators earn 85% of payments',
    ],
  },
  {
    id: '8',
    icon: 'cash',
    iconColor: colors.success,
    title: 'Become a Creator',
    description: 'Earn money by sharing premium content!',
    features: [
      'Set your subscription price',
      'Post exclusive content for subscribers',
      'Receive tips from fans',
      'Get paid via Stripe',
    ],
  },
  {
    id: '9',
    icon: 'person-circle',
    iconColor: colors.primary,
    title: 'Your Profile',
    description: 'Manage your account and see your stats.',
    features: [
      'Edit your bio and avatar',
      'View your posts and followers',
      'Track your earnings (creators)',
      'Access settings and more',
    ],
  },
  {
    id: '10',
    icon: 'rocket',
    iconColor: colors.accent,
    title: "You're All Set!",
    description: "Start exploring and connecting with the community!",
    features: [
      '✓ Follow creators you like',
      '✓ Post your first content',
      '✓ Engage with the community',
      '✓ Have fun!',
    ],
  },
];

interface OnboardingScreenProps {
  onComplete?: () => void;
}

export default function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const scrollX = useRef(new Animated.Value(0)).current;
  const router = useRouter();

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
      setCurrentIndex(currentIndex + 1);
    } else {
      completeOnboarding();
    }
  };

  const handleSkip = () => {
    completeOnboarding();
  };

  const completeOnboarding = async () => {
    try {
      await AsyncStorage.setItem(ONBOARDING_KEY, 'true');
    } catch (error) {
      console.log('Error saving onboarding status:', error);
    }
    if (onComplete) {
      onComplete();
    } else {
      // Navigate to main app
      router.replace('/(tabs)');
    }
  };

  const handleScroll = (event: any) => {
    const offsetX = event.nativeEvent.contentOffset.x;
    const index = Math.round(offsetX / width);
    setCurrentIndex(index);
  };

  const renderSlide = ({ item }: { item: OnboardingSlide }) => (
    <View style={styles.slide}>
      {/* Icon */}
      <View style={[styles.iconContainer, { backgroundColor: `${item.iconColor}15` }]}>
        <Ionicons name={item.icon as any} size={80} color={item.iconColor} />
      </View>

      {/* Title */}
      <Text style={styles.title}>{item.title}</Text>

      {/* Description */}
      <Text style={styles.description}>{item.description}</Text>

      {/* Features */}
      {item.features && (
        <View style={styles.featuresContainer}>
          {item.features.map((feature, index) => (
            <View key={index} style={styles.featureRow}>
              <Ionicons 
                name={feature.startsWith('✓') ? 'checkmark-circle' : 'chevron-forward-circle'} 
                size={20} 
                color={item.iconColor} 
              />
              <Text style={styles.featureText}>
                {feature.startsWith('✓') ? feature.substring(2) : feature}
              </Text>
            </View>
          ))}
        </View>
      )}
    </View>
  );

  const renderPagination = () => (
    <View style={styles.pagination}>
      {slides.map((_, index) => {
        const inputRange = [(index - 1) * width, index * width, (index + 1) * width];
        const dotWidth = scrollX.interpolate({
          inputRange,
          outputRange: [8, 24, 8],
          extrapolate: 'clamp',
        });
        const opacity = scrollX.interpolate({
          inputRange,
          outputRange: [0.3, 1, 0.3],
          extrapolate: 'clamp',
        });

        return (
          <Animated.View
            key={index}
            style={[
              styles.dot,
              {
                width: dotWidth,
                opacity,
                backgroundColor: colors.primary,
              },
            ]}
          />
        );
      })}
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Skip Button */}
      {currentIndex < slides.length - 1 && (
        <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      )}

      {/* Slides */}
      <Animated.FlatList
        ref={flatListRef}
        data={slides}
        keyExtractor={(item) => item.id}
        renderItem={renderSlide}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { x: scrollX } } }],
          { useNativeDriver: false }
        )}
        onMomentumScrollEnd={handleScroll}
        scrollEventThrottle={16}
      />

      {/* Pagination */}
      {renderPagination()}

      {/* Progress Text */}
      <Text style={styles.progressText}>
        {currentIndex + 1} of {slides.length}
      </Text>

      {/* Next/Get Started Button */}
      <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
        <Text style={styles.nextButtonText}>
          {currentIndex === slides.length - 1 ? "Get Started!" : "Next"}
        </Text>
        <Ionicons 
          name={currentIndex === slides.length - 1 ? "checkmark-circle" : "arrow-forward"} 
          size={20} 
          color="#fff" 
        />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

// Helper to check if onboarding is complete
export const checkOnboardingComplete = async (): Promise<boolean> => {
  try {
    const complete = await AsyncStorage.getItem(ONBOARDING_KEY);
    return complete === 'true';
  } catch {
    return false;
  }
};

// Helper to reset onboarding (for testing)
export const resetOnboarding = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(ONBOARDING_KEY);
  } catch (error) {
    console.log('Error resetting onboarding:', error);
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  skipButton: {
    position: 'absolute',
    top: 60,
    right: 20,
    zIndex: 10,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  skipText: {
    color: colors.textSecondary,
    fontSize: 16,
    fontWeight: '500',
  },
  slide: {
    width: width,
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingTop: 60,
  },
  iconContainer: {
    width: 160,
    height: 160,
    borderRadius: 80,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  featuresContainer: {
    width: '100%',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.border,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  featureText: {
    flex: 1,
    fontSize: 15,
    color: colors.textPrimary,
    lineHeight: 22,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
  },
  dot: {
    height: 8,
    borderRadius: 4,
    marginHorizontal: 4,
  },
  progressText: {
    textAlign: 'center',
    color: colors.textTertiary,
    fontSize: 14,
    marginBottom: 16,
  },
  nextButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    marginHorizontal: 32,
    marginBottom: 32,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  nextButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});
