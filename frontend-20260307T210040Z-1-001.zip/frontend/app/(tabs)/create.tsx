import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../src/contexts/AuthContext';
import { postsAPI, storiesAPI } from '../../src/services/api';
import colors from '../../src/theme/colors';

export default function CreateScreen() {
  const [content, setContent] = useState('');
  const [media, setMedia] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [isLoading, setIsLoading] = useState(false);
  const [createType, setCreateType] = useState<'post' | 'story' | 'video'>('post');
  const [isPremium, setIsPremium] = useState(false);
  const { user } = useAuth();
  const router = useRouter();

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert('Permission Required', 'Please allow access to your photo library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: createType === 'video' 
        ? ImagePicker.MediaTypeOptions.Videos 
        : ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: createType === 'video' ? [9, 16] : [1, 1],
      quality: 0.7,
      base64: true,
      videoMaxDuration: 60,
    });

    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      if (asset.base64) {
        const mimeType = asset.type === 'video' ? 'video/mp4' : 'image/jpeg';
        const base64Data = `data:${mimeType};base64,${asset.base64}`;
        setMedia(base64Data);
        setMediaType(asset.type === 'video' ? 'video' : 'image');
      } else if (asset.uri) {
        setMedia(asset.uri);
        setMediaType('video');
      }
    }
  };

  const takePhoto = async () => {
    const permissionResult = await ImagePicker.requestCameraPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert('Permission Required', 'Please allow access to your camera');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: createType === 'video' ? [9, 16] : [1, 1],
      quality: 0.7,
      base64: true,
      mediaTypes: createType === 'video'
        ? ImagePicker.MediaTypeOptions.Videos
        : ImagePicker.MediaTypeOptions.Images,
      videoMaxDuration: 60,
    });

    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      if (asset.base64) {
        const mimeType = asset.type === 'video' ? 'video/mp4' : 'image/jpeg';
        const base64Data = `data:${mimeType};base64,${asset.base64}`;
        setMedia(base64Data);
        setMediaType(asset.type === 'video' ? 'video' : 'image');
      }
    }
  };

  const handleCreate = async () => {
    if (createType === 'post' && !content.trim() && !media) {
      Alert.alert('Error', 'Please add some content or media');
      return;
    }

    if ((createType === 'story' || createType === 'video') && !media) {
      Alert.alert('Error', `Please add ${createType === 'video' ? 'a video' : 'media'} for your ${createType}`);
      return;
    }

    setIsLoading(true);
    try {
      if (createType === 'story') {
        await storiesAPI.createStory({
          media: media!,
          media_type: mediaType,
        });
        Alert.alert('Success', 'Story created successfully!');
      } else {
        await postsAPI.createPost({
          content: content.trim(),
          media: media || undefined,
          media_type: createType === 'video' ? 'video' : mediaType,
          is_premium: isPremium && user?.is_premium_creator,
        });
        Alert.alert('Success', `${createType === 'video' ? 'Video' : 'Post'} created successfully!`);
      }
      
      setContent('');
      setMedia(null);
      setIsPremium(false);
      router.back();
    } catch (error: any) {
      const message = error.response?.data?.detail || 'Failed to create';
      Alert.alert('Error', message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="close" size={28} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Create</Text>
          <TouchableOpacity
            style={[styles.shareButton, isLoading && styles.shareButtonDisabled]}
            onPress={handleCreate}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text style={styles.shareButtonText}>Share</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Type Selector */}
        <View style={styles.typeSelector}>
          <TouchableOpacity
            style={[styles.typeButton, createType === 'post' && styles.typeButtonActive]}
            onPress={() => setCreateType('post')}
          >
            <Ionicons
              name="newspaper"
              size={18}
              color={createType === 'post' ? colors.primary : colors.textTertiary}
            />
            <Text style={[styles.typeText, createType === 'post' && styles.typeTextActive]}>
              Post
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.typeButton, createType === 'story' && styles.typeButtonActive]}
            onPress={() => setCreateType('story')}
          >
            <Ionicons
              name="add-circle"
              size={18}
              color={createType === 'story' ? colors.primary : colors.textTertiary}
            />
            <Text style={[styles.typeText, createType === 'story' && styles.typeTextActive]}>
              Story
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.typeButton, createType === 'video' && styles.typeButtonActive]}
            onPress={() => setCreateType('video')}
          >
            <Ionicons
              name="videocam"
              size={18}
              color={createType === 'video' ? colors.primary : colors.textTertiary}
            />
            <Text style={[styles.typeText, createType === 'video' && styles.typeTextActive]}>
              Video
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} keyboardShouldPersistTaps="handled">
          {/* User Info */}
          <View style={styles.userRow}>
            {user?.avatar ? (
              <Image source={{ uri: user.avatar }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={20} color={colors.textTertiary} />
              </View>
            )}
            <View>
              <Text style={styles.displayName}>{user?.display_name}</Text>
              <Text style={styles.username}>@{user?.username}</Text>
            </View>
          </View>

          {/* Text Input (for posts and videos) */}
          {createType !== 'story' && (
            <TextInput
              style={styles.textInput}
              placeholder={createType === 'video' ? "Add a caption..." : "What's on your mind?"}
              placeholderTextColor={colors.textTertiary}
              multiline
              value={content}
              onChangeText={setContent}
              maxLength={500}
            />
          )}

          {/* Media Preview */}
          {media && (
            <View style={styles.mediaPreview}>
              <Image source={{ uri: media }} style={styles.mediaImage} />
              {mediaType === 'video' && (
                <View style={styles.videoIndicator}>
                  <Ionicons name="play-circle" size={48} color="#fff" />
                </View>
              )}
              <TouchableOpacity
                style={styles.removeMedia}
                onPress={() => setMedia(null)}
              >
                <Ionicons name="close-circle" size={28} color={colors.accent} />
              </TouchableOpacity>
            </View>
          )}

          {/* Media Actions */}
          <View style={styles.mediaActions}>
            <TouchableOpacity style={styles.mediaAction} onPress={pickImage}>
              <View style={styles.mediaActionIcon}>
                <Ionicons 
                  name={createType === 'video' ? 'film' : 'image'} 
                  size={24} 
                  color={colors.primary} 
                />
              </View>
              <Text style={styles.mediaActionText}>Gallery</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.mediaAction} onPress={takePhoto}>
              <View style={styles.mediaActionIcon}>
                <Ionicons 
                  name={createType === 'video' ? 'videocam' : 'camera'} 
                  size={24} 
                  color={colors.accent} 
                />
              </View>
              <Text style={styles.mediaActionText}>
                {createType === 'video' ? 'Record' : 'Camera'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Premium Content Toggle (for premium creators) */}
          {user?.is_premium_creator && createType !== 'story' && (
            <View style={styles.premiumToggle}>
              <View style={styles.premiumInfo}>
                <Ionicons name="star" size={20} color={colors.premium} />
                <View style={styles.premiumTextContainer}>
                  <Text style={styles.premiumTitle}>Premium Content</Text>
                  <Text style={styles.premiumSubtitle}>Only subscribers can view</Text>
                </View>
              </View>
              <Switch
                value={isPremium}
                onValueChange={setIsPremium}
                trackColor={{ false: colors.border, true: colors.accent }}
                thumbColor={isPremium ? '#fff' : colors.backgroundAlt}
              />
            </View>
          )}

          {createType === 'story' && (
            <View style={styles.storyInfo}>
              <Ionicons name="time-outline" size={20} color={colors.textSecondary} />
              <Text style={styles.storyInfoText}>
                Stories disappear after 24 hours
              </Text>
            </View>
          )}

          {createType === 'video' && (
            <View style={styles.storyInfo}>
              <Ionicons name="videocam-outline" size={20} color={colors.textSecondary} />
              <Text style={styles.storyInfoText}>
                Videos appear in the TikTok-style feed
              </Text>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: '600',
  },
  shareButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
  },
  shareButtonDisabled: {
    opacity: 0.7,
  },
  shareButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  typeSelector: {
    flexDirection: 'row',
    padding: 16,
    gap: 8,
    backgroundColor: colors.card,
  },
  typeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: colors.backgroundAlt,
    borderWidth: 1,
    borderColor: colors.border,
  },
  typeButtonActive: {
    backgroundColor: 'rgba(91, 138, 154, 0.1)',
    borderColor: colors.primary,
  },
  typeText: {
    color: colors.textTertiary,
    fontSize: 13,
    fontWeight: '600',
  },
  typeTextActive: {
    color: colors.primary,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  userRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 12,
  },
  avatarPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  displayName: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
  },
  username: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  textInput: {
    color: colors.textPrimary,
    fontSize: 18,
    lineHeight: 26,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  mediaPreview: {
    marginTop: 16,
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
  },
  mediaImage: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 12,
  },
  videoIndicator: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  removeMedia: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 14,
  },
  mediaActions: {
    flexDirection: 'row',
    marginTop: 24,
    gap: 16,
  },
  mediaAction: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  mediaActionIcon: {
    marginBottom: 8,
  },
  mediaActionText: {
    color: colors.textPrimary,
    fontSize: 14,
    fontWeight: '500',
  },
  premiumToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginTop: 24,
    borderWidth: 1,
    borderColor: colors.border,
  },
  premiumInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  premiumTextContainer: {
    marginLeft: 12,
  },
  premiumTitle: {
    color: colors.textPrimary,
    fontSize: 15,
    fontWeight: '600',
  },
  premiumSubtitle: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 2,
  },
  storyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
    gap: 8,
  },
  storyInfoText: {
    color: colors.textSecondary,
    fontSize: 14,
  },
});
