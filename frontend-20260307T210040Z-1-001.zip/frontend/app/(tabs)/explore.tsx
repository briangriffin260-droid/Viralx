import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { exploreAPI, postsAPI } from '../../src/services/api';
import PostCard from '../../src/components/PostCard';
import ContentWarning from '../../src/components/ContentWarning';
import colors from '../../src/theme/colors';

const CREATORS_WARNING_KEY = '@warning_dismissed_creators';

interface User {
  id: string;
  username: string;
  display_name: string;
  avatar: string | null;
  followers_count: number;
  is_premium_creator: boolean;
  subscription_price: number;
}

interface Post {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  user_avatar: string | null;
  content: string;
  media: string | null;
  media_type: string;
  is_premium: boolean;
  likes_count: number;
  comments_count: number;
  created_at: string;
  is_liked: boolean;
}

export default function ExploreScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'trending' | 'users' | 'creators'>('trending');
  const [users, setUsers] = useState<User[]>([]);
  const [creators, setCreators] = useState<User[]>([]);
  const [trendingPosts, setTrendingPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showCreatorWarning, setShowCreatorWarning] = useState(false);
  const [creatorsWarningDismissed, setCreatorsWarningDismissed] = useState(false);
  const router = useRouter();

  useEffect(() => {
    checkCreatorsWarningStatus();
  }, []);

  const checkCreatorsWarningStatus = async () => {
    try {
      const dismissed = await AsyncStorage.getItem(CREATORS_WARNING_KEY);
      setCreatorsWarningDismissed(dismissed === 'true');
    } catch (error) {
      console.log('Error checking creators warning:', error);
    }
  };

  const handleCreatorsTabPress = async () => {
    if (!creatorsWarningDismissed) {
      setShowCreatorWarning(true);
    } else {
      setActiveTab('creators');
    }
  };

  const handleCreatorWarningAccept = async () => {
    try {
      await AsyncStorage.setItem(CREATORS_WARNING_KEY, 'true');
      setCreatorsWarningDismissed(true);
    } catch (error) {
      console.log('Error saving warning preference:', error);
    }
    setShowCreatorWarning(false);
    setActiveTab('creators');
  };

  const handleCreatorWarningDecline = () => {
    setShowCreatorWarning(false);
  };

  useEffect(() => {
    if (activeTab === 'trending') {
      fetchTrending();
    } else if (activeTab === 'creators') {
      fetchCreators();
    }
  }, [activeTab]);

  useEffect(() => {
    if (searchQuery.length > 0 && activeTab === 'users') {
      searchUsers();
    } else if (searchQuery.length === 0 && activeTab === 'users') {
      fetchAllUsers();
    }
  }, [searchQuery, activeTab]);

  const fetchTrending = async () => {
    setIsLoading(true);
    try {
      const response = await exploreAPI.getTrending();
      setTrendingPosts(response.data);
    } catch (error) {
      console.log('Trending error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCreators = async () => {
    setIsLoading(true);
    try {
      const response = await exploreAPI.getCreators();
      setCreators(response.data);
    } catch (error) {
      console.log('Creators error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const searchUsers = async () => {
    setIsLoading(true);
    try {
      const response = await exploreAPI.searchUsers(searchQuery);
      setUsers(response.data);
    } catch (error) {
      console.log('Search error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAllUsers = async () => {
    setIsLoading(true);
    try {
      const response = await exploreAPI.searchUsers('');
      setUsers(response.data);
    } catch (error) {
      console.log('Fetch users error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderUserCard = ({ item }: { item: User }) => (
    <TouchableOpacity
      style={styles.userCard}
      onPress={() => router.push(`/profile/${item.username}`)}
    >
      {item.avatar ? (
        <Image source={{ uri: item.avatar }} style={styles.userAvatar} />
      ) : (
        <View style={styles.userAvatarPlaceholder}>
          <Ionicons name="person" size={24} color={colors.textTertiary} />
        </View>
      )}
      <View style={styles.userInfo}>
        <View style={styles.userNameRow}>
          <Text style={styles.userDisplayName}>{item.display_name}</Text>
          {item.is_premium_creator && (
            <Ionicons name="star" size={14} color={colors.premium} style={styles.premiumBadge} />
          )}
        </View>
        <Text style={styles.userUsername}>@{item.username}</Text>
        <Text style={styles.userFollowers}>{item.followers_count} followers</Text>
      </View>
      <TouchableOpacity style={styles.followButton}>
        <Text style={styles.followButtonText}>Follow</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const renderCreatorCard = ({ item }: { item: User }) => (
    <TouchableOpacity
      style={styles.creatorCard}
      onPress={() => router.push(`/profile/${item.username}`)}
    >
      {item.avatar ? (
        <Image source={{ uri: item.avatar }} style={styles.creatorAvatar} />
      ) : (
        <View style={styles.creatorAvatarPlaceholder}>
          <Ionicons name="person" size={32} color={colors.textTertiary} />
        </View>
      )}
      <View style={styles.creatorInfo}>
        <View style={styles.creatorNameRow}>
          <Text style={styles.creatorDisplayName}>{item.display_name}</Text>
          <Ionicons name="star" size={14} color={colors.premium} />
        </View>
        <Text style={styles.creatorUsername}>@{item.username}</Text>
        <Text style={styles.creatorFollowers}>{item.followers_count} followers</Text>
        <View style={styles.creatorPriceRow}>
          <Ionicons name="lock-closed" size={12} color={colors.accent} />
          <Text style={styles.creatorPrice}>
            ${item.subscription_price?.toFixed(2)}/month
          </Text>
        </View>
      </View>
      <TouchableOpacity style={styles.subscribeButton}>
        <Text style={styles.subscribeButtonText}>Subscribe</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color={colors.textTertiary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search users..."
            placeholderTextColor={colors.textTertiary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoCapitalize="none"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={20} color={colors.textTertiary} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'trending' && styles.tabActive]}
          onPress={() => setActiveTab('trending')}
        >
          <Ionicons
            name="flame"
            size={18}
            color={activeTab === 'trending' ? colors.accent : colors.textTertiary}
          />
          <Text style={[styles.tabText, activeTab === 'trending' && styles.tabTextActive]}>
            Trending
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'creators' && styles.tabActive]}
          onPress={handleCreatorsTabPress}
        >
          <Ionicons
            name="star"
            size={18}
            color={activeTab === 'creators' ? colors.premium : colors.textTertiary}
          />
          <Text style={[styles.tabText, activeTab === 'creators' && styles.tabTextActive]}>
            Creators
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'users' && styles.tabActive]}
          onPress={() => {
            setActiveTab('users');
            if (users.length === 0) fetchAllUsers();
          }}
        >
          <Ionicons
            name="people"
            size={18}
            color={activeTab === 'users' ? colors.primary : colors.textTertiary}
          />
          <Text style={[styles.tabText, activeTab === 'users' && styles.tabTextActive]}>
            Users
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : activeTab === 'trending' ? (
        <FlatList
          data={trendingPosts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <PostCard
              post={item}
              onPressUser={(username) => router.push(`/profile/${username}`)}
              onPressComments={(postId) => router.push(`/post/${postId}`)}
            />
          )}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="flame-outline" size={64} color={colors.border} />
              <Text style={styles.emptyTitle}>No trending posts yet</Text>
              <Text style={styles.emptySubtitle}>Be the first to create viral content!</Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      ) : activeTab === 'creators' ? (
        <FlatList
          data={creators}
          keyExtractor={(item) => item.id}
          renderItem={renderCreatorCard}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="star-outline" size={64} color={colors.premium} />
              <Text style={styles.emptyTitle}>No premium creators yet</Text>
              <Text style={styles.emptySubtitle}>Be the first to become a creator!</Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <FlatList
          data={users}
          keyExtractor={(item) => item.id}
          renderItem={renderUserCard}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="people-outline" size={64} color={colors.border} />
              <Text style={styles.emptyTitle}>No users found</Text>
              <Text style={styles.emptySubtitle}>Try a different search term</Text>
            </View>
          }
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Content Warning Modal for Creators */}
      <ContentWarning
        type="creator"
        visible={showCreatorWarning}
        onAccept={handleCreatorWarningAccept}
        onDecline={handleCreatorWarningDecline}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  searchContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: colors.textPrimary,
    fontSize: 16,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 6,
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  tabText: {
    color: colors.textTertiary,
    fontSize: 14,
    fontWeight: '600',
  },
  tabTextActive: {
    color: colors.textPrimary,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  userAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  userAvatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
  userInfo: {
    flex: 1,
    marginLeft: 12,
  },
  userNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userDisplayName: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
  },
  premiumBadge: {
    marginLeft: 4,
  },
  userUsername: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 2,
  },
  userFollowers: {
    color: colors.textTertiary,
    fontSize: 13,
    marginTop: 2,
  },
  followButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
  },
  followButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  // Creator Card Styles
  creatorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  creatorAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: colors.premium,
  },
  creatorAvatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.premium,
  },
  creatorInfo: {
    flex: 1,
    marginLeft: 12,
  },
  creatorNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  creatorDisplayName: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
  },
  creatorUsername: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 2,
  },
  creatorFollowers: {
    color: colors.textTertiary,
    fontSize: 13,
    marginTop: 2,
  },
  creatorPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  creatorPrice: {
    color: colors.accent,
    fontSize: 13,
    fontWeight: '600',
  },
  subscribeButton: {
    backgroundColor: colors.premium,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  subscribeButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
    paddingHorizontal: 40,
  },
  emptyTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
});
