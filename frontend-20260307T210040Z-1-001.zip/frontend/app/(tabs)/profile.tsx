import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  Dimensions,
  Alert,
  RefreshControl,
  Modal,
  TextInput,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../src/contexts/AuthContext';
import { postsAPI, authAPI, subscriptionsAPI } from '../../src/services/api';
import CreatorAgreementModal from '../../src/components/CreatorAgreementModal';
import colors from '../../src/theme/colors';

const { width } = Dimensions.get('window');
const imageSize = (width - 4) / 3;

interface Post {
  id: string;
  media: string | null;
  content: string;
  likes_count: number;
  comments_count: number;
  is_premium: boolean;
}

export default function ProfileScreen() {
  const { user, logout, updateUser, refreshUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showCreatorModal, setShowCreatorModal] = useState(false);
  const [showCreatorAgreement, setShowCreatorAgreement] = useState(false);
  const [showEarningsModal, setShowEarningsModal] = useState(false);
  const [subscriptionPrice, setSubscriptionPrice] = useState(user?.subscription_price?.toString() || '9.99');
  const [earnings, setEarnings] = useState<any>(null);
  const router = useRouter();

  const fetchPosts = async () => {
    if (!user) return;
    try {
      const response = await postsAPI.getUserPosts(user.id);
      setPosts(response.data);
    } catch (error) {
      console.log('Fetch posts error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchEarnings = async () => {
    try {
      const response = await subscriptionsAPI.getEarnings();
      setEarnings(response.data);
    } catch (error) {
      console.log('Earnings error:', error);
    }
  };

  useEffect(() => {
    fetchPosts();
    if (user?.is_premium_creator) {
      fetchEarnings();
    }
  }, [user]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([refreshUser(), fetchPosts()]);
    if (user?.is_premium_creator) {
      await fetchEarnings();
    }
    setIsRefreshing(false);
  };

  const handleChangeAvatar = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert('Permission Required', 'Please allow access to your photo library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
      base64: true,
    });

    if (!result.canceled && result.assets[0].base64) {
      const base64Image = `data:image/jpeg;base64,${result.assets[0].base64}`;
      try {
        await authAPI.updateProfile({ avatar: base64Image });
        updateUser({ avatar: base64Image });
        Alert.alert('Success', 'Profile photo updated!');
      } catch (error) {
        Alert.alert('Error', 'Failed to update profile photo');
      }
    }
  };

  const handleBecomeCreator = async () => {
    try {
      const price = parseFloat(subscriptionPrice);
      if (isNaN(price) || price < 1) {
        Alert.alert('Error', 'Please enter a valid price (minimum $1)');
        return;
      }
      
      // Close the price modal and show the agreement
      setShowCreatorModal(false);
      setShowCreatorAgreement(true);
    } catch (error) {
      Alert.alert('Error', 'Failed to become a creator');
    }
  };

  const handleCreatorAgreementAccept = async () => {
    try {
      const price = parseFloat(subscriptionPrice);
      await authAPI.updateProfile({ 
        is_premium_creator: true,
        subscription_price: price 
      });
      updateUser({ is_premium_creator: true, subscription_price: price });
      setShowCreatorAgreement(false);
      Alert.alert('🌟 Congratulations!', 'You are now a premium creator! Start posting exclusive content for your subscribers.');
    } catch (error) {
      Alert.alert('Error', 'Failed to activate creator mode');
    }
  };

  const handleCreatorAgreementDecline = () => {
    setShowCreatorAgreement(false);
    Alert.alert(
      'Agreement Required',
      'You must accept the Creator Agreement to become a premium creator.',
      [{ text: 'OK' }]
    );
  };

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await logout();
          router.replace('/(auth)/login');
        },
      },
    ]);
  };

  const renderPostItem = ({ item }: { item: Post }) => (
    <TouchableOpacity
      style={styles.postItem}
      onPress={() => router.push(`/post/${item.id}`)}
    >
      {item.media ? (
        <Image source={{ uri: item.media }} style={styles.postImage} />
      ) : (
        <View style={styles.textPostItem}>
          <Text style={styles.textPostContent} numberOfLines={4}>
            {item.content}
          </Text>
        </View>
      )}
      {item.is_premium && (
        <View style={styles.premiumPostBadge}>
          <Ionicons name="star" size={12} color={colors.premium} />
        </View>
      )}
      <View style={styles.postOverlay}>
        <View style={styles.postStat}>
          <Ionicons name="heart" size={14} color="#fff" />
          <Text style={styles.postStatText}>{item.likes_count}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (!user) return null;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.username}>@{user.username}</Text>
        <View style={styles.headerRight}>
          {/* Creator Dashboard Button */}
          {user.is_premium_creator && (
            <TouchableOpacity 
              style={styles.headerIcon}
              onPress={() => router.push('/creator-dashboard' as any)}
            >
              <Ionicons name="stats-chart" size={24} color={colors.premium} />
            </TouchableOpacity>
          )}
          {/* Wallet Button */}
          <TouchableOpacity 
            style={styles.headerIcon}
            onPress={() => router.push('/wallet' as any)}
          >
            <Ionicons name="wallet-outline" size={24} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerIcon}>
            <Ionicons name="menu" size={28} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Profile Info */}
        <View style={styles.profileSection}>
          <TouchableOpacity onPress={handleChangeAvatar}>
            {user.avatar ? (
              <Image source={{ uri: user.avatar }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={40} color={colors.textTertiary} />
              </View>
            )}
            <View style={styles.editAvatarBadge}>
              <Ionicons name="camera" size={14} color="#fff" />
            </View>
          </TouchableOpacity>

          <Text style={styles.displayName}>{user.display_name}</Text>
          {user.bio ? <Text style={styles.bio}>{user.bio}</Text> : null}

          {/* Stats */}
          <View style={styles.statsRow}>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>{user.posts_count}</Text>
              <Text style={styles.statLabel}>Posts</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>{user.followers_count}</Text>
              <Text style={styles.statLabel}>Followers</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statNumber}>{user.following_count}</Text>
              <Text style={styles.statLabel}>Following</Text>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.editButton}>
              <Text style={styles.editButtonText}>Edit Profile</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
              <Ionicons name="log-out-outline" size={20} color={colors.accent} />
            </TouchableOpacity>
          </View>

          {/* Premium Creator Section */}
          {user.is_premium_creator ? (
            <View style={styles.creatorSection}>
              <View style={styles.premiumBadge}>
                <Ionicons name="star" size={16} color={colors.premium} />
                <Text style={styles.premiumText}>Premium Creator</Text>
              </View>
              <Text style={styles.subscriptionPriceText}>
                ${user.subscription_price?.toFixed(2)}/month
              </Text>
            </View>
          ) : (
            <TouchableOpacity
              style={styles.becomeCreatorButton}
              onPress={() => setShowCreatorModal(true)}
            >
              <Ionicons name="star-outline" size={20} color={colors.premium} />
              <Text style={styles.becomeCreatorText}>Become a Premium Creator</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Posts Grid */}
        <View style={styles.postsSection}>
          <View style={styles.postsTabs}>
            <TouchableOpacity style={[styles.postsTab, styles.postsTabActive]}>
              <Ionicons name="grid" size={24} color={colors.textPrimary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.postsTab}>
              <Ionicons name="bookmark-outline" size={24} color={colors.textTertiary} />
            </TouchableOpacity>
          </View>

          {posts.length > 0 ? (
            <FlatList
              data={posts}
              keyExtractor={(item) => item.id}
              renderItem={renderPostItem}
              numColumns={3}
              scrollEnabled={false}
              contentContainerStyle={styles.postsGrid}
            />
          ) : (
            <View style={styles.emptyPosts}>
              <Ionicons name="camera-outline" size={48} color={colors.border} />
              <Text style={styles.emptyPostsTitle}>No posts yet</Text>
              <Text style={styles.emptyPostsSubtitle}>
                Share your first post with the world
              </Text>
              <TouchableOpacity
                style={styles.createFirstPost}
                onPress={() => router.push('/(tabs)/create')}
              >
                <Text style={styles.createFirstPostText}>Create Post</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>

      {/* Become Creator Modal */}
      <Modal
        visible={showCreatorModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCreatorModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Become a Premium Creator</Text>
              <TouchableOpacity onPress={() => setShowCreatorModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              <Ionicons name="star" size={48} color={colors.premium} style={styles.modalIcon} />
              <Text style={styles.modalDescription}>
                Earn money by creating exclusive content for your subscribers!
              </Text>
              
              <View style={styles.priceInput}>
                <Text style={styles.priceLabel}>Monthly Subscription Price</Text>
                <View style={styles.priceInputRow}>
                  <Text style={styles.currencySymbol}>$</Text>
                  <TextInput
                    style={styles.priceTextInput}
                    value={subscriptionPrice}
                    onChangeText={setSubscriptionPrice}
                    keyboardType="decimal-pad"
                    placeholder="9.99"
                    placeholderTextColor={colors.textTertiary}
                  />
                  <Text style={styles.perMonth}>/month</Text>
                </View>
              </View>

              <TouchableOpacity
                style={styles.activateButton}
                onPress={handleBecomeCreator}
              >
                <Text style={styles.activateButtonText}>Activate Creator Mode</Text>
              </TouchableOpacity>
              
              <Text style={styles.mockNote}>
                Note: Payments are MOCKED for this MVP
              </Text>
            </View>
          </View>
        </View>
      </Modal>

      {/* Earnings Modal */}
      <Modal
        visible={showEarningsModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowEarningsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Your Earnings</Text>
              <TouchableOpacity onPress={() => setShowEarningsModal(false)}>
                <Ionicons name="close" size={24} color={colors.textPrimary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              {earnings ? (
                <>
                  <View style={styles.earningsCard}>
                    <Text style={styles.earningsLabel}>Total Earnings</Text>
                    <Text style={styles.earningsAmount}>
                      ${earnings.total_earnings?.toFixed(2)}
                    </Text>
                  </View>
                  
                  <View style={styles.earningsRow}>
                    <View style={styles.earningsItem}>
                      <Ionicons name="star" size={24} color={colors.premium} />
                      <Text style={styles.earningsItemLabel}>Subscriptions</Text>
                      <Text style={styles.earningsItemValue}>{earnings.subscriptions_count}</Text>
                      <Text style={styles.earningsItemAmount}>
                        ${earnings.subscription_revenue?.toFixed(2)}
                      </Text>
                    </View>
                    <View style={styles.earningsItem}>
                      <Ionicons name="cash" size={24} color={colors.success} />
                      <Text style={styles.earningsItemLabel}>Tips</Text>
                      <Text style={styles.earningsItemValue}>Total</Text>
                      <Text style={styles.earningsItemAmount}>
                        ${earnings.tips_total?.toFixed(2)}
                      </Text>
                    </View>
                  </View>
                  
                  <Text style={styles.mockNote}>
                    {earnings.note}
                  </Text>
                </>
              ) : (
                <Text style={styles.noEarnings}>Loading earnings...</Text>
              )}
            </View>
          </View>
        </View>
      </Modal>

      {/* Creator Agreement Modal */}
      <CreatorAgreementModal
        visible={showCreatorAgreement}
        onAccept={handleCreatorAgreementAccept}
        onDecline={handleCreatorAgreementDecline}
        subscriptionPrice={subscriptionPrice}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  username: {
    color: colors.textPrimary,
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerRight: {
    flexDirection: 'row',
  },
  headerIcon: {
    marginLeft: 16,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: colors.card,
  },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 48,
  },
  avatarPlaceholder: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
  editAvatarBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.card,
  },
  displayName: {
    color: colors.textPrimary,
    fontSize: 20,
    fontWeight: '600',
    marginTop: 12,
  },
  bio: {
    color: colors.textSecondary,
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
    paddingHorizontal: 32,
  },
  statsRow: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 40,
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    color: colors.textPrimary,
    fontSize: 20,
    fontWeight: 'bold',
  },
  statLabel: {
    color: colors.textSecondary,
    fontSize: 13,
    marginTop: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 12,
  },
  editButton: {
    flex: 1,
    backgroundColor: colors.backgroundAlt,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  editButtonText: {
    color: colors.textPrimary,
    fontWeight: '600',
    fontSize: 14,
  },
  logoutButton: {
    backgroundColor: colors.backgroundAlt,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  creatorSection: {
    alignItems: 'center',
    marginTop: 16,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.premiumBg,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
  },
  premiumText: {
    color: colors.premium,
    fontSize: 13,
    fontWeight: '600',
  },
  subscriptionPriceText: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 4,
  },
  becomeCreatorButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.premiumBg,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 24,
    marginTop: 16,
    gap: 8,
    borderWidth: 1,
    borderColor: colors.premium,
  },
  becomeCreatorText: {
    color: colors.premium,
    fontSize: 14,
    fontWeight: '600',
  },
  postsSection: {
    flex: 1,
    marginTop: 8,
  },
  postsTabs: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  postsTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
  },
  postsTabActive: {
    borderBottomWidth: 2,
    borderBottomColor: colors.textPrimary,
  },
  postsGrid: {
    gap: 2,
  },
  postItem: {
    width: imageSize,
    height: imageSize,
    margin: 1,
  },
  postImage: {
    width: '100%',
    height: '100%',
  },
  textPostItem: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.backgroundAlt,
    padding: 8,
    justifyContent: 'center',
  },
  textPostContent: {
    color: colors.textPrimary,
    fontSize: 12,
  },
  premiumPostBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 10,
    padding: 4,
  },
  postOverlay: {
    position: 'absolute',
    bottom: 4,
    left: 4,
    flexDirection: 'row',
  },
  postStat: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  postStatText: {
    color: '#fff',
    fontSize: 11,
    marginLeft: 4,
  },
  emptyPosts: {
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 40,
    backgroundColor: colors.card,
  },
  emptyPostsTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  emptyPostsSubtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
  createFirstPost: {
    backgroundColor: colors.accent,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    marginTop: 20,
  },
  createFirstPostText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: '600',
  },
  modalBody: {
    padding: 24,
    alignItems: 'center',
  },
  modalIcon: {
    marginBottom: 16,
  },
  modalDescription: {
    color: colors.textSecondary,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  priceInput: {
    width: '100%',
    marginBottom: 24,
  },
  priceLabel: {
    color: colors.textPrimary,
    fontSize: 14,
    marginBottom: 8,
  },
  priceInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  currencySymbol: {
    color: colors.textPrimary,
    fontSize: 20,
    fontWeight: '600',
  },
  priceTextInput: {
    flex: 1,
    color: colors.textPrimary,
    fontSize: 20,
    paddingVertical: 14,
    marginLeft: 8,
  },
  perMonth: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  activateButton: {
    backgroundColor: colors.premium,
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 24,
    width: '100%',
    alignItems: 'center',
  },
  activateButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  mockNote: {
    color: colors.accent,
    fontSize: 12,
    marginTop: 16,
    textAlign: 'center',
  },
  // Earnings Modal
  earningsCard: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 16,
    padding: 24,
    width: '100%',
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.border,
  },
  earningsLabel: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  earningsAmount: {
    color: colors.success,
    fontSize: 36,
    fontWeight: 'bold',
    marginTop: 8,
  },
  earningsRow: {
    flexDirection: 'row',
    width: '100%',
    gap: 16,
  },
  earningsItem: {
    flex: 1,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  earningsItemLabel: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 8,
  },
  earningsItemValue: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    marginTop: 4,
  },
  earningsItemAmount: {
    color: colors.success,
    fontSize: 14,
    marginTop: 4,
  },
  noEarnings: {
    color: colors.textSecondary,
    fontSize: 14,
  },
});
