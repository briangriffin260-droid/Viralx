import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Image,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Video, ResizeMode } from 'expo-av';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { postsAPI } from '../../src/services/api';
import api from '../../src/services/api';
import { useAuth } from '../../src/contexts/AuthContext';
import ContentWarning from '../../src/components/ContentWarning';
import SendGiftModal from '../../src/components/SendGiftModal';
import colors from '../../src/theme/colors';

const { width, height } = Dimensions.get('window');
const VIDEO_HEIGHT = height - 150;

const VIDEO_WARNING_KEY = '@warning_dismissed_videos';

interface VideoPost {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  user_avatar: string | null;
  content: string;
  media: string | null;
  media_type: string;
  is_premium: boolean;
  likes_count: number;
  comments_count: number;
  created_at: string;
  is_liked: boolean;
  is_accessible: boolean;
}

export default function VideoFeedScreen() {
  const [videos, setVideos] = useState<VideoPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showWarning, setShowWarning] = useState(false);
  const [warningChecked, setWarningChecked] = useState(false);
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [selectedVideoForGift, setSelectedVideoForGift] = useState<VideoPost | null>(null);
  const [coinBalance, setCoinBalance] = useState(0);
  const { user } = useAuth();
  const router = useRouter();
  const videoRefs = useRef<{ [key: string]: Video | null }>({});

  // Check if warning was already dismissed
  useEffect(() => {
    checkWarningStatus();
  }, []);

  const checkWarningStatus = async () => {
    try {
      const dismissed = await AsyncStorage.getItem(VIDEO_WARNING_KEY);
      if (dismissed !== 'true') {
        setShowWarning(true);
      }
      setWarningChecked(true);
    } catch (error) {
      setWarningChecked(true);
    }
  };

  const handleWarningAccept = async () => {
    try {
      await AsyncStorage.setItem(VIDEO_WARNING_KEY, 'true');
    } catch (error) {
      console.log('Error saving warning preference:', error);
    }
    setShowWarning(false);
  };

  const handleWarningDecline = () => {
    setShowWarning(false);
    router.back();
  };

  useFocusEffect(
    useCallback(() => {
      if (!showWarning && warningChecked) {
        fetchVideos();
      }
      return () => {
        Object.values(videoRefs.current).forEach(ref => {
          ref?.pauseAsync();
        });
      };
    }, [showWarning, warningChecked])
  );

  const fetchVideos = async () => {
    try {
      const response = await postsAPI.getVideoFeed();
      setVideos(response.data);
      // Also fetch coin balance for gifts
      try {
        const balanceRes = await api.get('/coins/balance');
        setCoinBalance(balanceRes.data.balance || 0);
      } catch (e) {
        // Ignore balance errors
      }
    } catch (error) {
      console.log('Video feed error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenGiftModal = (video: VideoPost) => {
    setSelectedVideoForGift(video);
    setShowGiftModal(true);
  };

  const handleGiftSuccess = async () => {
    // Refresh coin balance after sending gift
    try {
      const balanceRes = await api.get('/coins/balance');
      setCoinBalance(balanceRes.data.balance || 0);
    } catch (e) {
      // Ignore
    }
  };

  const handleLike = async (video: VideoPost) => {
    try {
      if (video.is_liked) {
        await postsAPI.unlikePost(video.id);
      } else {
        await postsAPI.likePost(video.id);
      }
      setVideos(prev =>
        prev.map(v =>
          v.id === video.id
            ? {
                ...v,
                is_liked: !v.is_liked,
                likes_count: v.is_liked ? v.likes_count - 1 : v.likes_count + 1,
              }
            : v
        )
      );
    } catch (error) {
      console.log('Like error:', error);
    }
  };

  const onViewableItemsChanged = useCallback(({ viewableItems }: any) => {
    if (viewableItems.length > 0) {
      const newIndex = viewableItems[0].index;
      setCurrentIndex(newIndex);
      
      videos.forEach((video, index) => {
        const ref = videoRefs.current[video.id];
        if (ref) {
          if (index === newIndex) {
            ref.playAsync();
          } else {
            ref.pauseAsync();
          }
        }
      });
    }
  }, [videos]);

  const renderVideo = ({ item, index }: { item: VideoPost; index: number }) => (
    <View style={styles.videoContainer}>
      {item.is_accessible && item.media ? (
        <Video
          ref={(ref) => {
            videoRefs.current[item.id] = ref;
          }}
          source={{ uri: item.media }}
          style={styles.video}
          resizeMode={ResizeMode.COVER}
          isLooping
          shouldPlay={index === currentIndex}
          isMuted={false}
        />
      ) : (
        <View style={styles.lockedContent}>
          <Ionicons name="lock-closed" size={64} color={colors.accent} />
          <Text style={styles.lockedText}>Premium Content</Text>
          <Text style={styles.lockedSubtext}>Subscribe to view</Text>
          <TouchableOpacity
            style={styles.subscribeButton}
            onPress={() => router.push(`/profile/${item.username}`)}
          >
            <Text style={styles.subscribeButtonText}>Subscribe</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Overlay */}
      <View style={styles.overlay}>
        {/* Right Actions */}
        <View style={styles.rightActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push(`/profile/${item.username}`)}
          >
            {item.user_avatar ? (
              <Image source={{ uri: item.user_avatar }} style={styles.avatarAction} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={20} color="#fff" />
              </View>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handleLike(item)}
          >
            <Ionicons
              name={item.is_liked ? 'heart' : 'heart-outline'}
              size={32}
              color={item.is_liked ? colors.accent : '#fff'}
            />
            <Text style={styles.actionText}>{item.likes_count}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push(`/post/${item.id}`)}
          >
            <Ionicons name="chatbubble-outline" size={30} color="#fff" />
            <Text style={styles.actionText}>{item.comments_count}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton}>
            <Ionicons name="paper-plane-outline" size={28} color="#fff" />
            <Text style={styles.actionText}>Share</Text>
          </TouchableOpacity>

          {/* Gift Button */}
          {user && item.user_id !== user.id && (
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={() => handleOpenGiftModal(item)}
            >
              <Ionicons name="gift-outline" size={28} color={colors.premium} />
              <Text style={styles.actionText}>Gift</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Bottom Info */}
        <View style={styles.bottomInfo}>
          <TouchableOpacity
            style={styles.userInfo}
            onPress={() => router.push(`/profile/${item.username}`)}
          >
            <Text style={styles.username}>@{item.username}</Text>
            {item.is_premium && (
              <Ionicons name="star" size={14} color={colors.premium} style={styles.premiumBadge} />
            )}
          </TouchableOpacity>
          <Text style={styles.caption} numberOfLines={2}>
            {item.content}
          </Text>
        </View>
      </View>
    </View>
  );

  // Show content warning first
  if (showWarning) {
    return (
      <ContentWarning
        type="videos"
        visible={showWarning}
        onAccept={handleWarningAccept}
        onDecline={handleWarningDecline}
      />
    );
  }

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <SafeAreaView style={styles.header} edges={['top']}>
        <Text style={styles.headerTitle}>Videos</Text>
        <View style={styles.headerBadge}>
          <Ionicons name="shield-checkmark" size={14} color={colors.primary} />
          <Text style={styles.headerBadgeText}>18+</Text>
        </View>
      </SafeAreaView>

      {videos.length > 0 ? (
        <FlatList
          data={videos}
          keyExtractor={(item) => item.id}
          renderItem={renderVideo}
          pagingEnabled
          showsVerticalScrollIndicator={false}
          snapToInterval={VIDEO_HEIGHT}
          decelerationRate="fast"
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={{
            itemVisiblePercentThreshold: 50,
          }}
          getItemLayout={(_, index) => ({
            length: VIDEO_HEIGHT,
            offset: VIDEO_HEIGHT * index,
            index,
          })}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Ionicons name="videocam-outline" size={64} color="#333" />
          <Text style={styles.emptyTitle}>No videos yet</Text>
          <Text style={styles.emptySubtitle}>
            Be the first to share a video!
          </Text>
          <TouchableOpacity
            style={styles.createButton}
            onPress={() => router.push('/(tabs)/create')}
          >
            <Text style={styles.createButtonText}>Create Video</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Gift Modal */}
      {selectedVideoForGift && (
        <SendGiftModal
          visible={showGiftModal}
          recipientId={selectedVideoForGift.user_id}
          recipientName={selectedVideoForGift.display_name}
          postId={selectedVideoForGift.id}
          coinBalance={coinBalance}
          onClose={() => {
            setShowGiftModal(false);
            setSelectedVideoForGift(null);
          }}
          onSuccess={handleGiftSuccess}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: 16,
    paddingBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    textShadow: '0px 1px 3px rgba(0,0,0,0.5)',
  },
  headerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  headerBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  videoContainer: {
    width: width,
    height: VIDEO_HEIGHT,
    backgroundColor: '#000',
  },
  video: {
    width: '100%',
    height: '100%',
  },
  lockedContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
  },
  lockedText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '600',
    marginTop: 16,
  },
  lockedSubtext: {
    color: '#888',
    fontSize: 14,
    marginTop: 8,
  },
  subscribeButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 24,
    marginTop: 20,
  },
  subscribeButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
  },
  rightActions: {
    position: 'absolute',
    right: 12,
    bottom: 100,
    alignItems: 'center',
  },
  actionButton: {
    alignItems: 'center',
    marginBottom: 20,
  },
  avatarAction: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: '#fff',
  },
  avatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  actionText: {
    color: '#fff',
    fontSize: 12,
    marginTop: 4,
    textShadow: '0px 1px 2px rgba(0,0,0,0.5)',
  },
  bottomInfo: {
    padding: 16,
    paddingRight: 80,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  username: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textShadow: '0px 1px 3px rgba(0,0,0,0.5)',
  },
  premiumBadge: {
    marginLeft: 6,
  },
  caption: {
    color: '#fff',
    fontSize: 14,
    marginTop: 8,
    textShadow: '0px 1px 3px rgba(0,0,0,0.5)',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  emptySubtitle: {
    color: '#888',
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
  createButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    marginTop: 20,
  },
  createButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
