import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/contexts/AuthContext';
import { postsAPI, storiesAPI, notificationsAPI } from '../../src/services/api';
import PostCard from '../../src/components/PostCard';
import StoryCircle from '../../src/components/StoryCircle';
import colors from '../../src/theme/colors';

interface Post {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  user_avatar: string | null;
  content: string;
  media: string | null;
  media_type: string;
  is_premium: boolean;
  likes_count: number;
  comments_count: number;
  created_at: string;
  is_liked: boolean;
}

interface StoryGroup {
  user_id: string;
  username: string;
  display_name: string;
  user_avatar: string | null;
  stories: any[];
  has_unseen: boolean;
}

export default function HomeScreen() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<StoryGroup[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'foryou' | 'following'>('foryou');
  const [unreadCount, setUnreadCount] = useState(0);
  const { user } = useAuth();
  const router = useRouter();

  const fetchFeed = useCallback(async () => {
    try {
      const response = activeTab === 'following'
        ? await postsAPI.getFollowingFeed()
        : await postsAPI.getFeed();
      setPosts(response.data);
    } catch (error) {
      console.log('Feed error:', error);
    }
  }, [activeTab]);

  const fetchStories = async () => {
    try {
      const response = await storiesAPI.getStories();
      setStories(response.data);
    } catch (error) {
      console.log('Stories error:', error);
    }
  };

  const fetchUnreadCount = async () => {
    try {
      const response = await notificationsAPI.getUnreadCount();
      setUnreadCount(response.data.count);
    } catch (error) {
      console.log('Unread count error:', error);
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    await Promise.all([fetchFeed(), fetchStories(), fetchUnreadCount()]);
    setIsLoading(false);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([fetchFeed(), fetchStories(), fetchUnreadCount()]);
    setIsRefreshing(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    fetchFeed();
  }, [activeTab]);

  const handleStoryPress = (storyGroup: StoryGroup) => {
    router.push({
      pathname: '/stories/[userId]',
      params: {
        userId: storyGroup.user_id,
        stories: JSON.stringify(storyGroup.stories),
      },
    });
  };

  const renderStories = () => (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={styles.storiesContainer}
      contentContainerStyle={styles.storiesContent}
    >
      <StoryCircle
        username={user?.username || ''}
        displayName="Your story"
        avatar={user?.avatar || null}
        hasUnseen={false}
        isAddStory={true}
        onPress={() => router.push('/(tabs)/create')}
      />
      {stories.map((storyGroup) => (
        <StoryCircle
          key={storyGroup.user_id}
          username={storyGroup.username}
          displayName={storyGroup.display_name}
          avatar={storyGroup.user_avatar}
          hasUnseen={storyGroup.has_unseen}
          onPress={() => handleStoryPress(storyGroup)}
        />
      ))}
    </ScrollView>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <Text style={styles.logo}>AllTogether</Text>
      <View style={styles.headerRight}>
        <TouchableOpacity 
          style={styles.headerIcon}
          onPress={() => router.push('/(tabs)/activity')}
        >
          <Ionicons name="notifications-outline" size={24} color={colors.textPrimary} />
          {unreadCount > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>
                {unreadCount > 99 ? '99+' : unreadCount}
              </Text>
            </View>
          )}
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.headerIcon}
          onPress={() => router.push('/messages')}
        >
          <Ionicons name="chatbubble-outline" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderTabs = () => (
    <View style={styles.tabsContainer}>
      <TouchableOpacity
        style={[styles.tab, activeTab === 'foryou' && styles.tabActive]}
        onPress={() => setActiveTab('foryou')}
      >
        <Text style={[styles.tabText, activeTab === 'foryou' && styles.tabTextActive]}>
          For You
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.tab, activeTab === 'following' && styles.tabActive]}
        onPress={() => setActiveTab('following')}
      >
        <Text style={[styles.tabText, activeTab === 'following' && styles.tabTextActive]}>
          Following
        </Text>
      </TouchableOpacity>
    </View>
  );

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        {renderHeader()}
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {renderHeader()}
      {renderTabs()}
      
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={renderStories}
        renderItem={({ item }) => (
          <PostCard
            post={item}
            onPressUser={(username) => router.push(`/profile/${username}`)}
            onPressComments={(postId) => router.push(`/post/${postId}`)}
            onPostUpdated={fetchFeed}
          />
        )}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="images-outline" size={64} color={colors.border} />
            <Text style={styles.emptyTitle}>
              {activeTab === 'following' ? 'No posts from followed users' : 'No posts yet'}
            </Text>
            <Text style={styles.emptySubtitle}>
              {activeTab === 'following'
                ? 'Follow users to see their posts here'
                : 'Be the first to share something!'}
            </Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  logo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.primary,
  },
  headerRight: {
    flexDirection: 'row',
  },
  headerIcon: {
    marginLeft: 20,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -6,
    right: -8,
    backgroundColor: colors.accent,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tab: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  tabText: {
    color: colors.textTertiary,
    fontSize: 15,
    fontWeight: '600',
  },
  tabTextActive: {
    color: colors.textPrimary,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  storiesContainer: {
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  storiesContent: {
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
    paddingHorizontal: 40,
  },
  emptyTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    textAlign: 'center',
  },
  emptySubtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
});
