import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Dimensions,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../src/contexts/AuthContext';
import colors from '../src/theme/colors';
import api from '../src/services/api';

const { width } = Dimensions.get('window');

interface DashboardStats {
  totalEarnings: number;
  monthlyEarnings: number;
  subscribers: number;
  totalViews: number;
  totalLikes: number;
  giftsReceived: number;
  coinBalance: number;
  pendingPayout: number;
}

interface RecentActivity {
  id: string;
  type: 'subscription' | 'tip' | 'gift' | 'view';
  amount?: number;
  username: string;
  timestamp: string;
}

export default function CreatorDashboard() {
  const { user, refreshUser } = useAuth();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [stats, setStats] = useState<DashboardStats>({
    totalEarnings: 0,
    monthlyEarnings: 0,
    subscribers: 0,
    totalViews: 0,
    totalLikes: 0,
    giftsReceived: 0,
    coinBalance: 0,
    pendingPayout: 0,
  });
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [analyticsStatus, setAnalyticsStatus] = useState<any>(null);
  const [badgeStatus, setBadgeStatus] = useState<any>(null);

  useFocusEffect(
    useCallback(() => {
      loadDashboardData();
    }, [])
  );

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      // Fetch multiple data sources in parallel
      const [earningsRes, balanceRes, analyticsRes, badgeRes, giftsRes] = await Promise.all([
        api.get('/earnings/summary').catch(() => ({ data: null })),
        api.get('/coins/balance').catch(() => ({ data: { balance: 0 } })),
        api.get('/analytics/status').catch(() => ({ data: null })),
        api.get('/verified/status').catch(() => ({ data: null })),
        api.get('/gifts/received').catch(() => ({ data: [] })),
      ]);

      // Calculate stats from responses
      const earnings = earningsRes.data || {};
      const giftsList = giftsRes.data || [];

      setStats({
        totalEarnings: earnings.total_earnings || 0,
        monthlyEarnings: earnings.monthly_earnings || 0,
        subscribers: user?.followers_count || 0,
        totalViews: earnings.total_views || 0,
        totalLikes: earnings.total_likes || 0,
        giftsReceived: giftsList.length,
        coinBalance: balanceRes.data?.balance || 0,
        pendingPayout: earnings.pending_payout || 0,
      });

      setAnalyticsStatus(analyticsRes.data);
      setBadgeStatus(badgeRes.data);

      // Create mock recent activity for demo
      setRecentActivity([
        { id: '1', type: 'subscription', amount: 9.99, username: 'fan_user1', timestamp: '2 hours ago' },
        { id: '2', type: 'gift', amount: 50, username: 'supporter_22', timestamp: '4 hours ago' },
        { id: '3', type: 'tip', amount: 5.00, username: 'grateful_user', timestamp: '1 day ago' },
        { id: '4', type: 'view', username: 'viewer_55', timestamp: '1 day ago' },
      ]);

    } catch (error) {
      console.log('Error loading dashboard:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadDashboardData();
    await refreshUser();
    setIsRefreshing(false);
  };

  const handleRequestPayout = () => {
    if (stats.pendingPayout < 50) {
      Alert.alert('Minimum Payout', 'You need at least $50 in earnings to request a payout.');
      return;
    }
    Alert.alert(
      'Request Payout',
      `Request a payout of $${stats.pendingPayout.toFixed(2)} to your connected Stripe account?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Request', onPress: () => {
          Alert.alert('Success', 'Payout request submitted! You\'ll receive funds within 2-3 business days.');
        }},
      ]
    );
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'subscription': return 'star';
      case 'tip': return 'cash';
      case 'gift': return 'gift';
      case 'view': return 'eye';
      default: return 'notifications';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'subscription': return colors.premium;
      case 'tip': return colors.success;
      case 'gift': return colors.accent;
      case 'view': return colors.info;
      default: return colors.textSecondary;
    }
  };

  if (!user?.is_premium_creator) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Creator Dashboard</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={styles.notCreatorContainer}>
          <Ionicons name="star" size={64} color={colors.premium} />
          <Text style={styles.notCreatorTitle}>Become a Creator</Text>
          <Text style={styles.notCreatorText}>
            Start earning money from your content! Set up your creator profile to access exclusive monetization tools.
          </Text>
          <TouchableOpacity 
            style={styles.becomeCreatorButton}
            onPress={() => router.push('/(tabs)/profile' as any)}
          >
            <Text style={styles.becomeCreatorText}>Set Up Creator Profile</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Creator Dashboard</Text>
        <TouchableOpacity onPress={() => router.push('/wallet' as any)}>
          <Ionicons name="wallet-outline" size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={styles.scrollContent}
      >
        {/* Earnings Overview */}
        <View style={styles.earningsCard}>
          <Text style={styles.earningsLabel}>Total Earnings</Text>
          <Text style={styles.earningsAmount}>
            ${stats.totalEarnings.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </Text>
          <View style={styles.earningsRow}>
            <View style={styles.earningsItem}>
              <Text style={styles.earningsItemLabel}>This Month</Text>
              <Text style={styles.earningsItemValue}>
                ${stats.monthlyEarnings.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </Text>
            </View>
            <View style={styles.earningsDivider} />
            <View style={styles.earningsItem}>
              <Text style={styles.earningsItemLabel}>Pending Payout</Text>
              <Text style={styles.earningsItemValue}>
                ${stats.pendingPayout.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </Text>
            </View>
          </View>
          <TouchableOpacity 
            style={styles.payoutButton}
            onPress={handleRequestPayout}
          >
            <Text style={styles.payoutButtonText}>Request Payout</Text>
          </TouchableOpacity>
        </View>

        {/* Stats Grid */}
        <Text style={styles.sectionTitle}>Performance</Text>
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Ionicons name="people" size={24} color={colors.primary} />
            <Text style={styles.statValue}>{stats.subscribers.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Subscribers</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="eye" size={24} color={colors.info} />
            <Text style={styles.statValue}>{stats.totalViews.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Total Views</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="heart" size={24} color={colors.accent} />
            <Text style={styles.statValue}>{stats.totalLikes.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Total Likes</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="gift" size={24} color={colors.premium} />
            <Text style={styles.statValue}>{stats.giftsReceived.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Gifts Received</Text>
          </View>
        </View>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionsContainer}>
          <TouchableOpacity 
            style={styles.actionCard}
            onPress={() => router.push('/(tabs)/create' as any)}
          >
            <View style={[styles.actionIcon, { backgroundColor: `${colors.accent}15` }]}>
              <Ionicons name="add-circle" size={28} color={colors.accent} />
            </View>
            <Text style={styles.actionTitle}>Create Content</Text>
            <Text style={styles.actionDesc}>Post new content</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionCard}
            onPress={() => router.push('/wallet' as any)}
          >
            <View style={[styles.actionIcon, { backgroundColor: `${colors.premium}15` }]}>
              <Ionicons name="diamond" size={28} color={colors.premium} />
            </View>
            <Text style={styles.actionTitle}>Monetization</Text>
            <Text style={styles.actionDesc}>Boosts & features</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionCard}
            onPress={() => {
              if (analyticsStatus?.is_active) {
                Alert.alert('Premium Analytics', 'Detailed analytics coming soon!');
              } else {
                router.push('/wallet' as any);
              }
            }}
          >
            <View style={[styles.actionIcon, { backgroundColor: `${colors.info}15` }]}>
              <Ionicons name="analytics" size={28} color={colors.info} />
            </View>
            <Text style={styles.actionTitle}>Analytics</Text>
            <Text style={styles.actionDesc}>
              {analyticsStatus?.is_active ? 'View insights' : 'Upgrade'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Subscription Info */}
        <View style={styles.subscriptionCard}>
          <View style={styles.subscriptionHeader}>
            <Ionicons name="star" size={24} color={colors.premium} />
            <Text style={styles.subscriptionTitle}>Your Subscription</Text>
          </View>
          <Text style={styles.subscriptionPrice}>
            ${user?.subscription_price?.toFixed(2) || '9.99'}/month
          </Text>
          <Text style={styles.subscriptionNote}>
            Subscribers pay this amount for access to your premium content.
            Platform takes 15% fee on all transactions.
          </Text>
          <TouchableOpacity 
            style={styles.editPriceButton}
            onPress={() => router.push('/(tabs)/profile' as any)}
          >
            <Text style={styles.editPriceText}>Edit Price</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Activity */}
        <Text style={styles.sectionTitle}>Recent Activity</Text>
        <View style={styles.activityContainer}>
          {recentActivity.map((activity) => (
            <View key={activity.id} style={styles.activityItem}>
              <View style={[styles.activityIcon, { backgroundColor: `${getActivityColor(activity.type)}15` }]}>
                <Ionicons 
                  name={getActivityIcon(activity.type) as any} 
                  size={20} 
                  color={getActivityColor(activity.type)} 
                />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityText}>
                  <Text style={styles.activityUsername}>@{activity.username}</Text>
                  {activity.type === 'subscription' && ' subscribed'}
                  {activity.type === 'tip' && ' sent a tip'}
                  {activity.type === 'gift' && ' sent a gift'}
                  {activity.type === 'view' && ' viewed your content'}
                </Text>
                <Text style={styles.activityTime}>{activity.timestamp}</Text>
              </View>
              {activity.amount && (
                <Text style={styles.activityAmount}>
                  +${activity.amount.toFixed(2)}
                </Text>
              )}
            </View>
          ))}
        </View>

        {/* Pro Tips */}
        <View style={styles.tipsCard}>
          <View style={styles.tipsHeader}>
            <Ionicons name="bulb" size={20} color={colors.warning} />
            <Text style={styles.tipsTitle}>Pro Tips</Text>
          </View>
          <Text style={styles.tipsText}>
            • Post consistently to keep subscribers engaged{'\n'}
            • Use stories to tease premium content{'\n'}
            • Engage with fans in comments and DMs{'\n'}
            • Promote your profile to grow faster
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  // Not Creator State
  notCreatorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  notCreatorTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: colors.textPrimary,
    marginTop: 16,
    marginBottom: 8,
  },
  notCreatorText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  becomeCreatorButton: {
    backgroundColor: colors.premium,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
  },
  becomeCreatorText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  // Earnings Card
  earningsCard: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.border,
  },
  earningsLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  earningsAmount: {
    fontSize: 42,
    fontWeight: 'bold',
    color: colors.success,
    textAlign: 'center',
    marginVertical: 8,
  },
  earningsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 20,
  },
  earningsItem: {
    alignItems: 'center',
    flex: 1,
  },
  earningsDivider: {
    width: 1,
    height: 40,
    backgroundColor: colors.border,
  },
  earningsItemLabel: {
    fontSize: 12,
    color: colors.textTertiary,
    marginBottom: 4,
  },
  earningsItemValue: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  payoutButton: {
    backgroundColor: colors.accent,
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  payoutButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  // Section Title
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 12,
  },
  // Stats Grid
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    width: (width - 44) / 2,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  // Quick Actions
  actionsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  actionCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  actionIcon: {
    width: 52,
    height: 52,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  actionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textPrimary,
    textAlign: 'center',
  },
  actionDesc: {
    fontSize: 11,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: 2,
  },
  // Subscription Card
  subscriptionCard: {
    backgroundColor: `${colors.premium}10`,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.premium,
  },
  subscriptionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  subscriptionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  subscriptionPrice: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.premium,
    marginBottom: 8,
  },
  subscriptionNote: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 20,
    marginBottom: 12,
  },
  editPriceButton: {
    alignSelf: 'flex-start',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: colors.premium,
    borderRadius: 8,
  },
  editPriceText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  // Recent Activity
  activityContainer: {
    backgroundColor: colors.card,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.border,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 14,
    color: colors.textPrimary,
  },
  activityUsername: {
    fontWeight: '600',
  },
  activityTime: {
    fontSize: 12,
    color: colors.textTertiary,
    marginTop: 2,
  },
  activityAmount: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.success,
  },
  // Tips Card
  tipsCard: {
    backgroundColor: `${colors.warning}10`,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: `${colors.warning}30`,
  },
  tipsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  tipsText: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 22,
  },
});
