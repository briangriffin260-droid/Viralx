# ViralX - Google Play Store Deployment Guide

## 📱 Your Privacy Policy & Terms URLs

Your legal pages are now live:
- **Privacy Policy**: https://verified-creators-2.preview.emergentagent.com/api/privacy-policy
- **Terms of Service**: https://verified-creators-2.preview.emergentagent.com/api/terms-of-service

Use these URLs when setting up your Google Play store listing.

---

## 🚀 Google Play Deployment Steps

### Step 1: Create Google Play Developer Account
1. Go to https://play.google.com/console/
2. Pay the **$25 one-time fee**
3. Complete identity verification (may take 24-48 hours)

### Step 2: Export Your Code
1. Click **"Save to GitHub"** in Emergent chat
2. Clone to your computer:
```bash
git clone https://github.com/YOUR_USERNAME/alltogether.git
cd alltogether/frontend
```

### Step 3: Update app.json
Edit `app.json` and replace these values:

```json
{
  "expo": {
    "owner": "YOUR_EXPO_USERNAME",
    "android": {
      "package": "com.yourcompany.alltogether",
      "versionCode": 1
    },
    "extra": {
      "eas": {
        "projectId": "YOUR_EAS_PROJECT_ID"
      }
    }
  }
}
```

**Important**: Change `com.yourcompany.alltogether` to your own unique package name (e.g., `com.johnsmith.alltogether`)

### Step 4: Install EAS & Login
```bash
npm install -g eas-cli
eas login
# Create Expo account if you don't have one
```

### Step 5: Configure EAS
```bash
eas build:configure
# This creates your project on Expo and gets your project ID
```

### Step 6: Build Android App Bundle
```bash
eas build --platform android --profile production
```
This will:
- Build your app in the cloud (takes ~10-15 minutes)
- Generate an `.aab` file (Android App Bundle)
- Give you a download link

### Step 7: Create App in Google Play Console
1. Go to **Google Play Console** > **Create app**
2. Fill in:
   - App name: **ViralX**
   - Default language: English
   - App or game: **App**
   - Free or paid: **Free** (your monetization is in-app)
   - Accept the declarations

### Step 8: Complete Store Listing
Fill in all required information:

**Main store listing:**
- Short description (80 chars): `Connect, create, and monetize. The ultimate social platform for creators.`
- Full description: (see below)
- App icon: 512x512 PNG
- Feature graphic: 1024x500 PNG
- Screenshots: At least 2 phone screenshots

**Content rating:**
- Complete the questionnaire
- Your app will likely be rated **18+** due to adult content

**Privacy Policy:**
- URL: `https://verified-creators-2.preview.emergentagent.com/api/privacy-policy`

### Step 9: Upload Your App Bundle
1. Go to **Release** > **Production**
2. Click **Create new release**
3. Upload the `.aab` file from Step 6
4. Add release notes
5. Review and roll out

### Step 10: Submit for Review
- Click **Submit for review**
- Review typically takes 1-3 days
- You'll get an email when approved/rejected

---

## 📝 Store Listing Content

### Short Description (80 characters)
```
Connect, create, and monetize. The ultimate social platform for creators.
```

### Full Description
```
ViralX is the ultimate social platform combining the best features of your favorite apps. Create posts, stories, and videos. Build your audience and monetize your content with subscriptions, tips, and exclusive features.

FEATURES:
• Create and share posts, stories, and videos
• Build your follower base
• Monetize with premium subscriptions
• Receive tips and virtual gifts from fans
• Boost your content for more visibility
• Get verified with a blue checkmark
• Access detailed creator analytics
• Direct messaging with your community

FOR CREATORS:
• Set your own subscription price
• Earn from tips and virtual gifts
• 85% revenue share
• Creator dashboard with earnings tracking
• Premium analytics to grow your audience

SAFETY & SECURITY:
• 18+ age verification
• AI-powered content moderation
• Report and block features
• Secure payments via Stripe

Join ViralX today and start creating!
```

---

## ⚠️ Important Notes

### Adult Content Declaration
- Your app has adult content features
- In the Content Rating questionnaire, answer "Yes" to mature themes
- May be restricted in some countries

### In-App Purchases
- You're using Stripe (not Google Play Billing)
- This is allowed for physical goods/services
- For digital content, Google may require Play Billing
- Monitor your listing for any policy issues

### Age Gate
- Your 18+ age gate is implemented ✅
- Make sure it works properly before submission

---

## 📋 Pre-Submission Checklist

- [ ] Google Play Developer account created ($25)
- [ ] Expo account created (free)
- [ ] Code exported to GitHub
- [ ] app.json updated with your package name
- [ ] EAS configured with project ID
- [ ] Android App Bundle (.aab) built
- [ ] App icon (512x512) created
- [ ] Feature graphic (1024x500) created
- [ ] At least 2 screenshots taken
- [ ] Privacy Policy URL added
- [ ] Content rating questionnaire completed
- [ ] Store listing filled out

---

## 🆘 Need Help?

- **EAS Build Issues**: https://docs.expo.dev/eas/
- **Google Play Help**: https://support.google.com/googleplay/android-developer/
- **Expo Forums**: https://forums.expo.dev/

Good luck with your launch! 🚀
