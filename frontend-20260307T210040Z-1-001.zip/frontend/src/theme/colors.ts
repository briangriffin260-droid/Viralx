// Serene Sky Theme - Light & Comfortable
// A calm, welcoming color palette with cool blue-gray undertones

export const colors = {
  // Primary Colors
  primary: '#5B8A9A',        // Dusty Teal - calm, trustworthy
  primaryLight: '#7BA3B1',   // Lighter teal for hover states
  primaryDark: '#4A7585',    // Darker teal for pressed states
  
  // Secondary Colors  
  secondary: '#9BB5C4',      // Soft Blue-Gray - gentle, soothing
  secondaryLight: '#B5CAD6', // Lighter blue-gray
  
  // Accent Colors
  accent: '#E07A5F',         // Terracotta - warm touch for buttons
  accentLight: '#E89A84',    // Lighter terracotta
  accentDark: '#C96B52',     // Darker terracotta for pressed states
  
  // Background Colors
  background: '#F8F9FA',     // Off-White - clean, airy
  backgroundAlt: '#EEF1F4',  // Slightly darker for sections
  card: '#FFFFFF',           // White - fresh, open
  cardAlt: '#F5F7F9',        // Slight gray for alternating cards
  
  // Border Colors
  border: '#E5E9EC',         // Light Gray - subtle definition
  borderLight: '#F0F2F5',    // Very light border
  borderDark: '#D0D5DA',     // Darker border for emphasis
  
  // Text Colors
  textPrimary: '#2D3436',    // Charcoal - easy to read
  textSecondary: '#636E72',  // Cool Gray - soft contrast
  textTertiary: '#95A5A6',   // Lighter gray for hints
  textInverse: '#FFFFFF',    // White text on dark backgrounds
  
  // Status Colors
  success: '#27AE60',        // Green for success states
  warning: '#F39C12',        // Orange for warnings
  error: '#E74C3C',          // Red for errors
  info: '#3498DB',           // Blue for info
  
  // Special Colors
  premium: '#D4A574',        // Warm gold for premium (softer than bright gold)
  premiumBg: 'rgba(212, 165, 116, 0.1)', // Premium background tint
  like: '#E07A5F',           // Same as accent for likes
  link: '#5B8A9A',           // Same as primary for links
  
  // Overlay Colors
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
  
  // Gradient Colors (for stories ring)
  gradientStart: '#E07A5F',  // Terracotta
  gradientMid: '#D4A574',    // Warm gold
  gradientEnd: '#5B8A9A',    // Dusty teal
};

// Semantic color aliases for common use cases
export const semanticColors = {
  // Buttons
  buttonPrimary: colors.accent,
  buttonPrimaryText: colors.textInverse,
  buttonSecondary: colors.card,
  buttonSecondaryText: colors.textPrimary,
  
  // Inputs
  inputBackground: colors.card,
  inputBorder: colors.border,
  inputBorderFocus: colors.primary,
  inputPlaceholder: colors.textTertiary,
  inputText: colors.textPrimary,
  
  // Navigation
  tabActive: colors.primary,
  tabInactive: colors.textTertiary,
  headerBackground: colors.card,
  headerText: colors.textPrimary,
  
  // Cards & Content
  postBackground: colors.card,
  postBorder: colors.border,
  
  // Icons
  iconDefault: colors.textSecondary,
  iconActive: colors.primary,
};

export default colors;
