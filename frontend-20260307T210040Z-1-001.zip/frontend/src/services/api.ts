import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL || 'http://localhost:8001';

const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth API
export const authAPI = {
  register: (data: { email: string; password: string; username: string; display_name: string }) =>
    api.post('/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
  updateProfile: (data: { display_name?: string; bio?: string; avatar?: string; is_premium_creator?: boolean; subscription_price?: number }) =>
    api.put('/auth/profile', data),
};

// Users API
export const usersAPI = {
  getProfile: (username: string) => api.get(`/users/${username}`),
  getFollowStatus: (userId: string) => api.get(`/users/${userId}/follow-status`),
  follow: (userId: string) => api.post(`/users/${userId}/follow`),
  unfollow: (userId: string) => api.delete(`/users/${userId}/follow`),
  getFollowers: (userId: string) => api.get(`/users/${userId}/followers`),
  getFollowing: (userId: string) => api.get(`/users/${userId}/following`),
  getSubscriptionStatus: (userId: string) => api.get(`/users/${userId}/subscription-status`),
  subscribe: (creatorId: string) => api.post(`/users/${creatorId}/subscribe`),
  cancelSubscription: (creatorId: string) => api.delete(`/users/${creatorId}/subscribe`),
  sendTip: (userId: string, amount: number, message?: string) => 
    api.post(`/users/${userId}/tip`, { amount, message }),
};

// Posts API
export const postsAPI = {
  getFeed: (skip = 0, limit = 20) => api.get(`/posts?skip=${skip}&limit=${limit}`),
  getVideoFeed: (skip = 0, limit = 20) => api.get(`/posts/videos?skip=${skip}&limit=${limit}`),
  getFollowingFeed: (skip = 0, limit = 20) => api.get(`/posts/following?skip=${skip}&limit=${limit}`),
  getUserPosts: (userId: string, skip = 0, limit = 20) =>
    api.get(`/posts/user/${userId}?skip=${skip}&limit=${limit}`),
  getPost: (postId: string) => api.get(`/posts/${postId}`),
  createPost: (data: { content: string; media?: string; media_type?: string; is_premium?: boolean }) =>
    api.post('/posts', data),
  deletePost: (postId: string) => api.delete(`/posts/${postId}`),
  likePost: (postId: string) => api.post(`/posts/${postId}/like`),
  unlikePost: (postId: string) => api.delete(`/posts/${postId}/like`),
  getComments: (postId: string) => api.get(`/posts/${postId}/comments`),
  createComment: (postId: string, content: string) =>
    api.post(`/posts/${postId}/comments`, { content }),
  deleteComment: (postId: string, commentId: string) =>
    api.delete(`/posts/${postId}/comments/${commentId}`),
};

// Stories API
export const storiesAPI = {
  getStories: () => api.get('/stories'),
  createStory: (data: { media: string; media_type: string }) => api.post('/stories', data),
  viewStory: (storyId: string) => api.post(`/stories/${storyId}/view`),
  deleteStory: (storyId: string) => api.delete(`/stories/${storyId}`),
};

// Notifications API
export const notificationsAPI = {
  getNotifications: (skip = 0, limit = 50) => api.get(`/notifications?skip=${skip}&limit=${limit}`),
  getUnreadCount: () => api.get('/notifications/unread-count'),
  markAllRead: () => api.put('/notifications/read-all'),
  markRead: (notificationId: string) => api.put(`/notifications/${notificationId}/read`),
};

// Messaging API
export const messagesAPI = {
  getConversations: () => api.get('/conversations'),
  createOrGetConversation: (userId: string) => api.post(`/conversations/${userId}`),
  getMessages: (conversationId: string, skip = 0, limit = 50) => 
    api.get(`/conversations/${conversationId}/messages?skip=${skip}&limit=${limit}`),
  sendMessage: (conversationId: string, content: string, media?: string, mediaType?: string) =>
    api.post(`/conversations/${conversationId}/messages`, { content, media, media_type: mediaType }),
};

// Subscriptions API
export const subscriptionsAPI = {
  getMySubscriptions: () => api.get('/subscriptions'),
  getEarnings: () => api.get('/earnings'),
};

// Explore API
export const exploreAPI = {
  searchUsers: (query: string) => api.get(`/explore/users?q=${query}`),
  getTrending: (skip = 0, limit = 20) => api.get(`/explore/trending?skip=${skip}&limit=${limit}`),
  getCreators: (skip = 0, limit = 20) => api.get(`/explore/creators?skip=${skip}&limit=${limit}`),
};

// ID Verification API
export const verificationAPI = {
  getStatus: () => api.get('/verification/status'),
  submitID: (idImage: string) => api.post('/verification/submit', { id_image: idImage }),
};

// Reports & Moderation API
export const reportsAPI = {
  reportUser: (data: { 
    reported_user_id: string; 
    reason: string; 
    content_type: string; 
    content_id?: string;
    content_text?: string;
  }) => api.post('/reports', data),
  getMyReports: () => api.get('/reports/my-reports'),
  getBanStatus: () => api.get('/ban/status'),
};

// Stripe Payments API
export const paymentsAPI = {
  createCheckout: (data: {
    creator_id: string;
    payment_type: string;
    tip_amount?: number;
    origin_url: string;
  }) => api.post('/payments/create-checkout', data),
  verifyPayment: (sessionId: string) => api.get(`/payments/verify/${sessionId}`),
  getPlatformStats: () => api.get('/payments/platform-stats'),
};

// Stripe Connect API (for creator payouts)
export const connectAPI = {
  onboard: () => api.post('/connect/onboard'),
  getStatus: () => api.get('/connect/status'),
  requestPayout: () => api.post('/connect/payout'),
  getPayoutHistory: () => api.get('/connect/payouts'),
};

// Admin Dashboard API
export const adminAPI = {
  getDashboard: () => api.get('/admin/dashboard'),
  getCreators: () => api.get('/admin/creators'),
  getRevenueChart: (days?: number) => api.get(`/admin/revenue-chart?days=${days || 30}`),
};

// Advertising API
export const adsAPI = {
  createAd: (data: {
    ad_type: string;
    title: string;
    content: string;
    media?: string;
    link_url: string;
    cta_text?: string;
    budget: number;
    days_to_run?: number;
  }) => api.post('/ads/create', data),
  getFeedAds: (limit?: number) => api.get(`/ads/feed?limit=${limit || 3}`),
  getBannerAd: () => api.get('/ads/banner'),
  recordImpression: (adId: string) => api.post(`/ads/${adId}/impression`),
  recordClick: (adId: string) => api.post(`/ads/${adId}/click`),
  getMyAds: () => api.get('/ads/my-ads'),
  getAdRevenue: () => api.get('/ads/revenue'),
};

// Verified Badge API
export const badgeAPI = {
  getStatus: () => api.get('/verified/status'),
  purchase: (months: number, originUrl: string) => 
    api.post('/verified/purchase', { months, origin_url: originUrl }),
  activate: (sessionId: string) => api.post(`/verified/activate/${sessionId}`),
};

// Post Boost API
export const boostAPI = {
  boostPost: (postId: string, budget: number, durationDays: number, originUrl: string) =>
    api.post('/boost/post', { post_id: postId, budget, duration_days: durationDays, origin_url: originUrl }),
  activate: (sessionId: string) => api.post(`/boost/activate/${sessionId}`),
  getMyBoosts: () => api.get('/boost/my-boosts'),
  getBoostedPosts: (limit?: number) => api.get(`/posts/boosted?limit=${limit || 5}`),
};

// Virtual Gifts & Coins API
export const coinsAPI = {
  getPackages: () => api.get('/coins/packages'),
  getGifts: () => api.get('/coins/gifts'),
  getBalance: () => api.get('/coins/balance'),
  buyCoins: (packageId: string, originUrl: string) =>
    api.post('/coins/buy', { package_id: packageId, origin_url: originUrl }),
  activateCoins: (sessionId: string) => api.post(`/coins/activate/${sessionId}`),
  sendGift: (recipientId: string, giftType: string, postId?: string) =>
    api.post('/gifts/send', { recipient_id: recipientId, gift_type: giftType, post_id: postId }),
  getReceivedGifts: () => api.get('/gifts/received'),
};

// Featured Spots API
export const featuredAPI = {
  getPrices: () => api.get('/featured/prices'),
  purchase: (spotType: string, durationDays: number, originUrl: string) =>
    api.post('/featured/purchase', { spot_type: spotType, duration_days: durationDays, origin_url: originUrl }),
  activate: (sessionId: string) => api.post(`/featured/activate/${sessionId}`),
  getFeaturedUsers: (spotType: string, limit?: number) => 
    api.get(`/featured/users/${spotType}?limit=${limit || 10}`),
};

// Premium Analytics API
export const analyticsAPI = {
  getPlans: () => api.get('/analytics/plans'),
  getStatus: () => api.get('/analytics/status'),
  subscribe: (plan: string, originUrl: string) =>
    api.post('/analytics/subscribe', { plan, origin_url: originUrl }),
  activate: (sessionId: string) => api.post(`/analytics/activate/${sessionId}`),
  getData: () => api.get('/analytics/data'),
};

// Promoted Profile API
export const promotedAPI = {
  promote: (budget: number, durationDays: number, originUrl: string) =>
    api.post('/promote/profile', { budget, duration_days: durationDays, origin_url: originUrl }),
  activate: (sessionId: string) => api.post(`/promote/activate/${sessionId}`),
  getMyPromotion: () => api.get('/promote/my-promotions'),
  getSuggestedUsers: () => api.get('/promote/suggested-users'),
};

export default api;
