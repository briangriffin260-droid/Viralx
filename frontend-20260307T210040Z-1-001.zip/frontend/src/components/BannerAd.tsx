import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { adsAPI } from '../services/api';
import colors from '../theme/colors';

interface BannerAdProps {
  position?: 'top' | 'bottom';
}

export default function BannerAd({ position = 'bottom' }: BannerAdProps) {
  const [ad, setAd] = useState<any>(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    fetchBannerAd();
  }, []);

  const fetchBannerAd = async () => {
    try {
      const response = await adsAPI.getBannerAd();
      if (response.data) {
        setAd(response.data);
        recordImpression(response.data.id);
      }
    } catch (error) {
      console.log('Banner ad error:', error);
    }
  };

  const recordImpression = async (adId: string) => {
    try {
      await adsAPI.recordImpression(adId);
    } catch (error) {
      console.log('Impression error:', error);
    }
  };

  const handleClick = async () => {
    if (!ad) return;
    
    try {
      const response = await adsAPI.recordClick(ad.id);
      if (response.data.link_url) {
        Linking.openURL(response.data.link_url);
      }
    } catch (error) {
      console.log('Click error:', error);
      if (ad.link_url) {
        Linking.openURL(ad.link_url);
      }
    }
  };

  const handleClose = () => {
    setVisible(false);
  };

  if (!ad || !visible) return null;

  return (
    <View style={[styles.container, position === 'top' ? styles.topPosition : styles.bottomPosition]}>
      <TouchableOpacity style={styles.banner} onPress={handleClick} activeOpacity={0.9}>
        {/* Ad Badge */}
        <View style={styles.adBadge}>
          <Text style={styles.adBadgeText}>Ad</Text>
        </View>

        {/* Content */}
        <View style={styles.content}>
          {ad.media && (
            <Image source={{ uri: ad.media }} style={styles.image} resizeMode="cover" />
          )}
          <View style={styles.textContainer}>
            <Text style={styles.title} numberOfLines={1}>{ad.title}</Text>
            <Text style={styles.description} numberOfLines={1}>{ad.content}</Text>
          </View>
          <TouchableOpacity style={styles.ctaButton} onPress={handleClick}>
            <Text style={styles.ctaText}>{ad.cta_text}</Text>
          </TouchableOpacity>
        </View>

        {/* Close Button */}
        <TouchableOpacity style={styles.closeButton} onPress={handleClose}>
          <Ionicons name="close" size={16} color={colors.textTertiary} />
        </TouchableOpacity>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 8,
    zIndex: 100,
  },
  topPosition: {
    top: 0,
  },
  bottomPosition: {
    bottom: 70, // Above tab bar
  },
  banner: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.15)',
    elevation: 5,
    borderWidth: 1,
    borderColor: colors.border,
  },
  adBadge: {
    position: 'absolute',
    top: -8,
    left: 12,
    backgroundColor: colors.primary,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  adBadgeText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 8,
    backgroundColor: colors.backgroundAlt,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    color: colors.textPrimary,
    fontSize: 14,
    fontWeight: '600',
  },
  description: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 2,
  },
  ctaButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 6,
  },
  ctaText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  closeButton: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
