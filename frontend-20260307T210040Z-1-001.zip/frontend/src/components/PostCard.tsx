import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDistanceToNow } from 'date-fns';
import { postsAPI } from '../services/api';
import ReportUserModal from './ReportUserModal';
import BoostPostModal from './BoostPostModal';
import colors from '../theme/colors';

const { width } = Dimensions.get('window');

interface Post {
  id: string;
  user_id: string;
  username: string;
  display_name: string;
  user_avatar: string | null;
  content: string;
  media: string | null;
  media_type: string;
  is_premium: boolean;
  likes_count: number;
  comments_count: number;
  created_at: string;
  is_liked: boolean;
  is_boosted?: boolean;
}

interface PostCardProps {
  post: Post;
  currentUserId?: string;
  onPressUser?: (username: string) => void;
  onPressComments?: (postId: string) => void;
  onPostUpdated?: () => void;
}

export default function PostCard({ post, currentUserId, onPressUser, onPressComments, onPostUpdated }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(post.is_liked);
  const [likesCount, setLikesCount] = useState(post.likes_count);
  const [isLiking, setIsLiking] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showBoostModal, setShowBoostModal] = useState(false);
  
  const isOwnPost = currentUserId === post.user_id;

  const handleLike = async () => {
    if (isLiking) return;
    setIsLiking(true);
    
    try {
      if (isLiked) {
        await postsAPI.unlikePost(post.id);
        setIsLiked(false);
        setLikesCount(prev => prev - 1);
      } else {
        await postsAPI.likePost(post.id);
        setIsLiked(true);
        setLikesCount(prev => prev + 1);
      }
    } catch (error) {
      console.log('Like error:', error);
    } finally {
      setIsLiking(false);
    }
  };

  const getTimeAgo = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return '';
    }
  };

  return (
    <View style={styles.container}>
      {/* Boosted Badge */}
      {post.is_boosted && (
        <View style={styles.boostedBadge}>
          <Ionicons name="rocket" size={12} color={colors.accent} />
          <Text style={styles.boostedText}>Boosted</Text>
        </View>
      )}

      {/* Header */}
      <TouchableOpacity
        style={styles.header}
        onPress={() => onPressUser?.(post.username)}
      >
        <View style={styles.avatarContainer}>
          {post.user_avatar ? (
            <Image source={{ uri: post.user_avatar }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <Ionicons name="person" size={20} color={colors.textTertiary} />
            </View>
          )}
        </View>
        <View style={styles.userInfo}>
          <View style={styles.nameRow}>
            <Text style={styles.displayName}>{post.display_name}</Text>
            {post.is_premium && (
              <Ionicons name="star" size={14} color={colors.premium} style={styles.premiumBadge} />
            )}
          </View>
          <Text style={styles.username}>@{post.username}</Text>
        </View>
        <Text style={styles.time}>{getTimeAgo(post.created_at)}</Text>
      </TouchableOpacity>

      {/* Content */}
      {post.content ? <Text style={styles.content}>{post.content}</Text> : null}

      {/* Media */}
      {post.media && (
        <Image
          source={{ uri: post.media }}
          style={styles.media}
          resizeMode="cover"
        />
      )}

      {/* Actions */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionButton} onPress={handleLike}>
          <Ionicons
            name={isLiked ? 'heart' : 'heart-outline'}
            size={24}
            color={isLiked ? colors.accent : colors.textSecondary}
          />
          <Text style={[styles.actionText, isLiked && styles.likedText]}>
            {likesCount}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => onPressComments?.(post.id)}
        >
          <Ionicons name="chatbubble-outline" size={22} color={colors.textSecondary} />
          <Text style={styles.actionText}>{post.comments_count}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton}>
          <Ionicons name="paper-plane-outline" size={22} color={colors.textSecondary} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.actionButton}>
          <Ionicons name="bookmark-outline" size={22} color={colors.textSecondary} />
        </TouchableOpacity>

        {/* Boost Button - Only for own posts */}
        {isOwnPost && (
          <TouchableOpacity 
            style={styles.actionButton} 
            onPress={() => setShowBoostModal(true)}
          >
            <Ionicons name="rocket-outline" size={20} color={colors.primary} />
          </TouchableOpacity>
        )}

        {/* Report Button - Only for other's posts */}
        {!isOwnPost && (
          <TouchableOpacity 
            style={styles.actionButton} 
            onPress={() => setShowReportModal(true)}
          >
            <Ionicons name="flag-outline" size={20} color={colors.textTertiary} />
          </TouchableOpacity>
        )}
      </View>

      {/* Report Modal */}
      <ReportUserModal
        visible={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportedUserId={post.user_id}
        reportedUsername={post.username}
        contentType="comment"
        contentId={post.id}
        contentText={post.content}
      />

      {/* Boost Modal */}
      <BoostPostModal
        visible={showBoostModal}
        postId={post.id}
        onClose={() => setShowBoostModal(false)}
        onSuccess={onPostUpdated}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    marginBottom: 8,
    borderRadius: 0,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  boostedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: `${colors.accent}10`,
    gap: 4,
  },
  boostedText: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.accent,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
  },
  avatarContainer: {
    marginRight: 10,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  avatarPlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
  userInfo: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  displayName: {
    color: colors.textPrimary,
    fontWeight: '600',
    fontSize: 15,
  },
  premiumBadge: {
    marginLeft: 4,
  },
  username: {
    color: colors.textSecondary,
    fontSize: 13,
  },
  time: {
    color: colors.textTertiary,
    fontSize: 12,
  },
  content: {
    color: colors.textPrimary,
    fontSize: 15,
    lineHeight: 21,
    paddingHorizontal: 12,
    paddingBottom: 12,
  },
  media: {
    width: width,
    height: width,
    backgroundColor: colors.backgroundAlt,
  },
  actions: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  actionText: {
    color: colors.textSecondary,
    marginLeft: 6,
    fontSize: 14,
  },
  likedText: {
    color: colors.accent,
  },
});
