import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import api from '../services/api';

interface Gift {
  id: string;
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  coinCost: number;
}

const GIFTS: Gift[] = [
  { id: 'heart', name: 'Heart', icon: 'heart', coinCost: 10 },
  { id: 'star', name: 'Star', icon: 'star', coinCost: 50 },
  { id: 'diamond', name: 'Diamond', icon: 'diamond', coinCost: 100 },
  { id: 'fire', name: 'Fire', icon: 'flame', coinCost: 200 },
  { id: 'crown', name: 'Crown', icon: 'trophy', coinCost: 500 },
  { id: 'rocket', name: 'Rocket', icon: 'rocket', coinCost: 1000 },
];

interface SendGiftModalProps {
  visible: boolean;
  recipientId: string;
  recipientName: string;
  postId?: string;
  coinBalance: number;
  onClose: () => void;
  onSuccess?: () => void;
}

export default function SendGiftModal({
  visible,
  recipientId,
  recipientName,
  postId,
  coinBalance,
  onClose,
  onSuccess,
}: SendGiftModalProps) {
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null);
  const [isSending, setIsSending] = useState(false);

  const handleSendGift = async () => {
    if (!selectedGift) {
      Alert.alert('Select a Gift', 'Please select a gift to send');
      return;
    }

    if (coinBalance < selectedGift.coinCost) {
      Alert.alert(
        'Insufficient Coins',
        `You need ${selectedGift.coinCost} coins to send this gift. You have ${coinBalance} coins.`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Buy Coins', onPress: () => onClose() }, // Navigate to wallet
        ]
      );
      return;
    }

    setIsSending(true);
    try {
      await api.post('/gifts/send', {
        recipient_id: recipientId,
        gift_type: selectedGift.id,
        post_id: postId,
      });

      Alert.alert(
        'Gift Sent! 🎁',
        `You sent a ${selectedGift.name} to ${recipientName}!`
      );
      onSuccess?.();
      onClose();
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to send gift');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>Send a Gift</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color={colors.textPrimary} />
            </TouchableOpacity>
          </View>

          <View style={styles.balanceRow}>
            <Ionicons name="diamond" size={20} color={colors.premium} />
            <Text style={styles.balanceText}>Your balance: {coinBalance.toLocaleString()} coins</Text>
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.giftsScroll}>
            <View style={styles.giftsRow}>
              {GIFTS.map((gift) => (
                <TouchableOpacity
                  key={gift.id}
                  style={[
                    styles.giftItem,
                    selectedGift?.id === gift.id && styles.giftItemSelected,
                    coinBalance < gift.coinCost && styles.giftItemDisabled,
                  ]}
                  onPress={() => setSelectedGift(gift)}
                  disabled={coinBalance < gift.coinCost}
                >
                  <View
                    style={[
                      styles.giftIconContainer,
                      selectedGift?.id === gift.id && styles.giftIconContainerSelected,
                    ]}
                  >
                    <Ionicons
                      name={gift.icon}
                      size={32}
                      color={
                        coinBalance < gift.coinCost
                          ? colors.textTertiary
                          : selectedGift?.id === gift.id
                          ? colors.premium
                          : colors.textSecondary
                      }
                    />
                  </View>
                  <Text style={styles.giftName}>{gift.name}</Text>
                  <View style={styles.giftCost}>
                    <Ionicons name="diamond" size={12} color={colors.premium} />
                    <Text style={styles.giftCostText}>{gift.coinCost}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>

          <View style={styles.recipientInfo}>
            <Text style={styles.recipientLabel}>Sending to</Text>
            <Text style={styles.recipientName}>{recipientName}</Text>
          </View>

          <TouchableOpacity
            style={[
              styles.sendButton,
              (!selectedGift || isSending) && styles.sendButtonDisabled,
            ]}
            onPress={handleSendGift}
            disabled={!selectedGift || isSending}
          >
            {isSending ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="gift" size={20} color="#fff" />
                <Text style={styles.sendButtonText}>
                  {selectedGift
                    ? `Send ${selectedGift.name} (${selectedGift.coinCost} coins)`
                    : 'Select a Gift'}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  balanceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 8,
    backgroundColor: colors.backgroundAlt,
  },
  balanceText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  giftsScroll: {
    paddingVertical: 20,
  },
  giftsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
  },
  giftItem: {
    alignItems: 'center',
    width: 80,
  },
  giftItemSelected: {
    opacity: 1,
  },
  giftItemDisabled: {
    opacity: 0.4,
  },
  giftIconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.backgroundAlt,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    marginBottom: 8,
  },
  giftIconContainerSelected: {
    borderColor: colors.premium,
    backgroundColor: `${colors.premium}15`,
  },
  giftName: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  giftCost: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  giftCostText: {
    fontSize: 12,
    color: colors.premium,
    fontWeight: '600',
  },
  recipientInfo: {
    alignItems: 'center',
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    marginHorizontal: 20,
  },
  recipientLabel: {
    fontSize: 12,
    color: colors.textTertiary,
  },
  recipientName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
    marginTop: 4,
  },
  sendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.premium,
    marginHorizontal: 20,
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  sendButtonDisabled: {
    backgroundColor: colors.textTertiary,
  },
  sendButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
