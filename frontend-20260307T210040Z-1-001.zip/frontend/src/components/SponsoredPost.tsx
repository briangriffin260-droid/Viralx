import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { adsAPI } from '../services/api';
import colors from '../theme/colors';

interface SponsoredPostProps {
  ad: {
    id: string;
    advertiser_name: string;
    title: string;
    content: string;
    media?: string;
    link_url: string;
    cta_text: string;
  };
}

export default function SponsoredPost({ ad }: SponsoredPostProps) {
  useEffect(() => {
    // Record impression when ad is viewed
    recordImpression();
  }, []);

  const recordImpression = async () => {
    try {
      await adsAPI.recordImpression(ad.id);
    } catch (error) {
      console.log('Impression error:', error);
    }
  };

  const handleClick = async () => {
    try {
      const response = await adsAPI.recordClick(ad.id);
      if (response.data.link_url) {
        Linking.openURL(response.data.link_url);
      }
    } catch (error) {
      console.log('Click error:', error);
      Linking.openURL(ad.link_url);
    }
  };

  return (
    <View style={styles.container}>
      {/* Sponsored Label */}
      <View style={styles.sponsoredHeader}>
        <View style={styles.sponsoredBadge}>
          <Ionicons name="megaphone" size={12} color={colors.primary} />
          <Text style={styles.sponsoredText}>Sponsored</Text>
        </View>
        <Text style={styles.advertiserName}>{ad.advertiser_name}</Text>
      </View>

      {/* Content */}
      <TouchableOpacity onPress={handleClick} activeOpacity={0.9}>
        <Text style={styles.title}>{ad.title}</Text>
        <Text style={styles.content}>{ad.content}</Text>

        {/* Media */}
        {ad.media && (
          <Image source={{ uri: ad.media }} style={styles.media} resizeMode="cover" />
        )}

        {/* CTA Button */}
        <View style={styles.ctaContainer}>
          <TouchableOpacity style={styles.ctaButton} onPress={handleClick}>
            <Text style={styles.ctaText}>{ad.cta_text}</Text>
            <Ionicons name="arrow-forward" size={16} color="#fff" />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>

      {/* Ad Info */}
      <View style={styles.adInfo}>
        <TouchableOpacity style={styles.adInfoButton}>
          <Ionicons name="information-circle-outline" size={16} color={colors.textTertiary} />
          <Text style={styles.adInfoText}>Why this ad?</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.adInfoButton}>
          <Ionicons name="eye-off-outline" size={16} color={colors.textTertiary} />
          <Text style={styles.adInfoText}>Hide</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    marginBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    borderTopWidth: 1,
    borderTopColor: colors.primary,
  },
  sponsoredHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    gap: 8,
  },
  sponsoredBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: `${colors.primary}15`,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  sponsoredText: {
    color: colors.primary,
    fontSize: 11,
    fontWeight: '600',
  },
  advertiserName: {
    color: colors.textSecondary,
    fontSize: 13,
  },
  title: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    paddingHorizontal: 12,
    marginBottom: 6,
  },
  content: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 20,
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  media: {
    width: '100%',
    height: 200,
    backgroundColor: colors.backgroundAlt,
  },
  ctaContainer: {
    padding: 12,
  },
  ctaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  ctaText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  adInfo: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingHorizontal: 12,
    paddingBottom: 10,
    gap: 16,
  },
  adInfoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  adInfoText: {
    color: colors.textTertiary,
    fontSize: 12,
  },
});
