import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { reportsAPI } from '../services/api';
import colors from '../theme/colors';

interface ReportUserModalProps {
  visible: boolean;
  onClose: () => void;
  reportedUserId: string;
  reportedUsername: string;
  contentType?: 'comment' | 'message' | 'profile';
  contentId?: string;
  contentText?: string;
}

const REPORT_REASONS = [
  { id: 'harassment', label: 'Harassment or Bullying', icon: 'warning' },
  { id: 'hate_speech', label: 'Hate Speech or Discrimination', icon: 'megaphone' },
  { id: 'threats', label: 'Threats or Violence', icon: 'alert-circle' },
  { id: 'inappropriate', label: 'Inappropriate Content', icon: 'eye-off' },
  { id: 'spam', label: 'Spam or Scam', icon: 'mail' },
  { id: 'disrespectful', label: 'Disrespectful to Creators', icon: 'person-remove' },
  { id: 'other', label: 'Other', icon: 'ellipsis-horizontal' },
];

export default function ReportUserModal({
  visible,
  onClose,
  reportedUserId,
  reportedUsername,
  contentType = 'profile',
  contentId,
  contentText,
}: ReportUserModalProps) {
  const [selectedReason, setSelectedReason] = useState<string | null>(null);
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selectedReason) {
      Alert.alert('Error', 'Please select a reason for your report');
      return;
    }

    setIsSubmitting(true);
    try {
      const reason = REPORT_REASONS.find(r => r.id === selectedReason)?.label || selectedReason;
      const fullReason = additionalInfo 
        ? `${reason}: ${additionalInfo}` 
        : reason;

      await reportsAPI.reportUser({
        reported_user_id: reportedUserId,
        reason: fullReason,
        content_type: contentType,
        content_id: contentId,
        content_text: contentText,
      });

      Alert.alert(
        'Report Submitted',
        'Thank you for helping keep our community safe. We will review your report and take appropriate action.',
        [{ text: 'OK', onPress: onClose }]
      );
    } catch (error: any) {
      const message = error.response?.data?.detail || 'Failed to submit report';
      Alert.alert('Error', message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetAndClose = () => {
    setSelectedReason(null);
    setAdditionalInfo('');
    onClose();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={resetAndClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Report @{reportedUsername}</Text>
            <TouchableOpacity onPress={resetAndClose}>
              <Ionicons name="close" size={24} color={colors.textPrimary} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content}>
            {/* Warning */}
            <View style={styles.warningBox}>
              <Ionicons name="shield" size={24} color={colors.accent} />
              <Text style={styles.warningText}>
                Reports help us maintain a safe and respectful community. 
                Users with multiple reports may be banned for 30 days.
              </Text>
            </View>

            {/* Reason Selection */}
            <Text style={styles.sectionTitle}>Why are you reporting this user?</Text>
            
            {REPORT_REASONS.map((reason) => (
              <TouchableOpacity
                key={reason.id}
                style={[
                  styles.reasonItem,
                  selectedReason === reason.id && styles.reasonItemSelected,
                ]}
                onPress={() => setSelectedReason(reason.id)}
              >
                <Ionicons
                  name={reason.icon as any}
                  size={22}
                  color={selectedReason === reason.id ? colors.accent : colors.textSecondary}
                />
                <Text
                  style={[
                    styles.reasonText,
                    selectedReason === reason.id && styles.reasonTextSelected,
                  ]}
                >
                  {reason.label}
                </Text>
                {selectedReason === reason.id && (
                  <Ionicons name="checkmark-circle" size={22} color={colors.accent} />
                )}
              </TouchableOpacity>
            ))}

            {/* Additional Info */}
            <Text style={styles.sectionTitle}>Additional details (optional)</Text>
            <TextInput
              style={styles.textInput}
              placeholder="Provide more context about your report..."
              placeholderTextColor={colors.textTertiary}
              multiline
              numberOfLines={4}
              value={additionalInfo}
              onChangeText={setAdditionalInfo}
              textAlignVertical="top"
            />

            {/* Content Preview if available */}
            {contentText && (
              <View style={styles.contentPreview}>
                <Text style={styles.contentPreviewLabel}>Reported content:</Text>
                <Text style={styles.contentPreviewText} numberOfLines={3}>
                  "{contentText}"
                </Text>
              </View>
            )}

            {/* Submit Button */}
            <TouchableOpacity
              style={[styles.submitButton, (!selectedReason || isSubmitting) && styles.submitButtonDisabled]}
              onPress={handleSubmit}
              disabled={!selectedReason || isSubmitting}
            >
              {isSubmitting ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="flag" size={20} color="#fff" />
                  <Text style={styles.submitButtonText}>Submit Report</Text>
                </>
              )}
            </TouchableOpacity>

            {/* Cancel Button */}
            <TouchableOpacity style={styles.cancelButton} onPress={resetAndClose}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  content: {
    padding: 16,
  },
  warningBox: {
    flexDirection: 'row',
    backgroundColor: `${colors.accent}10`,
    padding: 12,
    borderRadius: 12,
    marginBottom: 20,
    gap: 12,
  },
  warningText: {
    flex: 1,
    color: colors.textSecondary,
    fontSize: 13,
    lineHeight: 18,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
    marginBottom: 12,
  },
  reasonItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    marginBottom: 8,
    gap: 12,
  },
  reasonItemSelected: {
    backgroundColor: `${colors.accent}15`,
    borderWidth: 1,
    borderColor: colors.accent,
  },
  reasonText: {
    flex: 1,
    fontSize: 15,
    color: colors.textSecondary,
  },
  reasonTextSelected: {
    color: colors.textPrimary,
    fontWeight: '500',
  },
  textInput: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 14,
    fontSize: 15,
    color: colors.textPrimary,
    minHeight: 100,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  contentPreview: {
    backgroundColor: colors.backgroundAlt,
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  contentPreviewLabel: {
    fontSize: 12,
    color: colors.textTertiary,
    marginBottom: 4,
  },
  contentPreviewText: {
    fontSize: 14,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  submitButtonDisabled: {
    opacity: 0.5,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  cancelButton: {
    alignItems: 'center',
    paddingVertical: 16,
    marginBottom: 20,
  },
  cancelButtonText: {
    color: colors.textSecondary,
    fontSize: 16,
  },
});
