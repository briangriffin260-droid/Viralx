import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';

interface TermsModalProps {
  visible: boolean;
  onAccept: () => void;
  onDecline: () => void;
}

export default function TermsModal({ visible, onAccept, onDecline }: TermsModalProps) {
  const [scrolledToBottom, setScrolledToBottom] = useState(false);

  const handleScroll = (event: any) => {
    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
    const isAtBottom = layoutMeasurement.height + contentOffset.y >= contentSize.height - 50;
    if (isAtBottom) {
      setScrolledToBottom(true);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Terms of Service & Waiver</Text>
          <TouchableOpacity onPress={onDecline}>
            <Ionicons name="close" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>

        {/* Scroll Notice */}
        {!scrolledToBottom && (
          <View style={styles.scrollNotice}>
            <Ionicons name="arrow-down" size={16} color={colors.primary} />
            <Text style={styles.scrollNoticeText}>Please read and scroll to the bottom</Text>
          </View>
        )}

        {/* Terms Content */}
        <ScrollView 
          style={styles.content}
          onScroll={handleScroll}
          scrollEventThrottle={16}
        >
          <Text style={styles.lastUpdated}>Last Updated: February 2025</Text>

          <Text style={styles.sectionTitle}>TERMS OF SERVICE AGREEMENT</Text>
          <Text style={styles.paragraph}>
            Welcome to AllTogether ("Platform", "App", "Service", "we", "us", or "our"). By creating an account and using our services, you ("User", "you", or "your") agree to be bound by these Terms of Service and all applicable laws and regulations.
          </Text>

          <Text style={styles.sectionTitle}>1. ACCEPTANCE OF TERMS</Text>
          <Text style={styles.paragraph}>
            By accessing or using AllTogether, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. If you do not agree to these terms, you must not use this platform.
          </Text>

          <Text style={styles.sectionTitle}>2. ELIGIBILITY</Text>
          <Text style={styles.paragraph}>
            You must be at least 18 years of age to use this platform. By creating an account, you represent and warrant that you are at least 18 years old and have the legal capacity to enter into this agreement.
          </Text>

          <Text style={styles.sectionTitle}>3. ASSUMPTION OF RISK</Text>
          <Text style={styles.warningBox}>
            <Text style={styles.warningTitle}>⚠️ IMPORTANT - PLEASE READ CAREFULLY{'\n\n'}</Text>
            YOU EXPRESSLY UNDERSTAND AND AGREE THAT YOUR USE OF THIS PLATFORM IS AT YOUR SOLE RISK. The platform is provided on an "AS IS" and "AS AVAILABLE" basis without warranties of any kind.
            {'\n\n'}
            You acknowledge that:{'\n'}
            • Interactions with other users are at your own risk{'\n'}
            • Content posted by users does not represent our views{'\n'}
            • We do not verify the identity or background of users{'\n'}
            • Premium content is provided by independent creators{'\n'}
            • Financial transactions are processed by third parties
          </Text>

          <Text style={styles.sectionTitle}>4. WAIVER OF LIABILITY</Text>
          <Text style={styles.warningBox}>
            <Text style={styles.warningTitle}>RELEASE AND WAIVER{'\n\n'}</Text>
            TO THE MAXIMUM EXTENT PERMITTED BY LAW, YOU HEREBY RELEASE, WAIVE, DISCHARGE, AND COVENANT NOT TO SUE AllTogether, its owners, operators, officers, directors, employees, agents, affiliates, and successors from any and all liability, claims, demands, actions, or causes of action whatsoever arising out of or related to any loss, damage, or injury that may be sustained by you, or to any property belonging to you, while using this platform.
            {'\n\n'}
            This waiver includes, but is not limited to:{'\n'}
            • Personal injury or emotional distress{'\n'}
            • Financial losses from transactions{'\n'}
            • Disputes with other users or creators{'\n'}
            • Content that may be offensive or harmful{'\n'}
            • Technical issues or service interruptions{'\n'}
            • Unauthorized access to your account{'\n'}
            • Any interactions or meetings with other users
          </Text>

          <Text style={styles.sectionTitle}>5. USER CONDUCT</Text>
          <Text style={styles.paragraph}>
            You agree not to:{'\n'}
            • Post illegal, harmful, or offensive content{'\n'}
            • Harass, bully, or threaten other users{'\n'}
            • Impersonate others or provide false information{'\n'}
            • Violate any applicable laws or regulations{'\n'}
            • Attempt to hack or disrupt the platform{'\n'}
            • Use the platform for any illegal activities
          </Text>

          <Text style={styles.sectionTitle}>6. CONTENT DISCLAIMER</Text>
          <Text style={styles.paragraph}>
            AllTogether may contain content created by users that is intended for mature audiences (18+). We do not pre-screen content and are not responsible for content posted by users. You access such content at your own risk and discretion.
          </Text>

          <Text style={styles.sectionTitle}>7. PAYMENT TERMS</Text>
          <Text style={styles.paragraph}>
            • All payments are processed by third-party payment processors{'\n'}
            • Subscriptions are billed on a recurring basis{'\n'}
            • Tips and donations are non-refundable{'\n'}
            • The platform takes a {15}% service fee on transactions{'\n'}
            • Creator payouts are subject to payment processor terms
          </Text>

          <Text style={styles.sectionTitle}>8. INDEMNIFICATION</Text>
          <Text style={styles.paragraph}>
            You agree to indemnify, defend, and hold harmless AllTogether and its affiliates from any claims, damages, losses, liabilities, costs, and expenses (including attorneys' fees) arising from your use of the platform, violation of these terms, or infringement of any rights of another party.
          </Text>

          <Text style={styles.sectionTitle}>9. LIMITATION OF LIABILITY</Text>
          <Text style={styles.warningBox}>
            IN NO EVENT SHALL AllTogether BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION, LOSS OF PROFITS, DATA, USE, GOODWILL, OR OTHER INTANGIBLE LOSSES, RESULTING FROM YOUR USE OF THE PLATFORM.
            {'\n\n'}
            OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID TO US IN THE PAST TWELVE (12) MONTHS, OR $100, WHICHEVER IS LESS.
          </Text>

          <Text style={styles.sectionTitle}>10. DISPUTE RESOLUTION</Text>
          <Text style={styles.paragraph}>
            Any disputes arising from these terms or your use of the platform shall be resolved through binding arbitration in accordance with the rules of the American Arbitration Association. You waive any right to participate in class action lawsuits against us.
          </Text>

          <Text style={styles.sectionTitle}>11. TERMINATION</Text>
          <Text style={styles.paragraph}>
            We reserve the right to suspend or terminate your account at any time, for any reason, without notice. Upon termination, your right to use the platform will immediately cease.
          </Text>

          <Text style={styles.sectionTitle}>12. MODIFICATIONS</Text>
          <Text style={styles.paragraph}>
            We reserve the right to modify these terms at any time. Continued use of the platform after changes constitutes acceptance of the modified terms.
          </Text>

          <Text style={styles.sectionTitle}>13. GOVERNING LAW</Text>
          <Text style={styles.paragraph}>
            These terms shall be governed by and construed in accordance with the laws of the United States, without regard to conflict of law principles.
          </Text>

          <Text style={styles.sectionTitle}>ACKNOWLEDGMENT</Text>
          <Text style={styles.acknowledgment}>
            BY CLICKING "I AGREE" OR BY USING THIS PLATFORM, YOU ACKNOWLEDGE THAT:{'\n\n'}
            ✓ You have read and understand these Terms of Service{'\n\n'}
            ✓ You are at least 18 years of age{'\n\n'}
            ✓ You voluntarily agree to be bound by these terms{'\n\n'}
            ✓ You waive your right to sue the platform{'\n\n'}
            ✓ You assume all risks associated with using this platform{'\n\n'}
            ✓ You understand this is a legally binding agreement
          </Text>

          {/* Extra space at bottom */}
          <View style={{ height: 40 }} />
        </ScrollView>

        {/* Action Buttons */}
        <View style={styles.footer}>
          <TouchableOpacity
            style={[styles.acceptButton, !scrolledToBottom && styles.acceptButtonDisabled]}
            onPress={onAccept}
            disabled={!scrolledToBottom}
          >
            <Ionicons name="checkmark-circle" size={20} color="#fff" />
            <Text style={styles.acceptButtonText}>
              {scrolledToBottom ? "I Agree to Terms & Waiver" : "Scroll to Read All Terms"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.declineButton} onPress={onDecline}>
            <Text style={styles.declineButtonText}>I Do Not Agree</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.card,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  scrollNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: `${colors.primary}15`,
    paddingVertical: 8,
    gap: 6,
  },
  scrollNoticeText: {
    color: colors.primary,
    fontSize: 13,
    fontWeight: '500',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  lastUpdated: {
    color: colors.textTertiary,
    fontSize: 12,
    marginTop: 16,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginTop: 20,
    marginBottom: 10,
  },
  paragraph: {
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 22,
  },
  warningBox: {
    backgroundColor: `${colors.accent}10`,
    padding: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: colors.accent,
    fontSize: 14,
    color: colors.textPrimary,
    lineHeight: 22,
  },
  warningTitle: {
    fontWeight: 'bold',
    color: colors.accent,
  },
  acknowledgment: {
    backgroundColor: colors.card,
    padding: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.primary,
    fontSize: 14,
    color: colors.textPrimary,
    lineHeight: 24,
    marginTop: 20,
  },
  footer: {
    padding: 20,
    paddingBottom: 34,
    backgroundColor: colors.card,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    gap: 12,
  },
  acceptButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  acceptButtonDisabled: {
    backgroundColor: colors.textTertiary,
  },
  acceptButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  declineButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  declineButtonText: {
    color: colors.textSecondary,
    fontSize: 14,
  },
});
