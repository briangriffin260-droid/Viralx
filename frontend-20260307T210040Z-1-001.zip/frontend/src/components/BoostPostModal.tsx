import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';
import api from '../services/api';

const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL || 'http://localhost:8001';

interface BoostPostModalProps {
  visible: boolean;
  postId: string;
  onClose: () => void;
  onSuccess?: () => void;
}

export default function BoostPostModal({ visible, postId, onClose, onSuccess }: BoostPostModalProps) {
  const [budget, setBudget] = useState('10');
  const [duration, setDuration] = useState('7');
  const [isLoading, setIsLoading] = useState(false);

  const handleBoost = async () => {
    const budgetNum = parseFloat(budget);
    const durationNum = parseInt(duration);

    if (isNaN(budgetNum) || budgetNum < 5) {
      Alert.alert('Error', 'Minimum budget is $5');
      return;
    }
    if (isNaN(durationNum) || durationNum < 1 || durationNum > 30) {
      Alert.alert('Error', 'Duration must be between 1-30 days');
      return;
    }

    setIsLoading(true);
    try {
      const response = await api.post('/boost/post', {
        post_id: postId,
        budget: budgetNum,
        duration_days: durationNum,
        origin_url: `${API_URL}/post/${postId}`,
      });

      if (response.data.checkout_url) {
        await Linking.openURL(response.data.checkout_url);
        Alert.alert('Payment', 'Complete the payment in your browser to activate the boost.');
        onSuccess?.();
      }
    } catch (error: any) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to boost post');
    } finally {
      setIsLoading(false);
      onClose();
    }
  };

  const estimatedReach = Math.floor(parseFloat(budget || '0') * 150);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.title}>Boost This Post</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color={colors.textPrimary} />
            </TouchableOpacity>
          </View>

          <View style={styles.content}>
            <View style={styles.iconContainer}>
              <Ionicons name="rocket" size={48} color={colors.accent} />
            </View>

            <Text style={styles.description}>
              Boost your post to reach more people and get more engagement!
            </Text>

            <Text style={styles.inputLabel}>Budget ($)</Text>
            <TextInput
              style={styles.input}
              value={budget}
              onChangeText={setBudget}
              keyboardType="decimal-pad"
              placeholder="Minimum $5"
              placeholderTextColor={colors.textTertiary}
            />

            <Text style={styles.inputLabel}>Duration (days)</Text>
            <TextInput
              style={styles.input}
              value={duration}
              onChangeText={setDuration}
              keyboardType="number-pad"
              placeholder="1-30 days"
              placeholderTextColor={colors.textTertiary}
            />

            <View style={styles.estimateBox}>
              <View style={styles.estimateRow}>
                <Text style={styles.estimateLabel}>Estimated Reach</Text>
                <Text style={styles.estimateValue}>~{estimatedReach.toLocaleString()} people</Text>
              </View>
              <View style={styles.estimateRow}>
                <Text style={styles.estimateLabel}>Cost per impression</Text>
                <Text style={styles.estimateValue}>
                  ${(parseFloat(budget || '0') / (estimatedReach || 1) * 1000).toFixed(2)} CPM
                </Text>
              </View>
            </View>

            <TouchableOpacity
              style={[styles.boostButton, isLoading && styles.boostButtonDisabled]}
              onPress={handleBoost}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="rocket" size={20} color="#fff" />
                  <Text style={styles.boostButtonText}>Boost for ${budget}</Text>
                </>
              )}
            </TouchableOpacity>

            <Text style={styles.note}>
              Your boosted post will appear in more feeds and explore pages.
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: colors.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  iconContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  description: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textPrimary,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: colors.textPrimary,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  estimateBox: {
    backgroundColor: `${colors.success}10`,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  estimateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  estimateLabel: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  estimateValue: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.success,
  },
  boostButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.accent,
    borderRadius: 12,
    padding: 16,
    gap: 8,
  },
  boostButtonDisabled: {
    opacity: 0.7,
  },
  boostButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  note: {
    fontSize: 12,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: 16,
  },
});
