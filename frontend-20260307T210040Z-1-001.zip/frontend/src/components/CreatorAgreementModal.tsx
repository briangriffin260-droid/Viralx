import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import colors from '../theme/colors';

interface CreatorAgreementModalProps {
  visible: boolean;
  onAccept: () => void;
  onDecline: () => void;
  subscriptionPrice: string;
}

export default function CreatorAgreementModal({ 
  visible, 
  onAccept, 
  onDecline,
  subscriptionPrice 
}: CreatorAgreementModalProps) {
  const [scrolledToBottom, setScrolledToBottom] = useState(false);

  const handleScroll = (event: any) => {
    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;
    const isAtBottom = layoutMeasurement.height + contentOffset.y >= contentSize.height - 50;
    if (isAtBottom) {
      setScrolledToBottom(true);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Creator Agreement</Text>
          <TouchableOpacity onPress={onDecline}>
            <Ionicons name="close" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
        </View>

        {/* Scroll Notice */}
        {!scrolledToBottom && (
          <View style={styles.scrollNotice}>
            <Ionicons name="arrow-down" size={16} color={colors.premium} />
            <Text style={styles.scrollNoticeText}>Please read and scroll to the bottom</Text>
          </View>
        )}

        {/* Agreement Content */}
        <ScrollView 
          style={styles.content}
          onScroll={handleScroll}
          scrollEventThrottle={16}
        >
          <View style={styles.iconContainer}>
            <Ionicons name="star" size={48} color={colors.premium} />
          </View>
          
          <Text style={styles.title}>Premium Creator Agreement</Text>
          <Text style={styles.subtitle}>Please read and agree to the following terms</Text>

          <Text style={styles.sectionTitle}>1. REVENUE SHARING</Text>
          <Text style={styles.paragraph}>
            By becoming a Premium Creator on AllTogether, you agree to the following revenue split:
          </Text>
          <View style={styles.revenueBox}>
            <View style={styles.revenueRow}>
              <Text style={styles.revenueLabel}>Your Earnings:</Text>
              <Text style={styles.revenueValue}>85%</Text>
            </View>
            <View style={styles.revenueDivider} />
            <View style={styles.revenueRow}>
              <Text style={styles.revenueLabel}>Platform Fee:</Text>
              <Text style={styles.revenueValue}>15%</Text>
            </View>
          </View>
          <Text style={styles.paragraph}>
            This applies to all subscription payments and tips received through the platform.
          </Text>

          <Text style={styles.sectionTitle}>2. SUBSCRIPTION PRICING</Text>
          <Text style={styles.paragraph}>
            You have set your monthly subscription price at:
          </Text>
          <View style={styles.priceBox}>
            <Text style={styles.priceAmount}>${subscriptionPrice}/month</Text>
          </View>
          <Text style={styles.paragraph}>
            You may change this price at any time. Changes will apply to new subscribers only.
          </Text>

          <Text style={styles.sectionTitle}>3. CONTENT OWNERSHIP</Text>
          <Text style={styles.paragraph}>
            You retain full ownership of all content you create and post. By posting content, you grant AllTogether a non-exclusive license to display, distribute, and promote your content on the platform.
          </Text>

          <Text style={styles.sectionTitle}>4. PLATFORM OWNER ACCESS</Text>
          <View style={styles.importantBox}>
            <Ionicons name="shield-checkmark" size={24} color={colors.primary} />
            <Text style={styles.importantTitle}>IMPORTANT - PLEASE READ</Text>
            <Text style={styles.importantText}>
              By becoming a Premium Creator, you agree and acknowledge that:
              {'\n\n'}
              <Text style={styles.bold}>• The Platform Owner(s) and designated administrators shall have FREE, unrestricted access to ALL your premium content</Text> for the purposes of:
              {'\n\n'}
              - Content moderation and policy enforcement{'\n'}
              - Quality assurance and platform improvement{'\n'}
              - Legal compliance and safety reviews{'\n'}
              - Marketing and promotional activities{'\n'}
              - Any other legitimate business purpose
              {'\n\n'}
              <Text style={styles.bold}>• This access is granted without payment</Text> and is a condition of using the platform's premium creator features.
              {'\n\n'}
              <Text style={styles.bold}>• Platform administrators may view, download, and review</Text> any content you post, including content marked as "premium" or "subscriber-only."
              {'\n\n'}
              This agreement is necessary to maintain platform safety, ensure content compliance, and provide quality service to all users.
            </Text>
          </View>

          <Text style={styles.sectionTitle}>5. CONTENT GUIDELINES</Text>
          <Text style={styles.paragraph}>
            As a Premium Creator, you agree to:{'\n\n'}
            • Not post illegal content{'\n'}
            • Not post content involving minors{'\n'}
            • Not engage in harassment or hate speech{'\n'}
            • Comply with all platform community guidelines{'\n'}
            • Respond to content moderation requests promptly
          </Text>

          <Text style={styles.sectionTitle}>6. PAYOUTS</Text>
          <Text style={styles.paragraph}>
            • Minimum payout threshold: $10{'\n'}
            • Payouts processed via Stripe Connect{'\n'}
            • You must complete identity verification{'\n'}
            • Payouts typically arrive within 2-7 business days{'\n'}
            • You are responsible for reporting income for tax purposes
          </Text>

          <Text style={styles.sectionTitle}>7. TERMINATION</Text>
          <Text style={styles.paragraph}>
            AllTogether reserves the right to:{'\n\n'}
            • Suspend or terminate your creator account at any time{'\n'}
            • Withhold payouts if terms are violated{'\n'}
            • Remove content that violates guidelines{'\n\n'}
            You may deactivate your creator status at any time, but existing subscribers will retain access until their subscription expires.
          </Text>

          <Text style={styles.sectionTitle}>8. LIABILITY</Text>
          <Text style={styles.paragraph}>
            You agree to indemnify and hold harmless AllTogether from any claims arising from your content or interactions with subscribers.
          </Text>

          <Text style={styles.sectionTitle}>ACKNOWLEDGMENT</Text>
          <View style={styles.acknowledgmentBox}>
            <Text style={styles.acknowledgmentText}>
              BY CLICKING "I AGREE" BELOW, YOU ACKNOWLEDGE THAT:
              {'\n\n'}
              ✓ You have read and understand this Creator Agreement
              {'\n\n'}
              ✓ You agree to the 85/15 revenue split
              {'\n\n'}
              ✓ You grant Platform Owners FREE access to your premium content
              {'\n\n'}
              ✓ You will comply with all content guidelines
              {'\n\n'}
              ✓ You understand this is a legally binding agreement
              {'\n\n'}
              ✓ You are at least 18 years of age
            </Text>
          </View>

          <View style={{ height: 40 }} />
        </ScrollView>

        {/* Action Buttons */}
        <View style={styles.footer}>
          <TouchableOpacity
            style={[styles.acceptButton, !scrolledToBottom && styles.acceptButtonDisabled]}
            onPress={onAccept}
            disabled={!scrolledToBottom}
          >
            <Ionicons name="checkmark-circle" size={20} color="#fff" />
            <Text style={styles.acceptButtonText}>
              {scrolledToBottom ? "I Agree & Become a Creator" : "Scroll to Read All Terms"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.declineButton} onPress={onDecline}>
            <Text style={styles.declineButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.card,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  scrollNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: `${colors.premium}15`,
    paddingVertical: 8,
    gap: 6,
  },
  scrollNoticeText: {
    color: colors.premium,
    fontSize: 13,
    fontWeight: '500',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  iconContainer: {
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginTop: 20,
    marginBottom: 10,
  },
  paragraph: {
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 22,
  },
  bold: {
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  revenueBox: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginVertical: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  revenueRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  revenueLabel: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  revenueValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.success,
  },
  revenueDivider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 12,
  },
  priceBox: {
    backgroundColor: `${colors.premium}15`,
    borderRadius: 12,
    padding: 16,
    marginVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.premium,
  },
  priceAmount: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.premium,
  },
  importantBox: {
    backgroundColor: `${colors.primary}10`,
    borderRadius: 12,
    padding: 16,
    marginVertical: 12,
    borderLeftWidth: 4,
    borderLeftColor: colors.primary,
  },
  importantTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.primary,
    marginTop: 8,
    marginBottom: 12,
  },
  importantText: {
    fontSize: 14,
    color: colors.textPrimary,
    lineHeight: 22,
  },
  acknowledgmentBox: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginTop: 16,
    borderWidth: 2,
    borderColor: colors.premium,
  },
  acknowledgmentText: {
    fontSize: 14,
    color: colors.textPrimary,
    lineHeight: 24,
  },
  footer: {
    padding: 20,
    paddingBottom: 34,
    backgroundColor: colors.card,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    gap: 12,
  },
  acceptButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.premium,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  acceptButtonDisabled: {
    backgroundColor: colors.textTertiary,
  },
  acceptButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  declineButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  declineButtonText: {
    color: colors.textSecondary,
    fontSize: 14,
  },
});
