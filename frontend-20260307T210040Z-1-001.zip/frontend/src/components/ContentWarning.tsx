import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import colors from '../theme/colors';

interface ContentWarningProps {
  type: 'creator' | 'videos' | 'premium_post' | 'subscribe' | 'tip';
  creatorName?: string;
  onAccept: () => void;
  onDecline: () => void;
  visible: boolean;
}

const WARNING_KEYS = {
  creator: '@warning_dismissed_creator',
  videos: '@warning_dismissed_videos',
  premium_post: '@warning_dismissed_premium',
  subscribe: '@warning_dismissed_subscribe',
  tip: '@warning_dismissed_tip',
};

const WARNING_CONTENT = {
  creator: {
    icon: 'star',
    iconColor: colors.premium,
    title: 'Premium Creator Content',
    message: 'This creator may post content intended for mature audiences (18+). By continuing, you acknowledge that you are of legal age.',
    acceptText: 'I Understand, Continue',
    declineText: 'Go Back',
  },
  videos: {
    icon: 'videocam',
    iconColor: colors.primary,
    title: 'Video Content Warning',
    message: 'The video feed may contain content from premium creators intended for mature audiences. Viewer discretion is advised.',
    acceptText: 'I Understand, Continue',
    declineText: 'Go Back',
  },
  premium_post: {
    icon: 'lock-closed',
    iconColor: colors.accent,
    title: 'Premium Content',
    message: 'This content is marked as premium and may contain mature material. Only subscribers can view this content.',
    acceptText: 'Continue',
    declineText: 'Cancel',
  },
  subscribe: {
    icon: 'card',
    iconColor: colors.premium,
    title: 'Subscription Notice',
    message: 'By subscribing, you will gain access to this creator\'s premium content, which may include mature material intended for adults only.',
    acceptText: 'I Understand, Subscribe',
    declineText: 'Cancel',
  },
  tip: {
    icon: 'cash',
    iconColor: colors.success,
    title: 'Send a Tip',
    message: 'You are about to send a tip to this creator. Tips are non-refundable and support creators directly.',
    acceptText: 'Continue',
    declineText: 'Cancel',
  },
};

export default function ContentWarning({
  type,
  creatorName,
  onAccept,
  onDecline,
  visible,
}: ContentWarningProps) {
  const [fadeAnim] = useState(new Animated.Value(0));
  const content = WARNING_CONTENT[type];

  useEffect(() => {
    if (visible) {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();
    }
  }, [visible]);

  const handleAccept = async () => {
    // For certain warnings, remember the user's choice
    if (type === 'videos') {
      try {
        await AsyncStorage.setItem(WARNING_KEYS[type], 'true');
      } catch (error) {
        console.log('Error saving warning preference:', error);
      }
    }
    onAccept();
  };

  if (!visible) return null;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onDecline}
    >
      <Animated.View style={[styles.overlay, { opacity: fadeAnim }]}>
        <View style={styles.container}>
          {/* Warning Icon */}
          <View style={[styles.iconContainer, { backgroundColor: `${content.iconColor}15` }]}>
            <Ionicons name={content.icon as any} size={40} color={content.iconColor} />
          </View>

          {/* Title */}
          <Text style={styles.title}>{content.title}</Text>
          
          {/* Creator Name if applicable */}
          {creatorName && (
            <Text style={styles.creatorName}>@{creatorName}</Text>
          )}

          {/* Message */}
          <Text style={styles.message}>{content.message}</Text>

          {/* Age Reminder */}
          <View style={styles.ageReminder}>
            <Ionicons name="shield-checkmark" size={18} color={colors.primary} />
            <Text style={styles.ageReminderText}>
              You must be 18+ to view this content
            </Text>
          </View>

          {/* Buttons */}
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.acceptButton}
              onPress={handleAccept}
            >
              <Text style={styles.acceptButtonText}>{content.acceptText}</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.declineButton}
              onPress={onDecline}
            >
              <Text style={styles.declineButtonText}>{content.declineText}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>
    </Modal>
  );
}

// Helper function to check if warning was dismissed
export const checkWarningDismissed = async (type: keyof typeof WARNING_KEYS): Promise<boolean> => {
  try {
    const dismissed = await AsyncStorage.getItem(WARNING_KEYS[type]);
    return dismissed === 'true';
  } catch (error) {
    return false;
  }
};

// Helper function to reset warning (for testing)
export const resetWarning = async (type: keyof typeof WARNING_KEYS): Promise<void> => {
  try {
    await AsyncStorage.removeItem(WARNING_KEYS[type]);
  } catch (error) {
    console.log('Error resetting warning:', error);
  }
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  container: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 340,
    alignItems: 'center',
    boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.2)',
    elevation: 8,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 8,
  },
  creatorName: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '600',
    marginBottom: 12,
  },
  message: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 16,
  },
  ageReminder: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundAlt,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginBottom: 20,
    gap: 8,
  },
  ageReminderText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '500',
  },
  buttonContainer: {
    width: '100%',
    gap: 10,
  },
  acceptButton: {
    backgroundColor: colors.accent,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  acceptButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  declineButton: {
    backgroundColor: colors.backgroundAlt,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  declineButtonText: {
    color: colors.textSecondary,
    fontSize: 15,
    fontWeight: '600',
  },
});
