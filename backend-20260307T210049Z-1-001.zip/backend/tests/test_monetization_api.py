"""
Backend API Tests for Monetization Features
- Coin packages and gifts endpoints
- Featured spots pricing
- Analytics plans
- Registration and auth flows
"""
import pytest
import requests
import os
from datetime import datetime

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://verified-creators-2.preview.emergentagent.com')

class TestPublicEndpoints:
    """Test public monetization endpoints that don't require auth"""
    
    def test_coins_packages(self):
        """GET /api/coins/packages - Returns available coin packages"""
        response = requests.get(f"{BASE_URL}/api/coins/packages")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Expected list of packages"
        assert len(data) > 0, "Expected at least one package"
        
        # Verify package structure
        for pkg in data:
            assert "id" in pkg, "Package missing 'id'"
            assert "coins" in pkg, "Package missing 'coins'"
            assert "price" in pkg, "Package missing 'price'"
            assert pkg["coins"] > 0, "Coins should be positive"
            assert pkg["price"] > 0, "Price should be positive"
        
        print(f"SUCCESS: /api/coins/packages returned {len(data)} packages")
    
    def test_coins_gifts(self):
        """GET /api/coins/gifts - Returns available virtual gifts"""
        response = requests.get(f"{BASE_URL}/api/coins/gifts")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Expected list of gifts"
        assert len(data) > 0, "Expected at least one gift type"
        
        # Verify gift structure
        for gift in data:
            assert "id" in gift, "Gift missing 'id'"
            assert "name" in gift, "Gift missing 'name'"
            assert "coin_cost" in gift, "Gift missing 'coin_cost'"
            assert gift["coin_cost"] > 0, "Coin cost should be positive"
        
        print(f"SUCCESS: /api/coins/gifts returned {len(data)} gift types")
    
    def test_featured_prices(self):
        """GET /api/featured/prices - Returns featured spot pricing"""
        response = requests.get(f"{BASE_URL}/api/featured/prices")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, dict), "Expected pricing dictionary"
        
        # Check expected spot types
        expected_types = ["explore_top", "explore_creators", "suggested"]
        for spot_type in expected_types:
            if spot_type in data:
                assert data[spot_type] > 0, f"Price for {spot_type} should be positive"
        
        print(f"SUCCESS: /api/featured/prices returned pricing data")
    
    def test_analytics_plans(self):
        """GET /api/analytics/plans - Returns analytics subscription plans"""
        response = requests.get(f"{BASE_URL}/api/analytics/plans")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, dict), "Expected plans dictionary"
        
        # Check expected plans
        expected_plans = ["basic", "pro", "enterprise"]
        for plan in expected_plans:
            if plan in data:
                assert "price" in data[plan], f"Plan {plan} missing price"
                assert data[plan]["price"] > 0, f"Price for {plan} plan should be positive"
        
        print(f"SUCCESS: /api/analytics/plans returned {len(data)} plans")
    
    def test_health_endpoint(self):
        """GET /api/health - Server health check"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("SUCCESS: /api/health is healthy")


class TestAuthenticationFlow:
    """Test user registration and login flow"""
    
    @pytest.fixture(scope="class")
    def test_user_data(self):
        """Generate unique test user data"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return {
            "email": f"TEST_user_{timestamp}@test.com",
            "password": "TestPass123!",
            "username": f"TEST_user_{timestamp}",
            "display_name": f"Test User {timestamp}"
        }
    
    def test_register_user(self, test_user_data):
        """POST /api/auth/register - Register new user"""
        response = requests.post(f"{BASE_URL}/api/auth/register", json=test_user_data)
        
        # User might already exist or registration should succeed
        if response.status_code == 200:
            data = response.json()
            assert "token" in data, "Registration should return token"
            assert "user" in data, "Registration should return user data"
            assert data["user"]["email"] == test_user_data["email"]
            print(f"SUCCESS: Registered user {test_user_data['username']}")
        elif response.status_code == 400:
            # Username or email taken is acceptable
            print(f"INFO: User already exists or validation error: {response.json()}")
        else:
            pytest.fail(f"Unexpected status {response.status_code}: {response.text}")
    
    def test_login_user(self, test_user_data):
        """POST /api/auth/login - Login with credentials"""
        # First register the user
        requests.post(f"{BASE_URL}/api/auth/register", json=test_user_data)
        
        # Then login
        login_data = {
            "email": test_user_data["email"],
            "password": test_user_data["password"]
        }
        response = requests.post(f"{BASE_URL}/api/auth/login", json=login_data)
        
        if response.status_code == 200:
            data = response.json()
            assert "token" in data, "Login should return token"
            assert "user" in data, "Login should return user data"
            print(f"SUCCESS: Logged in as {test_user_data['email']}")
        elif response.status_code == 401:
            print(f"INFO: Invalid credentials or user not found")
        else:
            pytest.fail(f"Unexpected status {response.status_code}: {response.text}")


class TestAuthenticatedEndpoints:
    """Test endpoints requiring authentication"""
    
    @pytest.fixture(scope="class")
    def auth_session(self):
        """Create authenticated session"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        user_data = {
            "email": f"TEST_auth_{timestamp}@test.com",
            "password": "AuthTestPass123!",
            "username": f"TEST_auth_{timestamp}",
            "display_name": f"Auth Test {timestamp}"
        }
        
        # Register
        response = requests.post(f"{BASE_URL}/api/auth/register", json=user_data)
        if response.status_code == 200:
            data = response.json()
            return {
                "token": data["token"],
                "user": data["user"],
                "headers": {"Authorization": f"Bearer {data['token']}"}
            }
        elif response.status_code == 400:
            # Try login
            login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
                "email": user_data["email"],
                "password": user_data["password"]
            })
            if login_response.status_code == 200:
                data = login_response.json()
                return {
                    "token": data["token"],
                    "user": data["user"],
                    "headers": {"Authorization": f"Bearer {data['token']}"}
                }
        pytest.skip("Could not authenticate for testing")
    
    def test_get_coin_balance(self, auth_session):
        """GET /api/coins/balance - Get user's coin balance"""
        response = requests.get(f"{BASE_URL}/api/coins/balance", headers=auth_session["headers"])
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert "balance" in data, "Response should include balance"
        assert isinstance(data["balance"], (int, float)), "Balance should be numeric"
        assert data["balance"] >= 0, "Balance should not be negative"
        
        print(f"SUCCESS: /api/coins/balance returned balance: {data['balance']}")
    
    def test_get_user_profile(self, auth_session):
        """GET /api/auth/me - Get current user profile"""
        response = requests.get(f"{BASE_URL}/api/auth/me", headers=auth_session["headers"])
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert "id" in data, "User should have id"
        assert "username" in data, "User should have username"
        assert "email" in data, "User should have email"
        
        print(f"SUCCESS: /api/auth/me returned user {data['username']}")
    
    def test_analytics_status(self, auth_session):
        """GET /api/analytics/status - Check analytics subscription status"""
        response = requests.get(f"{BASE_URL}/api/analytics/status", headers=auth_session["headers"])
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert "has_analytics" in data, "Should return analytics status"
        
        print(f"SUCCESS: /api/analytics/status returned has_analytics: {data['has_analytics']}")
    
    def test_verified_status(self, auth_session):
        """GET /api/verified/status - Check verified badge status"""
        response = requests.get(f"{BASE_URL}/api/verified/status", headers=auth_session["headers"])
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert "is_verified" in data, "Should return verification status"
        
        print(f"SUCCESS: /api/verified/status returned is_verified: {data['is_verified']}")


class TestVideoAndPostEndpoints:
    """Test video and post related endpoints"""
    
    def test_get_video_feed(self):
        """GET /api/posts/videos - Get video feed"""
        response = requests.get(f"{BASE_URL}/api/posts/videos")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Should return list of videos"
        print(f"SUCCESS: /api/posts/videos returned {len(data)} videos")
    
    def test_get_main_feed(self):
        """GET /api/posts - Get main feed"""
        response = requests.get(f"{BASE_URL}/api/posts")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        assert isinstance(data, list), "Should return list of posts"
        print(f"SUCCESS: /api/posts returned {len(data)} posts")


class TestPostBoostEndpoint:
    """Test boosted posts endpoints"""
    
    def test_get_boosted_posts(self):
        """GET /api/posts/boosted - Get boosted posts"""
        response = requests.get(f"{BASE_URL}/api/posts/boosted")
        # This endpoint might or might not exist
        if response.status_code == 200:
            data = response.json()
            assert isinstance(data, list), "Should return list of boosted posts"
            print(f"SUCCESS: /api/posts/boosted returned {len(data)} posts")
        elif response.status_code == 404:
            print(f"INFO: Boosted posts endpoint not found (404)")
        else:
            print(f"INFO: /api/posts/boosted returned {response.status_code}")


class TestGiftsEndpoints:
    """Test virtual gifts endpoints"""
    
    @pytest.fixture(scope="class")
    def auth_session(self):
        """Create authenticated session"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        user_data = {
            "email": f"TEST_gifts_{timestamp}@test.com",
            "password": "GiftsTestPass123!",
            "username": f"TEST_gifts_{timestamp}",
            "display_name": f"Gifts Test {timestamp}"
        }
        
        response = requests.post(f"{BASE_URL}/api/auth/register", json=user_data)
        if response.status_code == 200:
            data = response.json()
            return {
                "token": data["token"],
                "user": data["user"],
                "headers": {"Authorization": f"Bearer {data['token']}"}
            }
        pytest.skip("Could not authenticate for testing")
    
    def test_get_received_gifts(self, auth_session):
        """GET /api/gifts/received - Get received gifts"""
        response = requests.get(f"{BASE_URL}/api/gifts/received", headers=auth_session["headers"])
        
        if response.status_code == 200:
            data = response.json()
            assert isinstance(data, list), "Should return list of gifts"
            print(f"SUCCESS: /api/gifts/received returned {len(data)} gifts")
        else:
            print(f"INFO: /api/gifts/received returned {response.status_code}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
