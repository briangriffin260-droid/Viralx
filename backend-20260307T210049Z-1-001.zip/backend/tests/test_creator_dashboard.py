"""
Backend API tests for Creator Dashboard and Monetization features
Tests: /api/posts/boosted, /api/earnings/summary, /api/coins/*, /api/verified/*, /api/analytics/*
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://verified-creators-2.preview.emergentagent.com').rstrip('/')

class TestCreatorDashboardAPIs:
    """Tests for Creator Dashboard related APIs"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get auth token for existing test user"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": "uitest@test.com",
            "password": "TestPass123!"
        })
        if response.status_code != 200:
            pytest.skip("Test user not found - skipping authenticated tests")
        return response.json().get("token")
    
    @pytest.fixture(scope="class")
    def auth_headers(self, auth_token):
        """Headers with auth token"""
        return {"Authorization": f"Bearer {auth_token}", "Content-Type": "application/json"}
    
    # Test /api/posts/boosted endpoint (was returning 404 in iteration 1)
    def test_posts_boosted_returns_200(self):
        """Verify /api/posts/boosted now returns 200 (fixed from iteration 1)"""
        response = requests.get(f"{BASE_URL}/api/posts/boosted")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert isinstance(data, list), "Should return a list of posts"
        print(f"PASS: /api/posts/boosted returns 200 with {len(data)} boosted posts")
    
    # Test /api/earnings/summary endpoint
    def test_earnings_summary_returns_200(self, auth_headers):
        """Verify /api/earnings/summary returns earnings data"""
        response = requests.get(f"{BASE_URL}/api/earnings/summary", headers=auth_headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        
        # Verify required fields exist
        assert "total_earnings" in data, "Missing total_earnings field"
        assert "monthly_earnings" in data, "Missing monthly_earnings field"
        assert "pending_payout" in data, "Missing pending_payout field"
        assert "total_views" in data, "Missing total_views field"
        assert "total_likes" in data, "Missing total_likes field"
        
        # Verify data types
        assert isinstance(data["total_earnings"], (int, float)), "total_earnings should be numeric"
        assert isinstance(data["monthly_earnings"], (int, float)), "monthly_earnings should be numeric"
        print(f"PASS: /api/earnings/summary returns valid earnings data: {data}")
    
    def test_earnings_summary_requires_auth(self):
        """Verify /api/earnings/summary requires authentication"""
        response = requests.get(f"{BASE_URL}/api/earnings/summary")
        assert response.status_code == 403 or response.status_code == 401, \
            f"Expected 401/403 without auth, got {response.status_code}"
        print("PASS: /api/earnings/summary requires authentication")

    # Test coin balance
    def test_coins_balance(self, auth_headers):
        """Verify /api/coins/balance returns user coin balance"""
        response = requests.get(f"{BASE_URL}/api/coins/balance", headers=auth_headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert "balance" in data, "Missing balance field"
        assert isinstance(data["balance"], (int, float)), "Balance should be numeric"
        print(f"PASS: /api/coins/balance returns balance: {data['balance']}")
    
    # Test verified status
    def test_verified_status(self, auth_headers):
        """Verify /api/verified/status returns verification status"""
        response = requests.get(f"{BASE_URL}/api/verified/status", headers=auth_headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert "is_verified" in data, "Missing is_verified field"
        print(f"PASS: /api/verified/status returns status: {data}")
    
    # Test analytics status
    def test_analytics_status(self, auth_headers):
        """Verify /api/analytics/status returns analytics subscription status"""
        response = requests.get(f"{BASE_URL}/api/analytics/status", headers=auth_headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        # Should return has_analytics field (actual API response)
        assert "has_analytics" in data or "is_active" in data, "Missing has_analytics/is_active field"
        print(f"PASS: /api/analytics/status returns: {data}")
    
    # Test coin packages
    def test_coin_packages(self):
        """Verify /api/coins/packages returns available coin packages"""
        response = requests.get(f"{BASE_URL}/api/coins/packages")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert isinstance(data, list), "Should return list of packages"
        assert len(data) > 0, "Should have at least one coin package"
        print(f"PASS: /api/coins/packages returns {len(data)} packages")
    
    # Test coin gifts list
    def test_coin_gifts(self):
        """Verify /api/coins/gifts returns available virtual gifts"""
        response = requests.get(f"{BASE_URL}/api/coins/gifts")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert isinstance(data, list), "Should return list of gifts"
        print(f"PASS: /api/coins/gifts returns {len(data)} gift types")
    
    # Test featured prices
    def test_featured_prices(self):
        """Verify /api/featured/prices returns featured spot pricing"""
        response = requests.get(f"{BASE_URL}/api/featured/prices")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert isinstance(data, dict), "Should return pricing dictionary"
        print(f"PASS: /api/featured/prices returns: {data}")
    
    # Test analytics plans
    def test_analytics_plans(self):
        """Verify /api/analytics/plans returns available plans"""
        response = requests.get(f"{BASE_URL}/api/analytics/plans")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        # API returns dict with plan names as keys
        assert isinstance(data, (list, dict)), "Should return list or dict of plans"
        if isinstance(data, dict):
            assert len(data) >= 3, "Should have at least 3 plans (basic, pro, enterprise)"
            print(f"PASS: /api/analytics/plans returns {len(data)} plans: {list(data.keys())}")
        else:
            assert len(data) >= 3, "Should have at least 3 plans"
            print(f"PASS: /api/analytics/plans returns {len(data)} plans")
    
    # Test gifts received
    def test_gifts_received(self, auth_headers):
        """Verify /api/gifts/received returns gifts received by user"""
        response = requests.get(f"{BASE_URL}/api/gifts/received", headers=auth_headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert isinstance(data, list), "Should return list of received gifts"
        print(f"PASS: /api/gifts/received returns {len(data)} gifts")


class TestCreatorFlow:
    """Test flow for becoming a premium creator"""
    
    @pytest.fixture(scope="class")
    def auth_data(self):
        """Login and get user data"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": "uitest@test.com",
            "password": "TestPass123!"
        })
        if response.status_code != 200:
            pytest.skip("Test user not found")
        return response.json()
    
    @pytest.fixture(scope="class")
    def auth_headers(self, auth_data):
        return {"Authorization": f"Bearer {auth_data['token']}", "Content-Type": "application/json"}
    
    def test_user_can_update_to_premium_creator(self, auth_headers):
        """Test that user can update profile to become premium creator"""
        response = requests.put(f"{BASE_URL}/api/auth/profile", headers=auth_headers, json={
            "is_premium_creator": True,
            "subscription_price": 12.99
        })
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert data["is_premium_creator"] == True, "Should be premium creator"
        assert data["subscription_price"] == 12.99, "Subscription price should be updated"
        print("PASS: User successfully updated to premium creator")
    
    def test_premium_creator_can_access_earnings(self, auth_headers):
        """Premium creator should be able to access earnings summary"""
        response = requests.get(f"{BASE_URL}/api/earnings/summary", headers=auth_headers)
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert "total_earnings" in data
        print(f"PASS: Premium creator can access earnings: {data}")
    
    def test_revert_to_non_premium(self, auth_headers):
        """Clean up - revert user to non-premium status"""
        response = requests.put(f"{BASE_URL}/api/auth/profile", headers=auth_headers, json={
            "is_premium_creator": False,
            "subscription_price": 9.99
        })
        assert response.status_code == 200
        print("PASS: Cleaned up - user reverted to non-premium")


class TestHealthEndpoints:
    """Basic health and root endpoints"""
    
    def test_api_root(self):
        """Test API root endpoint"""
        response = requests.get(f"{BASE_URL}/api/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "version" in data
        print(f"PASS: API root returns: {data}")
    
    def test_health_check(self):
        """Test health check endpoint"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data.get("status") == "healthy"
        print(f"PASS: Health check returns: {data}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
